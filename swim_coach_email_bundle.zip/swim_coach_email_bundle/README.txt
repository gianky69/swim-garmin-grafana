SWIM COACH — EMAIL AUTOMATICHE

Contenuto:
- send_swim_coach_email.py: invia il riepilogo settimanale o il promemoria della seduta prevista per domani.
- unit e timer systemd.
- install_email_reports.sh: installazione con backup; i timer restano disattivati fino alla verifica manuale.

INSTALLAZIONE SU LXC
1. Trasferire tutti i file in una stessa cartella, ad esempio /opt/swim-coach/email-bundle, usando WinSCP.
2. Entrare nella cartella e lanciare da root:
   bash install_email_reports.sh
3. Eseguire le due prove in sola lettura stampate al termine dello script. --dry-run non invia posta e non registra invii.
4. Controllare che il riepilogo mostri i report della settimana e le sedute programmate, e che la prova datata 2026-10-10 mostri W1-A per domenica 11 ottobre.
5. Solo dopo aver controllato le anteprime, attivare:
   systemctl enable --now swim-coach-weekly.timer swim-coach-reminder.timer

PROGRAMMAZIONE
- Riepilogo settimanale: ogni sabato alle 08:00, ora Europe/Rome. Comprende i report TXT con data attività negli ultimi 7 giorni e le sedute programmate nei prossimi 7 giorni.
- Promemoria: controllo ogni giorno alle 18:00, ora Europe/Rome; invia una mail soltanto quando il giorno dopo è programmata una seduta.
- I report vengono inviati tramite /usr/sbin/sendmail e quindi tramite Postfix già configurato con Gmail.
- Gli invii sono registrati in /opt/swim-coach/data/email_state.json per evitare duplicati settimanali o per la stessa data di allenamento.
- Le password SMTP restano nella mappa SASL di Postfix; questo pacchetto non le legge né le copia.

Il test con --dry-run non spedisce email. I timer non si attivano automaticamente durante l'installazione.
