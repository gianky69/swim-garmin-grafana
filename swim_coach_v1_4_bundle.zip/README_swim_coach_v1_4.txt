SWIM COACH V1.4 — INSTALLAZIONE E NOTE
======================================

CONTENUTO
---------
swim_coach_web_v1_4.py   Web UI V1.4: dashboard, unione registrazioni, pagina report e pagina allenamenti futuri.
profile_v1_6.py          Motore profilo V1.6: applica le correzioni ai lap e raggruppa le registrazioni unite solo per il coaching.
swim_report.py           Report TXT/HTML con provenienza dei lap per le sedute composte da più registrazioni.
update_swim_coach.py     Aggiornamento unico, backup e validazione di profilo/report.
activity_merges.py       Archivio separato e funzioni per le unioni di registrazioni.
install_swim_coach_v1_4.sh Script che crea backup, installa i file, rigenera profilo/report e riavvia il servizio.

INSTALLAZIONE NEL LXC
---------------------
1. Copia swim_coach_v1_4_bundle.zip in /opt/swim-coach (ad esempio con WinSCP).
2. Esegui:

   cd /opt/swim-coach
   unzip swim_coach_v1_4_bundle.zip -d install-v1.4
   cd /opt/swim-coach/install-v1.4
   chmod +x install_swim_coach_v1_4.sh
   ./install_swim_coach_v1_4.sh

Lo script crea un backup con data/ora in /opt/swim-coach/backups, verifica la sintassi,
rigenera swim_profile.json e il report TXT/HTML e riavvia swim-coach-web.service. Le variabili
SWIM_COACH_SKIP_UPDATE=1 e SWIM_COACH_SKIP_RESTART=1 servono soltanto per test manuali.
Non sovrascrive corrections.json, history_swim.json o i file di analisi Garmin.

PAGINE DELLA WEB UI
-------------------
Home:                 http://IP_DEL_LXC:8090/
Correzione dati:      http://IP_DEL_LXC:8090/corrections
Unisci registrazioni: http://IP_DEL_LXC:8090/merge-activities
Report:               http://IP_DEL_LXC:8090/reports
Allenamenti futuri:   http://IP_DEL_LXC:8090/future

UNIONE DI REGISTRAZIONI
----------------------
Nella pagina "Unisci registrazioni" scegli due attività della stessa data.
La prima sarà l'inizio della seduta, la seconda verrà accodata. Non è consentito usare
la stessa attività in due unioni contemporaneamente. L'azione viene salvata in
 data/activity_merges.json, mantiene intatti i lap originali e avvia automaticamente
update_swim_coach.py per aggiornare il profilo e il report. L'unione è reversibile
tramite "Annulla unione".

CORREZIONI E DATI ORIGINALI
---------------------------
corrections.json continua a contenere le correzioni dei singoli lap e le unioni tra lap.
activity_merges.json registra separatamente le unioni tra intere registrazioni.
all_observations resta con i record originali; coaching_observations contiene le
correzioni e le sedute accorpate per il motore di coaching.

ALLENAMENTI FUTURI
------------------
La pagina /future legge data/upcoming_workouts.json. L'installatore crea un archivio
vuoto se non esiste. La pagina mostrerà gli allenamenti appena il prossimo passaggio
collegherà la programmazione del coach a questo file. Schema minimo:

{
  "version": 1,
  "workouts": [
    {
      "date": "2026-10-12",
      "title": "Tecnica e ritmo 100 m",
      "focus": "Mantenere una bracciata efficiente",
      "distance_m": 2000,
      "notes": "Esempio di schema; non è un allenamento prescritto.",
      "sets": [
        {"reps": "8x", "distance_m": 50, "pace": "controllato", "rest": "20 s"}
      ]
    }
  ]
}

NOTE
----
L'installatore genera i nuovi report locali durante l'aggiornamento. Non viene inviata
nessuna e-mail. Le versioni precedenti dei report restano nella cartella reports/archive.
