Archivio dei sorgenti Swim Coach per il repository GitHub.
Non include data Garmin, correzioni, report personali o credenziali.
L'archivio completo di ripristino va conservato privatamente.
