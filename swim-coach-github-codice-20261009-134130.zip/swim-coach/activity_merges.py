#!/usr/bin/env python3
"""Supporto per unire registrazioni Garmin della stessa seduta.

Le unioni vengono salvate in data/activity_merges.json, separato dalle
correzioni dei singoli lap. I dati originali restano invariati in
all_observations; solo coaching_observations viene raggruppato.
"""
from __future__ import annotations

import copy
import json
import os
from pathlib import Path
from typing import Any

BASE_DIR = Path("/opt/swim-coach")
DATA_DIR = BASE_DIR / "data"
ACTIVITY_MERGES_FILE = DATA_DIR / "activity_merges.json"


def empty_activity_merges() -> dict[str, Any]:
    return {"version": 1, "merges": []}


def load_activity_merges(path: Path | None = None) -> dict[str, Any]:
    target = path or ACTIVITY_MERGES_FILE
    try:
        with target.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        return empty_activity_merges()
    except (OSError, json.JSONDecodeError):
        return empty_activity_merges()
    if not isinstance(data, dict):
        return empty_activity_merges()
    merges = data.get("merges", [])
    if not isinstance(merges, list):
        merges = []
    clean = []
    used: set[str] = set()
    for entry in merges:
        if not isinstance(entry, dict):
            continue
        ids = entry.get("activity_ids")
        if not isinstance(ids, list) or len(ids) != 2:
            continue
        a, b = (str(ids[0]).strip(), str(ids[1]).strip())
        if not a or not b or a == b or a in used or b in used:
            continue
        item = dict(entry)
        item["activity_ids"] = [a, b]
        item["primary_activity_id"] = a
        item.setdefault("merge_id", f"{a}--{b}")
        used.update((a, b))
        clean.append(item)
    return {"version": int(data.get("version", 1) or 1), "merges": clean}


def save_activity_merges(data: dict[str, Any], path: Path | None = None) -> None:
    target = path or ACTIVITY_MERGES_FILE
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = load_activity_merges_from_payload(data)
    temporary = target.with_suffix(target.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(temporary, target)


def load_activity_merges_from_payload(data: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(data, dict):
        return empty_activity_merges()
    raw = data.get("merges", [])
    if not isinstance(raw, list):
        raw = []
    clean = []
    seen: set[str] = set()
    for entry in raw:
        if not isinstance(entry, dict):
            continue
        ids = entry.get("activity_ids")
        if not isinstance(ids, list) or len(ids) != 2:
            continue
        a, b = (str(ids[0]).strip(), str(ids[1]).strip())
        if not a or not b or a == b or a in seen or b in seen:
            continue
        item = dict(entry)
        item["activity_ids"] = [a, b]
        item["primary_activity_id"] = a
        item["merge_id"] = str(item.get("merge_id") or f"{a}--{b}")
        seen.update((a, b))
        clean.append(item)
    return {"version": 1, "merges": clean}


def _as_float(value: Any) -> float | None:
    try:
        value = float(value)
    except (TypeError, ValueError):
        return None
    return value if value == value and abs(value) != float("inf") else None


def _lap_sort_key(row: dict[str, Any]) -> tuple[int, str]:
    try:
        return (int(row.get("lap")), "")
    except (TypeError, ValueError):
        return (10**9, str(row.get("lap", "")))


def _activity_name(rows: list[dict[str, Any]], history_entry: dict[str, Any], aid: str) -> str:
    history_name = str(history_entry.get("name") or "").strip()
    if history_name:
        return history_name
    for row in rows:
        name = str(row.get("activity_name") or "").strip()
        if name:
            return name
    return f"Attività {aid}"


def apply_activity_merges(
    records: list[dict[str, Any]],
    merge_data: dict[str, Any],
    history: dict[str, dict[str, Any]],
) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]], list[dict[str, Any]], list[str]]:
    """Raggruppa coppie di attività nella stessa seduta per il coaching.

    Ogni record conserva source_activity_id/source_lap per mantenere leggibile
    la provenienza nei report. La lista records di ingresso non viene mutata.
    """
    original_history = copy.deepcopy(history)
    merges = merge_data.get("merges", []) if isinstance(merge_data, dict) else []
    rows_by_activity: dict[str, list[dict[str, Any]]] = {}
    for row in records:
        aid = str(row.get("activity_id", "")).strip()
        if aid:
            rows_by_activity.setdefault(aid, []).append(row)
    for rows in rows_by_activity.values():
        rows.sort(key=_lap_sort_key)

    occupied: set[str] = set()
    source_to_entry: dict[str, dict[str, Any]] = {}
    applied: list[dict[str, Any]] = []
    warnings: list[str] = []

    for entry in merges:
        if not isinstance(entry, dict):
            continue
        ids = entry.get("activity_ids", [])
        if not isinstance(ids, list) or len(ids) != 2:
            continue
        id_a, id_b = str(ids[0]), str(ids[1])
        if id_a == id_b or id_a in occupied or id_b in occupied:
            warnings.append(f"Unione attività ignorata per ID sovrapposti: {id_a}, {id_b}.")
            continue
        if not rows_by_activity.get(id_a) or not rows_by_activity.get(id_b):
            warnings.append(f"Unione attività ignorata: mancano osservazioni per {id_a} o {id_b}.")
            continue

        meta_a = original_history.get(id_a, {})
        meta_b = original_history.get(id_b, {})
        date_a = str(meta_a.get("date") or next((r.get("date") for r in rows_by_activity[id_a] if r.get("date")), ""))
        date_b = str(meta_b.get("date") or next((r.get("date") for r in rows_by_activity[id_b] if r.get("date")), ""))
        stored_date = str(entry.get("date") or "")
        if not date_a or not date_b or date_a != date_b or (stored_date and stored_date != date_a):
            warnings.append(f"Unione attività ignorata perché le date non coincidono: {id_a} ({date_a}), {id_b} ({date_b}).")
            continue

        name_a = _activity_name(rows_by_activity[id_a], meta_a, id_a)
        name_b = _activity_name(rows_by_activity[id_b], meta_b, id_b)
        merged_name = f"{name_a} + {name_b} (registrazioni unite)"
        merge_id = str(entry.get("merge_id") or f"{id_a}--{id_b}")

        combined_rows = []
        for source_id in (id_a, id_b):
            for row in rows_by_activity[source_id]:
                item = dict(row)
                item["source_activity_id"] = source_id
                item["source_activity_name"] = _activity_name(rows_by_activity[source_id], original_history.get(source_id, {}), source_id)
                item["source_lap"] = row.get("lap")
                item["session_merge_id"] = merge_id
                item["session_merged"] = True
                item["session_source_ids"] = [id_a, id_b]
                item["activity_id"] = id_a
                item["activity_name"] = merged_name
                item["date"] = date_a
                item["lap"] = len(combined_rows) + 1
                combined_rows.append(item)

        source_to_entry[id_a] = {"merge_id": merge_id, "activity_ids": [id_a, id_b], "rows": combined_rows}
        source_to_entry[id_b] = source_to_entry[id_a]
        occupied.update((id_a, id_b))
        applied.append({**entry, "activity_ids": [id_a, id_b], "merge_id": merge_id, "date": date_a, "combined_name": merged_name, "lap_count": len(combined_rows)})

        # Aggiorna soltanto i metadati di riepilogo, senza toccare history_swim.json.
        a = original_history.get(id_a, {})
        b = original_history.get(id_b, {})
        merged_meta = dict(a)
        merged_meta.update({"activity_id": id_a, "date": date_a, "name": merged_name, "merged_activity_ids": [id_a, id_b]})
        for field in ("distance", "duration", "training_load"):
            va, vb = _as_float(a.get(field)), _as_float(b.get(field))
            if va is not None or vb is not None:
                merged_meta[field] = (va or 0.0) + (vb or 0.0)
        hr_a, hr_b = _as_float(a.get("avg_hr")), _as_float(b.get("avg_hr"))
        dur_a, dur_b = _as_float(a.get("duration")), _as_float(b.get("duration"))
        if hr_a is not None and hr_b is not None and dur_a and dur_b and dur_a + dur_b > 0:
            merged_meta["avg_hr"] = (hr_a * dur_a + hr_b * dur_b) / (dur_a + dur_b)
        elif hr_a is None and hr_b is not None:
            merged_meta["avg_hr"] = hr_b
        max_a, max_b = _as_float(a.get("max_hr")), _as_float(b.get("max_hr"))
        max_values = [v for v in (max_a, max_b) if v is not None]
        if max_values:
            merged_meta["max_hr"] = max(max_values)
        original_history[id_a] = merged_meta
        original_history.pop(id_b, None)

    # Emissione in ordine: una seduta unita appare nel punto della prima registrazione.
    output: list[dict[str, Any]] = []
    emitted_merge_ids: set[str] = set()
    for row in records:
        aid = str(row.get("activity_id", "")).strip()
        mapped = source_to_entry.get(aid)
        if not mapped:
            output.append(dict(row))
            continue
        merge_id = mapped["merge_id"]
        if merge_id in emitted_merge_ids:
            continue
        output.extend(mapped["rows"])
        emitted_merge_ids.add(merge_id)

    return output, original_history, applied, warnings
