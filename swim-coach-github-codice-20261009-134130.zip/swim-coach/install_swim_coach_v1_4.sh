#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="${SWIM_COACH_DIR:-/opt/swim-coach}"
PACKAGE_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$BASE_DIR/backups/install-v1.4-$STAMP"

if [[ ! -d "$BASE_DIR" ]]; then
  echo "ERRORE: cartella Swim Coach non trovata: $BASE_DIR" >&2
  exit 1
fi
for required in swim_coach_web_v1_4.py profile_v1_6.py swim_report.py update_swim_coach.py activity_merges.py; do
  if [[ ! -f "$PACKAGE_DIR/$required" ]]; then
    echo "ERRORE: file del pacchetto mancante: $PACKAGE_DIR/$required" >&2
    exit 1
  fi
done

mkdir -p "$BASE_DIR/backups" "$BASE_DIR/data" "$BASE_DIR/reports"
mkdir -p "$BACKUP_DIR/data" "$BACKUP_DIR/scripts"

# Backup completo degli script che verranno sostituiti e dei dati chiave.
for name in swim_coach_web.py profile.py swim_report.py update_swim_coach.py activity_merges.py; do
  if [[ -f "$BASE_DIR/$name" ]]; then
    cp -a "$BASE_DIR/$name" "$BACKUP_DIR/scripts/$name"
  else
    printf '%s\n' "$name" >> "$BACKUP_DIR/scripts/not-present-before-install.txt"
  fi
done
for name in swim_profile.json corrections.json activity_merges.json upcoming_workouts.json; do
  if [[ -f "$BASE_DIR/data/$name" ]]; then
    cp -a "$BASE_DIR/data/$name" "$BACKUP_DIR/data/$name"
  else
    printf '%s\n' "$name" >> "$BACKUP_DIR/data/not-present-before-install.txt"
  fi
done

cp -f "$PACKAGE_DIR/swim_coach_web_v1_4.py" "$BASE_DIR/swim_coach_web.py"
cp -f "$PACKAGE_DIR/profile_v1_6.py" "$BASE_DIR/profile.py"
cp -f "$PACKAGE_DIR/swim_report.py" "$BASE_DIR/swim_report.py"
cp -f "$PACKAGE_DIR/update_swim_coach.py" "$BASE_DIR/update_swim_coach.py"
cp -f "$PACKAGE_DIR/activity_merges.py" "$BASE_DIR/activity_merges.py"
chmod 755 "$BASE_DIR/swim_coach_web.py" "$BASE_DIR/profile.py" "$BASE_DIR/swim_report.py" "$BASE_DIR/update_swim_coach.py" "$BASE_DIR/activity_merges.py"

# Inizializza i nuovi archivi solo se non esistono: i dati esistenti non vengono sovrascritti.
if [[ ! -f "$BASE_DIR/data/activity_merges.json" ]]; then
  printf '{\n  "version": 1,\n  "merges": []\n}\n' > "$BASE_DIR/data/activity_merges.json"
fi
if [[ ! -f "$BASE_DIR/data/upcoming_workouts.json" ]]; then
  printf '{\n  "version": 1,\n  "workouts": []\n}\n' > "$BASE_DIR/data/upcoming_workouts.json"
fi

printf '\nBackup installazione: %s\n' "$BACKUP_DIR"
printf '\nVerifica sintassi Python...\n'
/usr/bin/python3 -m py_compile \
  "$BASE_DIR/activity_merges.py" \
  "$BASE_DIR/profile.py" \
  "$BASE_DIR/swim_report.py" \
  "$BASE_DIR/update_swim_coach.py" \
  "$BASE_DIR/swim_coach_web.py"

if [[ "${SWIM_COACH_SKIP_UPDATE:-0}" == "1" ]]; then
  printf '\nAggiornamento profilo/report saltato su richiesta (SWIM_COACH_SKIP_UPDATE=1).\n'
else
  printf '\nRigenerazione profilo e report con la nuova versione...\n'
  /usr/bin/python3 "$BASE_DIR/update_swim_coach.py"
fi

if [[ "${SWIM_COACH_SKIP_RESTART:-0}" == "1" ]]; then
  printf '\nRiavvio Web UI saltato su richiesta (SWIM_COACH_SKIP_RESTART=1).\n'
else
  printf '\nRiavvio Web UI...\n'
  systemctl restart swim-coach-web.service
  systemctl is-active --quiet swim-coach-web.service
  systemctl status swim-coach-web.service --no-pager -l
fi

printf '\nInstallazione Swim Coach V1.4 completata.\n'
printf 'Backup: %s\n' "$BACKUP_DIR"
printf 'Web UI: http://IP_DEL_LXC:8090\n'
printf 'Nuovi archivi: %s/data/activity_merges.json e %s/data/upcoming_workouts.json\n' "$BASE_DIR" "$BASE_DIR"
