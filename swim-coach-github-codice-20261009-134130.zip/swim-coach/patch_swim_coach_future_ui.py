#!/usr/bin/env python3
"""Add a safe editor for future Swim Coach workouts to swim_coach_web.py.

Run on the Swim Coach host as root:
    python3 /opt/swim-coach/patch_swim_coach_future_ui.py
Then validate and restart swim-coach-web.service.
"""
from __future__ import annotations

import ast
import os
import sys
from datetime import datetime
from pathlib import Path

TARGET = Path("/opt/swim-coach/swim_coach_web.py")
MARKER = "SWIM_COACH_FUTURE_EDITOR_V1"

NEW_FUTURE_PAGE = r'''def future_workouts_page(message: str = "") -> str:
    """Show future workouts with edit, add and delete forms."""
    workouts = read_upcoming_workouts()
    cards = []

    def set_lines_for(workout: dict) -> list[str]:
        values = workout.get("sets", workout.get("main_set", []))
        if not isinstance(values, list):
            return []
        result = []
        for item in values:
            if isinstance(item, dict):
                parts = [
                    str(item.get(k))
                    for k in ("reps", "distance_m", "description", "pace", "rest")
                    if item.get(k) not in (None, "")
                ]
                if parts:
                    result.append(" · ".join(parts))
            elif str(item).strip():
                result.append(str(item).strip())
        return result

    def field(label: str, name: str, value: object, input_type: str = "text") -> str:
        return (
            f"<label style='display:block;margin:8px 0'>{html.escape(label)}"
            f"<input type='{input_type}' name='{name}' value='{html.escape(str(value or ''), quote=True)}' "
            "style='display:block;box-sizing:border-box;width:100%;max-width:100%;padding:8px;margin-top:4px' "
            "required></label>"
        )

    def editor_form(workout: dict, index: int, is_new: bool = False) -> str:
        workout_id = str(workout.get("id") or "")
        date_value = str(workout.get("date") or workout.get("scheduled_date") or "")
        title_value = str(workout.get("title") or workout.get("name") or "")
        distance_value = workout.get("distance_m", 2000)
        focus_value = str(workout.get("focus") or workout.get("goal") or "")
        notes_value = str(workout.get("notes") or workout.get("description") or "")
        sets_text = "\n".join(set_lines_for(workout))
        heading = "Nuova seduta" if is_new else f"Seduta {index}: {title_value or workout_id}"
        buttons = (
            "<button type='submit' name='action' value='add'>Aggiungi seduta</button>"
            if is_new else
            "<button type='submit' name='action' value='save'>Salva modifiche</button> "
            "<button type='submit' name='action' value='delete' class='warnbtn' "
            "onclick=\"return confirm('Eliminare questa seduta dal calendario?')\">Elimina seduta</button>"
        )
        hidden_id = "" if is_new else f"<input type='hidden' name='workout_id' value='{html.escape(workout_id, quote=True)}'>"
        distance_html = (
            f"<label style='display:block;margin:8px 0'>Distanza prevista (m)"
            f"<input type='number' name='distance_m' min='25' max='10000' step='25' "
            f"value='{html.escape(str(distance_value), quote=True)}' required "
            "style='display:block;box-sizing:border-box;width:100%;max-width:100%;padding:8px;margin-top:4px'></label>"
        )
        return (
            "<div class='card'>"
            f"<h2>{html.escape(heading)}</h2>"
            "<form method='post' action='/future/save'>"
            f"{hidden_id}"
            f"{field('Data', 'date', date_value, 'date')}"
            f"{field('Titolo', 'title', title_value)}"
            f"{distance_html}"
            f"{field('Obiettivo', 'focus', focus_value)}"
            "<label style='display:block;margin:8px 0'>Note"
            f"<textarea name='notes' rows='3' style='display:block;box-sizing:border-box;width:100%;max-width:100%;padding:8px;margin-top:4px'>{html.escape(notes_value)}</textarea></label>"
            "<label style='display:block;margin:8px 0'>Blocchi dell'allenamento "
            "<span class='small'>(una serie per riga; specifica stile, pinne e recupero)</span>"
            f"<textarea name='sets' rows='9' required style='display:block;box-sizing:border-box;width:100%;max-width:100%;padding:8px;margin-top:4px'>{html.escape(sets_text)}</textarea></label>"
            f"<p>{buttons}</p>"
            "</form></div>"
        )

    for index, workout in enumerate(
        sorted(workouts, key=lambda item: (str(item.get("date") or item.get("scheduled_date") or "9999-12-31"), str(item.get("title") or item.get("name") or ""))),
        start=1,
    ):
        cards.append(editor_form(workout, index))

    new_workout = {
        "date": "",
        "title": "",
        "distance_m": 2000,
        "focus": "",
        "notes": "",
        "sets": [],
    }
    message_html = f"<div class='notice'>{html.escape(message)}</div>" if message else ""
    intro = (
        "<div class='card'><h2>Programmazione degli allenamenti</h2>"
        "<p>Modifica le sedute, cambia la data, aggiungi una nuova seduta oppure elimina quella non più prevista. "
        "Le modifiche sono salvate in un file JSON separato dai dati Garmin. Prima di ogni salvataggio viene creata una copia di sicurezza.</p>"
        "<p class='small'>Inserisci una serie per riga. Il recupero va scritto nella descrizione della serie, per esempio: «recupero 20 s».</p></div>"
    )
    return render_page(
        "Allenamenti futuri",
        f"{message_html}<div class='toolbar' style='margin-bottom:12px'><a class='button secondary' href='/'>← Dashboard</a></div>"
        f"{intro}{''.join(cards)}{editor_form(new_workout, 0, True)}",
    )
'''

POST_HANDLER = r'''        # Gestione del calendario degli allenamenti futuri.
        if path == "/future/save":
            def future_redirect(text: str) -> None:
                self.redirect("/future?message=" + urllib.parse.quote(text))

            try:
                content_length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                content_length = 0
            if content_length < 0 or content_length > 2_000_000:
                future_redirect("Richiesta troppo grande o non valida.")
                return
            raw = self.rfile.read(content_length).decode("utf-8", errors="replace")
            form = urllib.parse.parse_qs(raw, keep_blank_values=True)
            action = str(form.get("action", [""])[0]).strip()
            workout_id = str(form.get("workout_id", [""])[0]).strip()
            if action not in ("add", "save", "delete"):
                future_redirect("Operazione non riconosciuta.")
                return

            values = None
            if action != "delete":
                date_value = str(form.get("date", [""])[0]).strip()
                title_value = str(form.get("title", [""])[0]).strip()
                focus_value = str(form.get("focus", [""])[0]).strip()
                notes_value = str(form.get("notes", [""])[0]).strip()
                sets_text = str(form.get("sets", [""])[0])
                try:
                    distance_value = int(str(form.get("distance_m", [""])[0]).strip())
                except ValueError:
                    distance_value = 0
                try:
                    parsed_date = datetime.strptime(date_value, "%Y-%m-%d")
                    date_is_valid = parsed_date.strftime("%Y-%m-%d") == date_value
                except ValueError:
                    date_is_valid = False
                set_values = [line.strip() for line in sets_text.splitlines() if line.strip()]
                if not date_is_valid:
                    future_redirect("Inserisci una data valida nel formato richiesto.")
                    return
                if not title_value or len(title_value) > 160:
                    future_redirect("Il titolo è obbligatorio e non può superare 160 caratteri.")
                    return
                if distance_value < 25 or distance_value > 10000 or distance_value % 25 != 0:
                    future_redirect("La distanza deve essere tra 25 e 10000 m, a multipli di 25 m.")
                    return
                if len(focus_value) > 300 or len(notes_value) > 3000:
                    future_redirect("Obiettivo o note troppo lunghi.")
                    return
                if not set_values or len(set_values) > 80 or any(len(line) > 500 for line in set_values):
                    future_redirect("Inserisci da 1 a 80 serie, ciascuna lunga al massimo 500 caratteri.")
                    return
                values = {
                    "date": date_value,
                    "title": title_value,
                    "distance_m": distance_value,
                    "focus": focus_value,
                    "notes": notes_value,
                    "sets": set_values,
                }

            try:
                with FUTURE_WORKOUTS_LOCK:
                    if FUTURE_WORKOUTS_FILE.exists():
                        with FUTURE_WORKOUTS_FILE.open("r", encoding="utf-8") as stream:
                            stored = json.load(stream)
                    else:
                        stored = {"version": 1, "workouts": []}

                    if isinstance(stored, list):
                        data = {"version": 1, "workouts": stored}
                    elif isinstance(stored, dict):
                        data = dict(stored)
                        existing = data.get("workouts", data.get("sessions", []))
                        data["workouts"] = existing
                    else:
                        raise ValueError("Il file del programma non ha una struttura riconosciuta.")

                    workouts = data.get("workouts")
                    if not isinstance(workouts, list) or any(not isinstance(item, dict) for item in workouts):
                        raise ValueError("L'elenco delle sedute nel file non è valido; nessun dato è stato modificato.")

                    if action == "delete":
                        if not workout_id:
                            raise ValueError("ID della seduta mancante.")
                        remaining = [item for item in workouts if str(item.get("id", "")) != workout_id]
                        if len(remaining) == len(workouts):
                            raise ValueError("La seduta da eliminare non è stata trovata.")
                        workouts = remaining
                        success_message = "Seduta eliminata dal calendario."
                    elif action == "save":
                        if not workout_id:
                            raise ValueError("ID della seduta mancante.")
                        match_index = next((i for i, item in enumerate(workouts) if str(item.get("id", "")) == workout_id), None)
                        if match_index is None:
                            raise ValueError("La seduta da modificare non è stata trovata.")
                        workouts[match_index] = {**workouts[match_index], **values, "id": workout_id}
                        success_message = "Seduta aggiornata."
                    else:
                        new_id = "SC-" + datetime.now().astimezone().strftime("%Y%m%d-%H%M%S-%f")
                        while any(str(item.get("id", "")) == new_id for item in workouts):
                            new_id += "-1"
                        workouts.append({"id": new_id, **values})
                        success_message = "Nuova seduta aggiunta."

                    data["version"] = data.get("version", 1)
                    data["workouts"] = sorted(
                        workouts,
                        key=lambda item: (str(item.get("date") or item.get("scheduled_date") or "9999-12-31"), str(item.get("title") or item.get("name") or "")),
                    )
                    data.pop("sessions", None)

                    if FUTURE_WORKOUTS_FILE.exists():
                        stamp = datetime.now().astimezone().strftime("%Y%m%d-%H%M%S-%f")
                        backup_path = FUTURE_WORKOUTS_FILE.with_name(FUTURE_WORKOUTS_FILE.name + ".bak-" + stamp)
                        backup_path.write_bytes(FUTURE_WORKOUTS_FILE.read_bytes())
                    atomic_write_json(FUTURE_WORKOUTS_FILE, data)
            except (OSError, ValueError, json.JSONDecodeError) as exc:
                future_redirect("Salvataggio non riuscito: " + str(exc))
                return

            future_redirect(success_message + " Copia di sicurezza creata prima del salvataggio, se il file esisteva già.")
            return

'''


def main() -> int:
    if not TARGET.is_file():
        print(f"ERRORE: file non trovato: {TARGET}", file=sys.stderr)
        return 1

    source = TARGET.read_text(encoding="utf-8")
    if MARKER in source:
        print("L'editor degli allenamenti futuri risulta già installato; nessuna modifica eseguita.")
        return 0

    if "def future_workouts_page(" not in source or "def rebuild_after_activity_merge(" not in source:
        print("ERRORE: struttura del file diversa da quella attesa. Nessuna modifica eseguita.", file=sys.stderr)
        return 1
    post_marker = '        if path in ("/merge-activities/create", "/merge-activities/unmerge"):'
    if post_marker not in source:
        print("ERRORE: punto di inserimento POST non trovato. Nessuna modifica eseguita.", file=sys.stderr)
        return 1
    if "CORRECTIONS_LOCK = threading.Lock()" not in source:
        print("ERRORE: lock principale non trovato. Nessuna modifica eseguita.", file=sys.stderr)
        return 1

    # Add a dedicated lock, keeping the corrections lock separate.
    source = source.replace(
        "CORRECTIONS_LOCK = threading.Lock()",
        "CORRECTIONS_LOCK = threading.Lock()\nFUTURE_WORKOUTS_LOCK = threading.Lock()",
        1,
    )

    page_start = source.index("def future_workouts_page(")
    page_end = source.index("\n\ndef rebuild_after_activity_merge(", page_start)
    source = source[:page_start] + NEW_FUTURE_PAGE.rstrip() + source[page_end:]

    post_marker = '        if path in ("/merge-activities/create", "/merge-activities/unmerge"):'
    source = source.replace(post_marker, POST_HANDLER + post_marker, 1)

    # Make the patch idempotency marker part of the source.
    source = source.replace(
        '"""\n        self.redirect("/future?message=" + urllib.parse.quote(text))',
        '"""\n        self.redirect("/future?message=" + urllib.parse.quote(text))',
        1,
    )
    # The route marker is a comment so later executions can detect an installed patch.
    source = source.replace(
        "        # Gestione del calendario degli allenamenti futuri.",
        f"        # {MARKER}: gestione del calendario degli allenamenti futuri.",
        1,
    )

    try:
        compile(source, str(TARGET), "exec")
    except SyntaxError as exc:
        print(f"ERRORE di sintassi nel codice generato (riga {exc.lineno}): {exc.msg}. Nessuna modifica eseguita.", file=sys.stderr)
        return 1

    timestamp = datetime.now().astimezone().strftime("%Y%m%d-%H%M%S-%f")
    backup = TARGET.with_name(TARGET.name + ".bak-future-ui-" + timestamp)
    temporary = TARGET.with_name(TARGET.name + ".tmp-future-ui")
    try:
        backup.write_bytes(TARGET.read_bytes())
        temporary.write_text(source, encoding="utf-8")
        os.replace(temporary, TARGET)
    except OSError as exc:
        try:
            if temporary.exists():
                temporary.unlink()
        except OSError:
            pass
        print(f"ERRORE durante il salvataggio della patch: {exc}", file=sys.stderr)
        print(f"Backup originale (se creato): {backup}", file=sys.stderr)
        return 1

    print("Editor degli allenamenti futuri installato.")
    print(f"Backup del programma: {backup}")
    print("La patch aggiunge modifica, aggiunta, eliminazione e cambio data delle sedute.")
    print("Prossimo passo: python3 -m py_compile /opt/swim-coach/swim_coach_web.py")
    print("Poi: systemctl restart swim-coach-web.service")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
