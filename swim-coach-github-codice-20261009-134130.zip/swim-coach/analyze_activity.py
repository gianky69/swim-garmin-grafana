#!/usr/bin/env python3

import json
import sys
from pathlib import Path
from statistics import mean, median


DATA_DIR = Path("/opt/swim-coach/data")


# ============================================================
# FUNZIONI GENERALI
# ============================================================

def safe_mean(values):
    values = [
        float(v)
        for v in values
        if v is not None
    ]

    return mean(values) if values else None


def safe_median(values):
    values = [
        float(v)
        for v in values
        if v is not None
    ]

    return median(values) if values else None


def weighted_mean(items, value_key, weight_key):
    """
    Media ponderata.
    """
    pairs = []

    for item in items:
        value = item.get(value_key)
        weight = item.get(weight_key)

        if value is None or weight is None:
            continue

        try:
            value = float(value)
            weight = float(weight)
        except (TypeError, ValueError):
            continue

        if weight <= 0:
            continue

        pairs.append((value, weight))

    if not pairs:
        return None

    total_weight = sum(
        weight for _, weight in pairs
    )

    if total_weight <= 0:
        return None

    return sum(
        value * weight
        for value, weight in pairs
    ) / total_weight


def pace_per_100(elapsed_s, distance_m):
    """
    Restituisce il passo equivalente in secondi / 100 m.
    """
    if (
        elapsed_s is None
        or distance_m is None
        or elapsed_s <= 0
        or distance_m <= 0
    ):
        return None

    return (
        float(elapsed_s)
        / float(distance_m)
        * 100
    )


def format_time(seconds):
    if seconds is None:
        return "--:--"

    seconds = max(
        0,
        int(round(seconds))
    )

    minutes = seconds // 60
    secs = seconds % 60

    return f"{minutes}:{secs:02d}"


def format_pace(seconds):
    return format_time(seconds)


def percentage_change(first, last):
    """
    Variazione percentuale da first a last.
    """
    if (
        first is None
        or last is None
        or first == 0
    ):
        return None

    return (
        (last - first)
        / first
        * 100
    )


# ============================================================
# TREND
# ============================================================

def classify_pace_trend(first_pace, last_pace):
    """
    Per il passo:
      negativo = più veloce
      positivo = più lento
    """

    if (
        first_pace is None
        or last_pace is None
    ):
        return "unknown"

    delta = last_pace - first_pace

    if delta < -2:
        return "improving"

    if delta > 2:
        return "declining"

    return "stable"


def classify_efficiency_trend(first_strokes, last_strokes):
    """
    Meno bracciate a parità di velocità:
    indicativamente maggiore efficienza.

    Non viene considerata una misura assoluta della tecnica,
    ma solo un indicatore da leggere insieme al passo.
    """

    if (
        first_strokes is None
        or last_strokes is None
    ):
        return "unknown"

    delta = last_strokes - first_strokes

    if delta < -0.5:
        return "improving"

    if delta > 0.5:
        return "declining"

    return "stable"


# ============================================================
# NORMALIZZAZIONE LAP
# ============================================================

def normalize_lap(lap):
    """
    Trasforma il record prodotto da extract_activity.py
    in una struttura più adatta all'analisi.
    """

    distance = lap.get(
        "distance_m"
    )

    elapsed = lap.get(
        "elapsed_s"
    )

    records = lap.get(
        "length_records",
        []
    )

    strokes = [
        x.get("strokes")
        for x in records
        if (
            x.get("strokes") is not None
            and x.get("strokes") > 0
        )
    ]

    cadences = [
        x.get("avg_cadence")
        for x in records
        if (
            x.get("avg_cadence") is not None
            and x.get("avg_cadence") > 0
        )
    ]

    speeds = [
        x.get("avg_speed")
        for x in records
        if (
            x.get("avg_speed") is not None
            and x.get("avg_speed") > 0
        )
    ]

    styles = [
        x.get("swim_stroke")
        for x in records
        if x.get("swim_stroke")
    ]

    style_counts = {}

    for style in styles:
        style_counts[style] = (
            style_counts.get(style, 0)
            + 1
        )

    if len(style_counts) == 1:
        main_style = next(
            iter(style_counts)
        )

    elif len(style_counts) > 1:
        main_style = "mixed"

    else:
        main_style = None

    lengths = lap.get(
        "lengths"
    )

    return {
        "lap":
            lap.get("index"),

        "type":
            lap.get("type"),

        "distance_m":
            distance,

        "elapsed_s":
            elapsed,

        "pace_100_s":
            pace_per_100(
                elapsed,
                distance
            ),

        "lengths":
            lengths,

        "main_style":
            main_style,

        "style_counts":
            style_counts,

        "avg_strokes_per_length":
            safe_mean(strokes),

        "avg_cadence":
            safe_mean(cadences),

        "avg_speed_m_s":
            safe_mean(speeds),

        "total_strokes":
            sum(strokes)
            if strokes
            else None,

        "length_records":
            records,
    }


# ============================================================
# RECUPERI
# ============================================================

def merge_consecutive_rests(laps):
    """
    Garmin può spezzare un unico recupero in più ActivityLap.

    Esempio:

        5 s
        5 s

    viene trasformato in:

        10 s
    """

    merged = []

    for lap in laps:

        if (
            lap.get("type") == "rest"
            and merged
            and merged[-1].get("type") == "rest"
        ):
            previous = merged[-1]

            previous["elapsed_s"] = (
                (previous.get("elapsed_s") or 0)
                + (lap.get("elapsed_s") or 0)
            )

        else:
            merged.append(
                dict(lap)
            )

    return merged


def add_rest_before(laps):
    """
    Associa ad ogni ripetuta il recupero
    immediatamente precedente.
    """

    previous_rest = None

    for lap in laps:

        if lap["type"] == "rest":

            previous_rest = (
                lap.get("elapsed_s")
            )

        elif lap["type"] == "swim":

            lap["rest_before_s"] = (
                previous_rest
            )

            previous_rest = None

        else:

            previous_rest = None

    return laps


# ============================================================
# RICONOSCIMENTO SERIE
# ============================================================

def build_series(laps):
    """
    Raggruppa ripetute della stessa distanza.

    I recuperi non interrompono la serie.

    Esempi:

        100 - REC - 100 - REC - 100 - REC - 100
        -> 4 x 100

        75 - REC - 75 - REC - 75
        -> 3 x 75

    Una variazione di distanza chiude il blocco.
    """

    blocks = []

    current = []

    def flush_current():

        nonlocal current

        if not current:
            return

        if len(current) == 1:

            blocks.append({
                "type":
                    "single",

                "repetitions":
                    1,

                "distance_m":
                    current[0][
                        "distance_m"
                    ],

                "laps":
                    current,
            })

        else:

            distances = {
                lap["distance_m"]
                for lap in current
            }

            if len(distances) == 1:

                blocks.append({
                    "type":
                        "series",

                    "repetitions":
                        len(current),

                    "distance_m":
                        current[0][
                            "distance_m"
                        ],

                    "laps":
                        current,
                })

            else:

                blocks.append({
                    "type":
                        "mixed_series",

                    "repetitions":
                        len(current),

                    "distance_m":
                        None,

                    "laps":
                        current,
                })

        current = []

    for lap in laps:

        if lap["type"] == "swim":

            if not current:

                current = [lap]

                continue

            current_distance = (
                current[0][
                    "distance_m"
                ]
            )

            new_distance = (
                lap["distance_m"]
            )

            if new_distance == current_distance:

                current.append(lap)

            else:

                flush_current()

                current = [lap]

        elif lap["type"] == "rest":

            # Il recupero separa le ripetute,
            # ma NON chiude la serie.
            continue

        else:

            flush_current()

    flush_current()

    return blocks


# ============================================================
# ANALISI DEL BLOCCO
# ============================================================

def analyze_block(block):

    laps = block["laps"]

    distances = [
        lap["distance_m"]
        for lap in laps
        if lap["distance_m"] is not None
    ]

    times = [
        lap["elapsed_s"]
        for lap in laps
        if lap["elapsed_s"] is not None
    ]

    paces = [
        lap["pace_100_s"]
        for lap in laps
        if lap["pace_100_s"] is not None
    ]

    strokes = [
        lap[
            "avg_strokes_per_length"
        ]
        for lap in laps
        if lap[
            "avg_strokes_per_length"
        ] is not None
    ]

    cadences = [
        lap["avg_cadence"]
        for lap in laps
        if lap["avg_cadence"] is not None
    ]

    speeds = [
        lap["avg_speed_m_s"]
        for lap in laps
        if lap["avg_speed_m_s"] is not None
    ]

    styles = {}

    for lap in laps:

        for style, count in lap[
            "style_counts"
        ].items():

            styles[style] = (
                styles.get(style, 0)
                + count
            )

    repetitions = len(laps)

    total_distance = sum(
        distances
    )

    total_swim_time = sum(
        times
    )

    average_pace = (
        total_swim_time
        / total_distance
        * 100
        if total_distance
        else None
    )

    average_strokes = (
        safe_mean(strokes)
        if strokes
        else None
    )

    average_cadence = (
        safe_mean(cadences)
        if cadences
        else None
    )

    average_speed = (
        safe_mean(speeds)
        if speeds
        else None
    )

    first_pace = (
        paces[0]
        if paces
        else None
    )

    last_pace = (
        paces[-1]
        if paces
        else None
    )

    first_strokes = (
        strokes[0]
        if strokes
        else None
    )

    last_strokes = (
        strokes[-1]
        if strokes
        else None
    )

    pace_delta = None

    if (
        first_pace is not None
        and last_pace is not None
    ):
        pace_delta = (
            last_pace - first_pace
        )

    strokes_delta = None

    if (
        first_strokes is not None
        and last_strokes is not None
    ):
        strokes_delta = (
            last_strokes
            - first_strokes
        )

    pace_trend = (
        classify_pace_trend(
            first_pace,
            last_pace
        )
    )

    efficiency_trend = (
        classify_efficiency_trend(
            first_strokes,
            last_strokes
        )
    )

    # Recuperi tra le ripetute.
    rest_between = []

    for lap in laps[1:]:

        rest = lap.get(
            "rest_before_s"
        )

        if rest is not None:

            rest_between.append(
                rest
            )

    average_rest = (
        safe_mean(rest_between)
    )

    # Etichetta leggibile.
    if block["type"] == "series":

        label = (
            f"{repetitions} × "
            f"{int(block['distance_m'])} m"
        )

    elif block["type"] == "single":

        label = (
            f"{int(block['distance_m'])} m"
        )

    else:

        label = "Serie mista"

    # Stile principale.
    if styles:

        dominant_style = max(
            styles,
            key=styles.get
        )

    else:

        dominant_style = None

    return {
        "type":
            block["type"],

        "label":
            label,

        "repetitions":
            repetitions,

        "distance_per_rep_m":
            block["distance_m"],

        "total_distance_m":
            total_distance,

        "total_swim_time_s":
            total_swim_time,

        "average_pace_100_s":
            average_pace,

        "average_pace_100":
            format_pace(
                average_pace
            ),

        "first_pace_100_s":
            first_pace,

        "last_pace_100_s":
            last_pace,

        "pace_delta_s_per_100":
            pace_delta,

        "pace_change_percent":
            percentage_change(
                first_pace,
                last_pace
            ),

        "pace_trend":
            pace_trend,

        "first_strokes_per_length":
            first_strokes,

        "last_strokes_per_length":
            last_strokes,

        "strokes_delta":
            strokes_delta,

        "efficiency_trend":
            efficiency_trend,

        "avg_strokes_per_length":
            average_strokes,

        "avg_cadence":
            average_cadence,

        "avg_speed_m_s":
            average_speed,

        "dominant_style":
            dominant_style,

        "styles":
            styles,

        "average_rest_between_reps_s":
            average_rest,

        "repetitions_detail": [
            {
                "lap":
                    lap["lap"],

                "distance_m":
                    lap[
                        "distance_m"
                    ],

                "elapsed_s":
                    lap[
                        "elapsed_s"
                    ],

                "time":
                    format_time(
                        lap["elapsed_s"]
                    ),

                "pace_100_s":
                    lap[
                        "pace_100_s"
                    ],

                "pace_100":
                    format_pace(
                        lap[
                            "pace_100_s"
                        ]
                    ),

                "strokes_per_length":
                    lap[
                        "avg_strokes_per_length"
                    ],

                "cadence":
                    lap[
                        "avg_cadence"
                    ],

                "style":
                    lap[
                        "main_style"
                    ],

                "styles":
                    lap[
                        "style_counts"
                    ],

                "rest_before_s":
                    lap.get(
                        "rest_before_s"
                    ),
            }
            for lap in laps
        ],
    }


# ============================================================
# CLASSIFICAZIONE DELLE FASI
# ============================================================

def classify_phases(blocks):
    """
    Classificazione euristica delle fasi dell'allenamento.

    IMPORTANTE:
    non pretende di sapere cosa fosse realmente programmato.

    Restituisce:
        warmup
        main_set
        cooldown

    con livello di confidence.

    La logica è volutamente conservativa.
    """

    if not blocks:
        return blocks

    # Passi dei blocchi.
    block_paces = [
        block.get(
            "average_pace_100_s"
        )
        for block in blocks
        if block.get(
            "average_pace_100_s"
        ) is not None
    ]

    reference_pace = (
        median(block_paces)
        if block_paces
        else None
    )

    for block in blocks:

        block["phase"] = "main_set"
        block["phase_confidence"] = 0.50

    # --------------------------------------------------------
    # WARMUP
    # --------------------------------------------------------

    # Guardiamo solo i primi blocchi.
    warmup_candidates = []

    for index, block in enumerate(
        blocks[:3]
    ):

        pace = block.get(
            "average_pace_100_s"
        )

        styles = block.get(
            "styles",
            {}
        )

        repetitions = block.get(
            "repetitions",
            1
        )

        distance = block.get(
            "total_distance_m"
        ) or 0

        mixed_style = (
            len(styles) > 1
        )

        slower_than_reference = (
            reference_pace is not None
            and pace is not None
            and pace
            >= reference_pace * 1.08
        )

        if (
            index == 0
            and (
                mixed_style
                or slower_than_reference
                or repetitions <= 2
            )
        ):
            warmup_candidates.append(
                (index, 0.85)
            )

        elif (
            index == 1
            and warmup_candidates
            and (
                mixed_style
                or slower_than_reference
            )
        ):
            warmup_candidates.append(
                (index, 0.70)
            )

    for index, confidence in (
        warmup_candidates
    ):

        blocks[index][
            "phase"
        ] = "warmup"

        blocks[index][
            "phase_confidence"
        ] = confidence

    # --------------------------------------------------------
    # MAIN SET
    # --------------------------------------------------------

    for block in blocks:

        if block["phase"] == "main_set":

            repetitions = block.get(
                "repetitions",
                1
            )

            pace = block.get(
                "average_pace_100_s"
            )

            # Serie ripetute con almeno 3 reps:
            # forte indicatore di serie di lavoro.
            if repetitions >= 3:

                block[
                    "phase_confidence"
                ] = 0.85

            elif (
                reference_pace is not None
                and pace is not None
                and pace
                <= reference_pace * 1.02
            ):

                block[
                    "phase_confidence"
                ] = 0.70

    # --------------------------------------------------------
    # COOLDOWN
    # --------------------------------------------------------

    # Partiamo dalla fine.
    for reverse_index in range(
        len(blocks) - 1,
        max(-1, len(blocks) - 3),
        -1
    ):

        block = blocks[
            reverse_index
        ]

        pace = block.get(
            "average_pace_100_s"
        )

        repetitions = block.get(
            "repetitions",
            1
        )

        styles = block.get(
            "styles",
            {}
        )

        mixed_style = (
            len(styles) > 1
        )

        slower_than_reference = (
            reference_pace is not None
            and pace is not None
            and pace
            >= reference_pace * 1.08
        )

        # Per essere classificato cooldown:
        # deve essere finale e chiaramente più lento
        # oppure composto da stile misto.
        if (
            slower_than_reference
            or (
                mixed_style
                and reverse_index
                >= len(blocks) - 2
            )
        ):

            # Non sovrascrivere un warmup.
            if block["phase"] != "warmup":

                block[
                    "phase"
                ] = "cooldown"

                block[
                    "phase_confidence"
                ] = 0.75

    # --------------------------------------------------------
    # CORREZIONE:
    # se abbiamo classificato tutto cooldown,
    # lasciamo almeno una parte centrale come main_set.
    # --------------------------------------------------------

    phase_names = {
        block["phase"]
        for block in blocks
    }

    if (
        "main_set" not in phase_names
        and len(blocks) >= 3
    ):

        middle = len(blocks) // 2

        blocks[middle][
            "phase"
        ] = "main_set"

        blocks[middle][
            "phase_confidence"
        ] = 0.55

    return blocks


# ============================================================
# VALUTAZIONE GENERALE
# ============================================================

def evaluate_session(result):
    """
    Produce indicatori generali utili al futuro Swim Coach.

    Non è ancora un coaching AI:
    prepara solamente una valutazione quantitativa.
    """

    blocks = result.get(
        "blocks",
        []
    )

    if not blocks:

        return {
            "pace_assessment":
                "unknown",

            "efficiency_assessment":
                "unknown",

            "fatigue_assessment":
                "unknown",

            "notes": [],
        }

    notes = []

    # --------------------------------------------------------
    # Analisi serie principali
    # --------------------------------------------------------

    main_blocks = [
        block
        for block in blocks
        if block.get(
            "phase"
        ) == "main_set"
    ]

    declining_blocks = [
        block
        for block in main_blocks
        if block.get(
            "pace_trend"
        ) == "declining"
    ]

    improving_blocks = [
        block
        for block in main_blocks
        if block.get(
            "pace_trend"
        ) == "improving"
    ]

    # --------------------------------------------------------
    # Passo
    # --------------------------------------------------------

    if declining_blocks:

        pace_assessment = (
            "some_decline"
        )

        notes.append(
            "Una o più serie principali "
            "mostrano rallentamento "
            "tra prima e ultima ripetuta."
        )

    elif improving_blocks:

        pace_assessment = (
            "improving"
        )

        notes.append(
            "Almeno una serie principale "
            "mostra una progressione positiva "
            "del passo."
        )

    else:

        pace_assessment = (
            "stable"
        )

    # --------------------------------------------------------
    # Efficienza
    # --------------------------------------------------------

    efficiency_declining = [
        block
        for block in main_blocks
        if block.get(
            "efficiency_trend"
        ) == "declining"
    ]

    efficiency_improving = [
        block
        for block in main_blocks
        if block.get(
            "efficiency_trend"
        ) == "improving"
    ]

    if efficiency_declining:

        efficiency_assessment = (
            "declining"
        )

        notes.append(
            "In alcune serie il numero "
            "di bracciate per lunghezza "
            "aumenta insieme al peggioramento "
            "del ritmo."
        )

    elif efficiency_improving:

        efficiency_assessment = (
            "improving"
        )

        notes.append(
            "Alcune serie mostrano "
            "un miglioramento dell'efficienza "
            "misurata dalle bracciate per lunghezza."
        )

    else:

        efficiency_assessment = (
            "stable"
        )

    # --------------------------------------------------------
    # Fatica
    # --------------------------------------------------------

    summary = result.get(
        "activity",
        {}
    )

    avg_hr = summary.get(
        "avg_hr"
    )

    max_hr = summary.get(
        "max_hr"
    )

    # Per ora non deduciamo la fatica solo dalla FC.
    # Usiamo soprattutto il rapporto:
    # rallentamento + aumento bracciate.
    fatigue_indicators = (
        len(declining_blocks)
        + len(efficiency_declining)
    )

    if fatigue_indicators >= 2:

        fatigue_assessment = (
            "possible_fatigue"
        )

        notes.append(
            "Sono presenti indicatori "
            "compatibili con affaticamento "
            "tecnico/di ritmo. "
            "Da verificare con lo storico."
        )

    elif fatigue_indicators == 1:

        fatigue_assessment = (
            "mild"
        )

    else:

        fatigue_assessment = (
            "low"
        )

    return {
        "pace_assessment":
            pace_assessment,

        "efficiency_assessment":
            efficiency_assessment,

        "fatigue_assessment":
            fatigue_assessment,

        "avg_hr":
            avg_hr,

        "max_hr":
            max_hr,

        "notes":
            notes,
    }


# ============================================================
# ANALISI ATTIVITÀ
# ============================================================

def analyze_activity(data):

    summary = (
        data.get("summary")
        or {}
    )

    session = (
        data.get("session")
        or {}
    )

    raw_laps = (
        data.get("laps")
        or []
    )

    # Normalizzazione.
    laps = [
        normalize_lap(lap)
        for lap in raw_laps
    ]

    # Recuperi consecutivi.
    laps = merge_consecutive_rests(
        laps
    )

    # Recupero precedente.
    laps = add_rest_before(
        laps
    )

    # Serie.
    blocks = build_series(
        laps
    )

    analyzed_blocks = [
        analyze_block(block)
        for block in blocks
    ]

    # Fasi.
    analyzed_blocks = classify_phases(
        analyzed_blocks
    )

    # --------------------------------------------------------
    # Metriche globali
    # --------------------------------------------------------

    swim_laps = [
        lap
        for lap in laps
        if lap["type"] == "swim"
    ]

    all_distances = [
        lap["distance_m"]
        for lap in swim_laps
        if lap["distance_m"] is not None
    ]

    all_times = [
        lap["elapsed_s"]
        for lap in swim_laps
        if lap["elapsed_s"] is not None
    ]

    distance_from_laps = sum(
        all_distances
    )

    moving_from_laps = sum(
        all_times
    )

    avg_pace = (
        moving_from_laps
        / distance_from_laps
        * 100
        if distance_from_laps
        else None
    )

    # --------------------------------------------------------
    # Stili complessivi
    # --------------------------------------------------------

    style_counts = {}

    for lap in swim_laps:

        for style, count in lap[
            "style_counts"
        ].items():

            style_counts[style] = (
                style_counts.get(
                    style,
                    0
                )
                + count
            )

    # --------------------------------------------------------
    # Efficienza globale
    # --------------------------------------------------------

    avg_strokes = weighted_mean(
        [
            {
                "value":
                    lap.get(
                        "avg_strokes_per_length"
                    ),

                "weight":
                    lap.get(
                        "lengths"
                    ) or 0,
            }
            for lap in swim_laps
        ],
        "value",
        "weight",
    )

    avg_cadence = safe_mean(
        [
            lap.get(
                "avg_cadence"
            )
            for lap in swim_laps
            if lap.get(
                "avg_cadence"
            ) is not None
        ]
    )

    avg_speed = safe_mean(
        [
            lap.get(
                "avg_speed_m_s"
            )
            for lap in swim_laps
            if lap.get(
                "avg_speed_m_s"
            ) is not None
        ]
    )

    # --------------------------------------------------------
    # Distanza per fase
    # --------------------------------------------------------

    phase_distance = {
        "warmup": 0,
        "main_set": 0,
        "cooldown": 0,
    }

    for block in analyzed_blocks:

        phase = block.get(
            "phase"
        )

        distance = (
            block.get(
                "total_distance_m"
            )
            or 0
        )

        if phase in phase_distance:

            phase_distance[
                phase
            ] += distance

    result = {

        "analysis_version":
            "3.0",

        "activity_id":
            data.get(
                "activity_id"
            ),

        "activity": {
            "name":
                summary.get(
                    "activityName"
                ),

            "type":
                summary.get(
                    "activityType"
                ),

            "distance_m":
                summary.get(
                    "distance"
                ),

            "elapsed_s":
                summary.get(
                    "elapsedDuration"
                ),

            "moving_s":
                summary.get(
                    "movingDuration"
                ),

            "avg_hr":
                summary.get(
                    "averageHR"
                ),

            "max_hr":
                summary.get(
                    "maxHR"
                ),

            "training_load":
                summary.get(
                    "activityTrainingLoad"
                ),

            "aerobic_training_effect":
                summary.get(
                    "aerobicTrainingEffect"
                ),

            "anaerobic_training_effect":
                summary.get(
                    "anaerobicTrainingEffect"
                ),

            "calories":
                summary.get(
                    "calories"
                ),
        },

        "pool": {
            "length_m":
                session.get(
                    "Pool_Length"
                ),

            "length_unit":
                session.get(
                    "Pool_Length_Unit"
                ),

            "device":
                session.get(
                    "Device"
                ),
        },

        "derived": {

            "distance_from_laps_m":
                distance_from_laps,

            "moving_time_from_laps_s":
                moving_from_laps,

            "avg_pace_100_s":
                avg_pace,

            "avg_pace_100":
                format_pace(
                    avg_pace
                ),

            "avg_strokes_per_length":
                avg_strokes,

            "avg_cadence":
                avg_cadence,

            "avg_speed_m_s":
                avg_speed,

            "styles":
                style_counts,

            "swim_laps":
                len(swim_laps),

            "blocks":
                len(analyzed_blocks),

            "distance_by_phase_m":
                phase_distance,
        },

        "blocks":
            analyzed_blocks,

        "evaluation":
            {},

        "laps":
            laps,
    }

    # Valutazione finale.
    result[
        "evaluation"
    ] = evaluate_session(
        result
    )

    return result


# ============================================================
# STAMPA REPORT
# ============================================================

def print_report(result):

    activity = result[
        "activity"
    ]

    derived = result[
        "derived"
    ]

    pool = result[
        "pool"
    ]

    evaluation = result[
        "evaluation"
    ]

    print()

    print(
        "=" * 100
    )

    print(
        "ANALISI ATTIVITÀ NUOTO - V3"
    )

    print(
        "=" * 100
    )

    print(
        f"Nome:       "
        f"{activity.get('name')}"
    )

    print(
        f"ActivityID: "
        f"{result.get('activity_id')}"
    )

    print(
        f"Distanza:   "
        f"{activity.get('distance_m')} m"
    )

    print(
        f"Piscina:    "
        f"{pool.get('length_m')} m"
    )

    print(
        f"Durata:     "
        f"{format_time(activity.get('elapsed_s'))}"
    )

    print(
        f"Nuoto:      "
        f"{format_time(activity.get('moving_s'))}"
    )

    print(
        f"FC media:   "
        f"{activity.get('avg_hr')} bpm"
    )

    print(
        f"FC max:     "
        f"{activity.get('max_hr')} bpm"
    )

    print(
        f"Training:   "
        f"{activity.get('training_load')}"
    )

    print(
        f"Aerobico:   "
        f"{activity.get('aerobic_training_effect')}"
    )

    print(
        f"Anaerobico: "
        f"{activity.get('anaerobic_training_effect')}"
    )

    print()

    print(
        "METRICHE DERIVATE"
    )

    print(
        "-" * 100
    )

    print(
        f"Passo medio:       "
        f"{derived.get('avg_pace_100')}/100 m"
    )

    if derived.get(
        "avg_strokes_per_length"
    ) is not None:

        print(
            "Bracciate/25 m:    "
            f"{derived['avg_strokes_per_length']:.1f}"
        )

    if derived.get(
        "avg_cadence"
    ) is not None:

        print(
            "Cadenza media:     "
            f"{derived['avg_cadence']:.1f} "
            "bracciate/min"
        )

    if derived.get(
        "avg_speed_m_s"
    ) is not None:

        print(
            "Velocità media:    "
            f"{derived['avg_speed_m_s']:.3f} m/s"
        )

    print(
        f"Lap di nuoto:      "
        f"{derived.get('swim_laps')}"
    )

    print(
        f"Blocchi:           "
        f"{derived.get('blocks')}"
    )

    print(
        "Stili:              "
        + ", ".join(
            f"{style}={count}"
            for style, count
            in derived.get(
                "styles",
                {}
            ).items()
        )
    )

    print()

    print(
        "DISTANZA PER FASE"
    )

    print(
        "-" * 100
    )

    for phase, distance in (
        derived.get(
            "distance_by_phase_m",
            {}
        ).items()
    ):

        print(
            f"{phase:<12} "
            f"{distance:.0f} m"
        )

    print()

    print(
        "BLOCCHI / SERIE"
    )

    print(
        "-" * 100
    )

    for number, block in enumerate(
        result["blocks"],
        start=1
    ):

        phase = block.get(
            "phase",
            "main_set"
        )

        confidence = (
            block.get(
                "phase_confidence"
            ) or 0
        )

        print()

        print(
            f"{number}. "
            f"{block['label']}"
            f"  [{phase}, "
            f"confidence={confidence:.2f}]"
        )

        print(
            f"   Distanza totale: "
            f"{block['total_distance_m']:.0f} m"
        )

        print(
            f"   Passo medio:     "
            f"{block['average_pace_100']}/100 m"
        )

        if block.get(
            "average_rest_between_reps_s"
        ) is not None:

            print(
                f"   Recupero medio:  "
                f"{format_time(block['average_rest_between_reps_s'])}"
            )

        if block.get(
            "avg_strokes_per_length"
        ) is not None:

            print(
                f"   Bracciate/25:    "
                f"{block['avg_strokes_per_length']:.1f}"
            )

        if block.get(
            "avg_cadence"
        ) is not None:

            print(
                f"   Cadenza:         "
                f"{block['avg_cadence']:.1f}"
            )

        print(
            f"   Stili:           "
            + ", ".join(
                f"{style}={count}"
                for style, count
                in block.get(
                    "styles",
                    {}
                ).items()
            )
        )

        print(
            f"   Trend passo:     "
            f"{block.get('pace_trend')}"
        )

        print(
            f"   Trend efficienza:"
            f" {block.get('efficiency_trend')}"
        )

        if block.get(
            "pace_delta_s_per_100"
        ) is not None:

            print(
                f"   Δ passo:         "
                f"{block['pace_delta_s_per_100']:+.1f} s/100"
            )

        if block.get(
            "strokes_delta"
        ) is not None:

            print(
                f"   Δ br/25:         "
                f"{block['strokes_delta']:+.1f}"
            )

        print()

        for rep in block[
            "repetitions_detail"
        ]:

            strokes = rep.get(
                "strokes_per_length"
            )

            cadence = rep.get(
                "cadence"
            )

            strokes_text = (
                f"{strokes:.1f}"
                if strokes is not None
                else "--"
            )

            cadence_text = (
                f"{cadence:.0f}"
                if cadence is not None
                else "--"
            )

            print(
                f"      Lap {rep['lap']:>2}: "
                f"{rep['distance_m']:>4.0f} m  "
                f"{rep['time']:>5}  "
                f"{rep['pace_100']:>5}/100  "
                f"{strokes_text:>4} br/25  "
                f"{cadence_text:>3} br/min  "
                f"{rep['style'] or '--'}"
            )

    print()

    print(
        "VALUTAZIONE AUTOMATICA"
    )

    print(
        "-" * 100
    )

    print(
        f"Passo:       "
        f"{evaluation.get('pace_assessment')}"
    )

    print(
        f"Efficienza:  "
        f"{evaluation.get('efficiency_assessment')}"
    )

    print(
        f"Fatica:      "
        f"{evaluation.get('fatigue_assessment')}"
    )

    for note in evaluation.get(
        "notes",
        []
    ):

        print(
            f"  - {note}"
        )

    print()

    print(
        "=" * 100
    )


# ============================================================
# MAIN
# ============================================================

def main():

    if len(sys.argv) != 2:

        print(
            f"Uso: {sys.argv[0]} ACTIVITY_ID"
        )

        print(
            "Esempio:"
        )

        print(
            f"  {sys.argv[0]} 24539708008"
        )

        sys.exit(1)

    activity_id = sys.argv[1]

    input_file = (
        DATA_DIR
        / f"{activity_id}.json"
    )

    if not input_file.exists():

        print(
            f"ERRORE: file non trovato: "
            f"{input_file}",
            file=sys.stderr
        )

        print()

        print(
            "Prima esegui:"
        )

        print(
            f"  extract_activity.py "
            f"{activity_id}"
        )

        sys.exit(2)

    try:

        with input_file.open(
            "r",
            encoding="utf-8"
        ) as f:

            data = json.load(f)

        result = analyze_activity(
            data
        )

    except Exception as exc:

        print(
            f"ERRORE: {exc}",
            file=sys.stderr
        )

        sys.exit(3)

    output_file = (
        DATA_DIR
        / f"{activity_id}_analysis.json"
    )

    with output_file.open(
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            result,
            f,
            ensure_ascii=False,
            indent=2
        )

    print_report(
        result
    )

    print()

    print(
        f"JSON analisi: "
        f"{output_file}"
    )


if __name__ == "__main__":
    main()
