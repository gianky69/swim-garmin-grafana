#!/usr/bin/env python3
"""Generate a local Swim Coach workout report from swim_profile.json.

This first-stage report is read-only: it never modifies Garmin data or
corrections.json. It writes plain-text and HTML reports for the latest
activity (or an explicitly selected activity) and compares recent sessions.
"""
from __future__ import annotations

import argparse
import html
import json
import statistics
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any

BASE_DIR = Path("/opt/swim-coach")
DATA_FILE = BASE_DIR / "data" / "swim_profile.json"
REPORT_DIR = BASE_DIR / "reports"

CLASS_LABELS = {
    "normal_swim": "Normale",
    "possible_special": "Speciale / da verificare",
    "artifact": "Artefatto escluso",
}
STYLE_LABELS = {
    "freestyle": "Stile libero",
    "backstroke": "Dorso",
    "breaststroke": "Rana",
    "butterfly": "Delfino",
    "mixed": "Misto",
    "unknown": "Sconosciuto",
}
EQUIPMENT_LABELS = {
    "none": "Senza attrezzatura",
    "fins": "Pinne",
    "pull_buoy": "Pull buoy",
    "paddles": "Palette",
    "kickboard": "Tavoletta",
    "other": "Attrezzatura mista/da verificare",
    "auto": "Automatico",
}


def number(value: Any, default: float = 0.0) -> float:
    try:
        value = float(value)
        if value != value or value in (float("inf"), float("-inf")):
            return default
        return value
    except (TypeError, ValueError):
        return default


def time_label(seconds: Any) -> str:
    value = number(seconds, -1)
    if value < 0:
        return "—"
    total = int(round(value))
    hours, rem = divmod(total, 3600)
    minutes, secs = divmod(rem, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes}:{secs:02d}"


def pace_label(seconds: Any, distance: Any) -> str:
    d = number(distance)
    t = number(seconds, -1)
    if d <= 0 or t < 0:
        return "—"
    return time_label(t * 100 / d) + "/100 m"


def safe_text(value: Any, fallback: str = "—") -> str:
    if value is None or str(value).strip() == "":
        return fallback
    return str(value)


def load_profile(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        profile = json.load(handle)
    if not isinstance(profile, dict):
        raise ValueError("Il profilo JSON non contiene un oggetto valido.")
    return profile


def get_records(profile: dict) -> list[dict]:
    # Coaching observations include manual corrections and manual merges.
    # The UI observations are retained separately and must not be used here.
    rows = profile.get("coaching_observations")
    if not isinstance(rows, list):
        rows = profile.get("all_observations", [])
    return [row for row in rows if isinstance(row, dict)]


def group_by_activity(records: list[dict]) -> dict[str, list[dict]]:
    groups: dict[str, list[dict]] = defaultdict(list)
    for row in records:
        aid = str(row.get("activity_id", "")).strip()
        if aid:
            groups[aid].append(row)
    for rows in groups.values():
        rows.sort(key=lambda r: number(r.get("lap"), 0))
    return dict(groups)


def activity_date(rows: list[dict]) -> str:
    dates = [str(r.get("date")) for r in rows if r.get("date")]
    return max(dates) if dates else ""


def activity_name(rows: list[dict], aid: str) -> str:
    for row in rows:
        name = row.get("activity_name")
        if name:
            return str(name)
    return f"Attività {aid}"


def activity_summary(rows: list[dict]) -> dict:
    active = [r for r in rows if r.get("classification") != "artifact"]
    normal = [r for r in active if r.get("classification", "normal_swim") == "normal_swim"]
    special = [r for r in active if r.get("classification") == "possible_special"]
    total_distance = sum(max(0.0, number(r.get("distance_m"))) for r in active)
    total_time = sum(max(0.0, number(r.get("elapsed_s"))) for r in active)
    normal_distance = sum(max(0.0, number(r.get("distance_m"))) for r in normal)
    normal_time = sum(max(0.0, number(r.get("elapsed_s"))) for r in normal)
    special_distance = sum(max(0.0, number(r.get("distance_m"))) for r in special)
    special_time = sum(max(0.0, number(r.get("elapsed_s"))) for r in special)
    return {
        "distance": total_distance,
        "time": total_time,
        "pace": pace_label(total_time, total_distance),
        "normal_count": len(normal),
        "normal_distance": normal_distance,
        "normal_time": normal_time,
        "special_count": len(special),
        "special_distance": special_distance,
        "special_time": special_time,
        "artifact_count": sum(1 for r in rows if r.get("classification") == "artifact"),
        "merged_count": sum(1 for r in active if r.get("merged")),
        "corrected_count": sum(1 for r in active if r.get("correction_applied")),
    }


def get_selected_activity(groups: dict[str, list[dict]], requested_id: str | None) -> tuple[str, list[dict]]:
    if requested_id:
        if requested_id not in groups:
            raise ValueError(f"Attività {requested_id} non trovata in coaching_observations.")
        return requested_id, groups[requested_id]
    candidates = list(groups.items())
    if not candidates:
        raise ValueError("Non ci sono attività nelle osservazioni del profilo.")
    candidates.sort(key=lambda item: (activity_date(item[1]), item[0]), reverse=True)
    return candidates[0]


def make_history(groups: dict[str, list[dict]], selected_id: str, limit: int = 6) -> list[dict]:
    results = []
    for aid, rows in groups.items():
        results.append({
            "id": aid,
            "date": activity_date(rows),
            "name": activity_name(rows, aid),
            "summary": activity_summary(rows),
        })
    results.sort(key=lambda item: (item["date"], item["id"]), reverse=True)
    selected = next((i for i, item in enumerate(results) if item["id"] == selected_id), None)
    if selected is not None:
        # Keep the selected workout first in the comparison list.
        results = results[selected:] + results[:selected]
    return results[:limit]


def lap_display(row: dict) -> tuple[str, str, str, str, str, str, str]:
    lap = safe_text(row.get("lap"))
    if row.get("merged"):
        sources = row.get("merged_source_laps") or []
        lap = " + ".join(str(x) for x in sources) if sources else lap
    if row.get("session_merged"):
        source_name = safe_text(row.get("source_activity_name"), safe_text(row.get("source_activity_id"), "registrazione"))
        source_lap = row.get("source_lap", lap)
        if row.get("merged"):
            original_sources = row.get("merged_source_laps") or []
            if original_sources:
                source_lap = "+".join(str(x) for x in original_sources)
        lap = f"{source_name} · lap {source_lap}"
    distance = f"{number(row.get('distance_m')):g} m"
    elapsed = time_label(row.get("elapsed_s"))
    pace = pace_label(row.get("elapsed_s"), row.get("distance_m"))
    style = STYLE_LABELS.get(str(row.get("style", "unknown")), str(row.get("style", "unknown")))
    equipment = EQUIPMENT_LABELS.get(str(row.get("equipment", "none")), str(row.get("equipment", "none")))
    classification = CLASS_LABELS.get(str(row.get("classification", "normal_swim")), str(row.get("classification", "unknown")))
    return lap, distance, elapsed, pace, style, equipment, classification


def profile_reference(profile: dict) -> dict | None:
    try:
        item = profile["profiles"]["freestyle"]["none"]["distances"]["100"]
        return {
            "n": item.get("n"),
            "median": item.get("median_pace_sec100"),
            "recent": item.get("recent_median_pace_sec100"),
            "trend": item.get("trend"),
            "confidence": item.get("confidence"),
        }
    except (KeyError, TypeError):
        return None


def build_report(profile: dict, records: list[dict], aid: str, rows: list[dict], groups: dict[str, list[dict]]) -> tuple[str, str]:
    date = activity_date(rows) or "Data non disponibile"
    name = activity_name(rows, aid)
    summary = activity_summary(rows)
    history = make_history(groups, aid)
    generated = datetime.now().astimezone().strftime("%Y-%m-%d %H:%M %Z")
    ref = profile_reference(profile)

    lines = [
        "SWIM COACH — REPORT ALLENAMENTO",
        "=" * 37,
        f"Data allenamento: {date}",
        f"Attività: {name} (ID {aid})",
        f"Report generato: {generated}",
        *(["Registrazioni Garmin unite: " + ", ".join(str(x) for x in next((r.get("session_source_ids", []) for r in rows if r.get("session_merged")), []))] if any(r.get("session_merged") for r in rows) else []),
        "",
        "RIEPILOGO CORRETTO",
        f"Distanza registrata (lap validi): {summary['distance']:.0f} m",
        f"Tempo sommato dei lap validi: {time_label(summary['time'])}",
        f"Passo medio calcolato sui lap validi: {summary['pace']}",
        f"Lap normali: {summary['normal_count']} ({summary['normal_distance']:.0f} m; {time_label(summary['normal_time'])})",
        f"Lap speciali/da verificare: {summary['special_count']} ({summary['special_distance']:.0f} m; {time_label(summary['special_time'])})",
        f"Lap esclusi come artefatti: {summary['artifact_count']}",
        f"Ripetute unite: {summary['merged_count']}",
        f"Registrazioni unite nella stessa seduta: {'sì' if any(row.get('session_merged') for row in rows) else 'no'}",
        "",
        "NOTA SUI TEMPI",
        "Il tempo riportato è la somma dei tempi dei lap disponibili, non necessariamente il tempo totale trascorso della seduta: le pause possono non essere rappresentate nei lap.",
        "I lap classificati come speciali sono conteggiati nel riepilogo della seduta, ma vengono separati dai lap normali e non vanno automaticamente usati come riferimento di velocità.",
        "",
        "DETTAGLIO LAP",
        "Lap sorgente | Distanza | Tempo | Passo/100 m | Stile | Attrezzatura | Classificazione",
        "-" * 105,
    ]
    for row in rows:
        lap, distance, elapsed, pace, style, equipment, classification = lap_display(row)
        reason = row.get("special_reason") if row.get("classification") == "possible_special" else None
        if row.get("merged"):
            lap = f"{lap} (UNIONE)"
        suffix = f" — motivo: {reason}" if reason else ""
        lines.append(f"{lap} | {distance} | {elapsed} | {pace} | {style} | {equipment} | {classification}{suffix}")

    lines.extend(["", "CONFRONTO CON LE SEDUTE RECENTI", "Data | Distanza corretta | Tempo lap | Passo medio | Speciali | Unioni", "-" * 80])
    for item in history:
        s = item["summary"]
        marker = " ← seduta del report" if item["id"] == aid else ""
        lines.append(f"{item['date'] or '—'} | {s['distance']:.0f} m | {time_label(s['time'])} | {s['pace']} | {s['special_count']} | {s['merged_count']}{marker}")

    lines.extend(["", "RIFERIMENTO STORICO: STILE LIBERO, SENZA ATTREZZATURA, 100 M"])
    if ref:
        lines.append(f"Osservazioni disponibili: {ref['n'] if ref['n'] is not None else '—'}")
        lines.append(f"Mediana storica: {time_label(ref['median']) if ref['median'] is not None else '—'} /100 m")
        lines.append(f"Mediana recente: {time_label(ref['recent']) if ref['recent'] is not None else '—'} /100 m")
        lines.append(f"Trend stimato: {ref['trend'] or '—'}; affidabilità: {ref['confidence'] or '—'}")
    else:
        lines.append("Profilo storico dei 100 m stile libero non disponibile.")

    lines.extend([
        "",
        "CONTROLLO QUALITÀ",
        f"Profilo versione: {profile.get('version', '—')}; generato: {profile.get('generated_at', '—')}",
        f"Osservazioni coaching disponibili: {len(records)}",
    ])
    if any(row.get("merged") and row.get("classification") == "possible_special" for row in rows):
        lines.append("ATTENZIONE: almeno una ripetuta unita è classificata speciale/da verificare; non usarla automaticamente per stimare la velocità standard.")
    if any(row.get("merged") and row.get("equipment") == "other" for row in rows):
        lines.append("ATTENZIONE: almeno una ripetuta unita combina attrezzature diverse o non uniformi; verificarla nella Web UI.")

    text_report = "\n".join(lines) + "\n"

    def cell(value: Any) -> str:
        return html.escape(str(value), quote=True)

    detail_rows = []
    for row in rows:
        lap, distance, elapsed, pace, style, equipment, classification = lap_display(row)
        if row.get("merged"):
            lap = f"{lap} (UNIONE)"
        reason = row.get("special_reason") if row.get("classification") == "possible_special" else None
        if reason:
            classification += f" — {reason}"
        detail_rows.append("<tr>" + "".join(f"<td>{cell(value)}</td>" for value in (lap, distance, elapsed, pace, style, equipment, classification)) + "</tr>")

    history_rows = []
    for item in history:
        s = item["summary"]
        history_rows.append("<tr>" + "".join(f"<td>{cell(value)}</td>" for value in (item["date"] or "—", item["name"], f"{s['distance']:.0f} m", time_label(s["time"]), s["pace"], s["special_count"], s["merged_count"])) + "</tr>")

    alerts = []
    if any(row.get("session_merged") for row in rows):
        source_ids = next((row.get("session_source_ids", []) for row in rows if row.get("session_merged")), [])
        alerts.append("Registrazioni Garmin unite nella stessa seduta: " + ", ".join(str(x) for x in source_ids) + ". I lap originali restano consultabili nella Web UI.")
    if any(row.get("merged") and row.get("classification") == "possible_special" for row in rows):
        alerts.append("Una ripetuta unita è classificata speciale/da verificare: non usarla automaticamente per stimare la velocità standard.")
    if any(row.get("merged") and row.get("equipment") == "other" for row in rows):
        alerts.append("Una ripetuta unita combina attrezzature diverse o non uniformi: verificarla nella Web UI.")
    alerts_html = "".join(f"<p class='alert'>{cell(msg)}</p>" for msg in alerts)
    ref_html = "Profilo dei 100 m stile libero non disponibile."
    if ref:
        ref_html = (
            f"Osservazioni: {cell(ref['n'] if ref['n'] is not None else '—')}; "
            f"mediana storica: {cell(time_label(ref['median']) if ref['median'] is not None else '—')}/100 m; "
            f"recente: {cell(time_label(ref['recent']) if ref['recent'] is not None else '—')}/100 m; "
            f"trend: {cell(ref['trend'] or '—')}; affidabilità: {cell(ref['confidence'] or '—')}."
        )
    html_report = f"""<!doctype html>
<html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Swim Coach — {cell(date)} — {cell(name)}</title>
<style>
body{{font-family:Arial,sans-serif;color:#1f2937;line-height:1.45;max-width:1100px;margin:24px auto;padding:0 16px}}
h1{{font-size:1.6rem}}h2{{font-size:1.15rem;margin-top:28px;border-bottom:1px solid #ddd;padding-bottom:6px}}
.kpis{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}}
.kpi{{background:#f3f6f9;border-radius:8px;padding:12px}}.value{{font-size:1.35rem;font-weight:700}}
.small{{color:#64748b;font-size:.9rem}}.alert{{background:#fff7ed;border-left:4px solid #ea580c;padding:10px}}
table{{border-collapse:collapse;width:100%;font-size:.9rem}}th,td{{text-align:left;border-bottom:1px solid #e5e7eb;padding:7px;vertical-align:top}}th{{background:#f8fafc}}
@media(max-width:700px){{body{{margin:12px auto}}table{{font-size:.8rem}}th,td{{padding:5px}}}}
</style></head><body>
<h1>Swim Coach — report allenamento</h1>
<p><b>{cell(date)}</b> · {cell(name)} · ID {cell(aid)}<br><span class="small">Generato {cell(generated)}; versione profilo {cell(profile.get('version', '—'))}</span></p>
{alerts_html}
<div class="kpis">
<div class="kpi"><div class="small">Distanza lap validi</div><div class="value">{summary['distance']:.0f} m</div></div>
<div class="kpi"><div class="small">Tempo sommato lap</div><div class="value">{cell(time_label(summary['time']))}</div></div>
<div class="kpi"><div class="small">Passo medio calcolato</div><div class="value">{cell(summary['pace'])}</div></div>
<div class="kpi"><div class="small">Ripetute unite</div><div class="value">{summary['merged_count']}</div></div>
</div>
<p>Lap normali: <b>{summary['normal_count']}</b> ({summary['normal_distance']:.0f} m; {cell(time_label(summary['normal_time']))}).
Lap speciali/da verificare: <b>{summary['special_count']}</b> ({summary['special_distance']:.0f} m; {cell(time_label(summary['special_time']))}).
Artefatti esclusi: <b>{summary['artifact_count']}</b>.</p>
<p class="small">Il tempo è la somma dei tempi dei lap disponibili, non necessariamente la durata trascorsa della seduta: le pause possono non essere rappresentate. I lap speciali sono tenuti separati dai riferimenti standard.</p>
<h2>Dettaglio dei lap</h2><div style="overflow-x:auto"><table><thead><tr><th>Lap sorgente</th><th>Distanza</th><th>Tempo</th><th>Passo/100 m</th><th>Stile</th><th>Attrezzatura</th><th>Classificazione</th></tr></thead><tbody>{''.join(detail_rows)}</tbody></table></div>
<h2>Confronto con le sedute recenti</h2><div style="overflow-x:auto"><table><thead><tr><th>Data</th><th>Attività</th><th>Distanza corretta</th><th>Tempo lap</th><th>Passo medio</th><th>Speciali</th><th>Unioni</th></tr></thead><tbody>{''.join(history_rows)}</tbody></table></div>
<h2>Riferimento storico — stile libero senza attrezzatura, 100 m</h2><p>{ref_html}</p>
</body></html>"""
    return text_report, html_report


def main() -> int:
    parser = argparse.ArgumentParser(description="Genera un report locale Swim Coach in TXT e HTML.")
    parser.add_argument("--profile", type=Path, default=DATA_FILE, help="Percorso swim_profile.json")
    parser.add_argument("--activity-id", default=None, help="ID attività; se omesso viene scelta la più recente")
    parser.add_argument("--output-dir", type=Path, default=REPORT_DIR, help="Cartella di output")
    args = parser.parse_args()

    try:
        profile = load_profile(args.profile)
        records = get_records(profile)
        groups = group_by_activity(records)
        aid, rows = get_selected_activity(groups, args.activity_id)
        text_report, html_report = build_report(profile, records, aid, rows, groups)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"ERRORE: {exc}")
        return 1

    args.output_dir.mkdir(parents=True, exist_ok=True)
    date = activity_date(rows) or "senza-data"
    safe_date = "".join(ch if ch.isalnum() or ch in "-" else "-" for ch in date)
    base = f"swim-report-{safe_date}-{aid}"
    txt_path = args.output_dir / f"{base}.txt"
    html_path = args.output_dir / f"{base}.html"
    txt_path.write_text(text_report, encoding="utf-8")
    html_path.write_text(html_report, encoding="utf-8")
    print("Report creati:")
    print(f"  Testo: {txt_path}")
    print(f"  HTML:  {html_path}")
    print(f"  Attività: {aid} — {activity_name(rows, aid)}")
    print(f"  Data: {date}")
    print(f"  Distanza corretta: {activity_summary(rows)['distance']:.0f} m")
    print(f"  Ripetute unite: {activity_summary(rows)['merged_count']}")
    print("Nota: il report è solo locale; l'invio e-mail viene configurato dopo la verifica del contenuto.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
