#!/usr/bin/env python3

import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import urlopen
from urllib.error import URLError, HTTPError


INFLUX_URL = "http://127.0.0.1:8086/query"
INFLUX_DB = "GarminStats"
OUTPUT_DIR = Path("/opt/swim-coach/data")


def influx_query(query):
    params = urlencode({
        "db": INFLUX_DB,
        "q": query,
        "epoch": "ms",
    })

    url = f"{INFLUX_URL}?{params}"

    try:
        with urlopen(url, timeout=10) as response:
            data = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        raise RuntimeError(f"Errore HTTP InfluxDB: {exc.code} {exc.reason}") from exc
    except URLError as exc:
        raise RuntimeError(f"Impossibile contattare InfluxDB: {exc.reason}") from exc

    if "error" in data:
        raise RuntimeError(f"Errore InfluxDB: {data['error']}")

    rows = []

    for result in data.get("results", []):
        for series in result.get("series", []):
            columns = series.get("columns", [])
            values = series.get("values", [])

            for value in values:
                rows.append(dict(zip(columns, value)))

    return rows


def first_or_none(rows):
    return rows[0] if rows else None


def to_float(value):
    if value is None or value == "":
        return None

    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def to_int(value):
    if value is None or value == "":
        return None

    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def iso_time(value):
    """
    Influx viene interrogato con epoch=ms.
    Converte millisecondi Unix in ISO 8601.
    """
    if value is None:
        return None

    try:
        dt = datetime.fromtimestamp(float(value) / 1000, tz=timezone.utc)
        return dt.isoformat()
    except (TypeError, ValueError, OverflowError):
        return None


def clean_row(row):
    result = {}

    for key, value in row.items():
        if key == "time":
            result["time"] = value
            result["time_iso"] = iso_time(value)
        else:
            result[key] = value

    return result


def choose_summary(rows, lap_distance):
    """
    ActivitySummary può contenere duplicati/anomalie.
    Scegliamo la riga più vicina alla distanza ricostruita dai lap.
    In caso di parità preferiamo quella più recente.
    """
    if not rows:
        return None

    def score(row):
        distance = to_float(row.get("distance"))

        if distance is None or math.isnan(distance):
            distance_error = 1e12
        else:
            distance_error = abs(distance - lap_distance)

        time_value = to_float(row.get("time")) or 0

        return (distance_error, -time_value)

    return min(rows, key=score)


def normalize_lap(row, length_map):
    index = to_int(row.get("Index"))
    length_index = to_int(row.get("Length_Index"))
    lengths = to_int(row.get("Lengths"))
    distance = to_float(row.get("Distance"))
    elapsed = to_float(row.get("Elapsed_Time"))

    if distance is not None and distance > 0 and lengths and lengths > 0:
        lap_type = "swim"
    elif (
        distance is not None
        and abs(distance) < 0.0001
        and lengths is not None
        and lengths == 0
    ):
        lap_type = "rest"
    elif (
        distance is not None
        and abs(distance) < 0.0001
        and lengths is not None
        and lengths > 0
    ):
        lap_type = "end_or_partial"
    else:
        lap_type = "unknown"

    associated_lengths = []

    if (
        lap_type == "swim"
        and length_index is not None
        and lengths is not None
        and lengths > 0
    ):
        first_index = length_index + 1
        last_index = length_index + lengths

        for idx in range(first_index, last_index + 1):
            if idx in length_map:
                associated_lengths.append(length_map[idx])

    return {
        "index": index,
        "type": lap_type,
        "length_index": length_index,
        "lengths": lengths,
        "distance_m": distance,
        "elapsed_s": elapsed,
        "cycles": to_int(row.get("Cycles")),
        "avg_hr": to_float(row.get("Avg_HR")),
        "avg_cadence": to_float(row.get("Avg_Cadence")),
        "avg_speed": to_float(row.get("Avg_Speed")),
        "avg_stroke_distance": to_float(row.get("Avg_Stroke_Distance")),
        "length_records": associated_lengths,
    }


def normalize_length(row):
    return {
        "index": to_int(row.get("Index")),
        "elapsed_s": to_float(row.get("Elapsed_Time")),
        "strokes": to_int(row.get("Strokes")),
        "swim_stroke": row.get("Swim_Stroke"),
        "avg_cadence": to_float(row.get("Avg_Cadence")),
        "avg_speed": to_float(row.get("Avg_Speed")),
    }


def extract_activity(activity_id):
    activity_id = str(activity_id)

    summary_query = (
        'SELECT * FROM "ActivitySummary" '
        f'WHERE "ActivityID"=\'{activity_id}\' '
        'AND "activityType"=\'lap_swimming\' '
        'ORDER BY time ASC'
    )

    session_query = (
        'SELECT * FROM "ActivitySession" '
        f'WHERE "ActivityID"=\'{activity_id}\' '
        'ORDER BY time ASC'
    )

    lap_query = (
        'SELECT * FROM "ActivityLap" '
        f'WHERE "ActivityID"=\'{activity_id}\' '
        'ORDER BY time ASC'
    )

    length_query = (
        'SELECT * FROM "ActivityLength" '
        f'WHERE "ActivityID"=\'{activity_id}\' '
        'ORDER BY time ASC'
    )

    summary_rows = influx_query(summary_query)
    session_rows = influx_query(session_query)
    lap_rows = influx_query(lap_query)
    length_rows = influx_query(length_query)

    if not session_rows:
        raise RuntimeError(
            f"Nessuna ActivitySession trovata per ActivityID {activity_id}"
        )

    if not lap_rows:
        raise RuntimeError(
            f"Nessun ActivityLap trovato per ActivityID {activity_id}"
        )

    # Normalizza le lunghezze e crea una mappa Index -> record.
    lengths_normalized = [
        normalize_length(row)
        for row in length_rows
    ]

    length_map = {
        item["index"]: item
        for item in lengths_normalized
        if item["index"] is not None
    }

    # Normalizza i lap.
    laps = [
        normalize_lap(row, length_map)
        for row in lap_rows
    ]

    # Distanza ricostruita dai lap di lavoro.
    lap_distance = sum(
        item["distance_m"]
        for item in laps
        if item["distance_m"] is not None and item["distance_m"] > 0
    )

    # Tempo sui lap di lavoro.
    moving_lap_time = sum(
        item["elapsed_s"]
        for item in laps
        if item["type"] == "swim" and item["elapsed_s"] is not None
    )

    # Tempo dei recuperi.
    rest_time = sum(
        item["elapsed_s"]
        for item in laps
        if item["type"] == "rest" and item["elapsed_s"] is not None
    )

    selected_summary = choose_summary(summary_rows, lap_distance)

    session = first_or_none(session_rows)

    result = {
        "activity_id": activity_id,
        "generated_at": datetime.now(timezone.utc).isoformat(),

        "summary": clean_row(selected_summary) if selected_summary else None,

        "summary_candidates": [
            clean_row(row)
            for row in summary_rows
        ],

        "session": clean_row(session) if session else None,

        "reconstruction": {
            "distance_from_laps_m": round(lap_distance, 3),
            "moving_time_from_laps_s": round(moving_lap_time, 3),
            "rest_time_from_laps_s": round(rest_time, 3),
            "swim_laps": sum(1 for x in laps if x["type"] == "swim"),
            "rest_laps": sum(1 for x in laps if x["type"] == "rest"),
            "other_laps": sum(
                1 for x in laps
                if x["type"] not in ("swim", "rest")
            ),
        },

        "laps": laps,

        # Conserviamo anche tutte le ActivityLength originali.
        "length_records_raw": lengths_normalized,
    }

    return result


def main():
    if len(sys.argv) != 2:
        print(f"Uso: {sys.argv[0]} ACTIVITY_ID")
        print(f"Esempio: {sys.argv[0]} 24539708008")
        sys.exit(1)

    activity_id = sys.argv[1]

    try:
        data = extract_activity(activity_id)
    except Exception as exc:
        print(f"ERRORE: {exc}", file=sys.stderr)
        sys.exit(2)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    output_file = OUTPUT_DIR / f"{activity_id}.json"

    with output_file.open("w", encoding="utf-8") as f:
        json.dump(
            data,
            f,
            ensure_ascii=False,
            indent=2,
        )

    print(f"OK")
    print(f"ActivityID: {activity_id}")
    print(f"File: {output_file}")
    print()
    print("Ricostruzione:")
    print(
        f"  Distanza dai lap: "
        f"{data['reconstruction']['distance_from_laps_m']} m"
    )
    print(
        f"  Lap di nuoto: "
        f"{data['reconstruction']['swim_laps']}"
    )
    print(
        f"  Lap di recupero: "
        f"{data['reconstruction']['rest_laps']}"
    )
    print(
        f"  Altri lap: "
        f"{data['reconstruction']['other_laps']}"
    )


if __name__ == "__main__":
    main()
