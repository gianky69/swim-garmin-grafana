#!/usr/bin/env python3
"""Importa da InfluxDB le nuove attività di nuoto e genera i report di oggi."""

import fcntl
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import urlopen
from zoneinfo import ZoneInfo

BASE = Path("/opt/swim-coach")
DATA = BASE / "data"
EXTRACT = BASE / "extract_activity.py"
ANALYZE = BASE / "analyze_activity.py"
UPDATE = BASE / "update_swim_coach.py"

INFLUX_URL = "http://127.0.0.1:8086/query"
INFLUX_DB = "GarminStats"
TZ = ZoneInfo("Europe/Rome")


def query_activities():
    query = (
        'SELECT * FROM "ActivitySummary" '
        'WHERE "activityType"=\'lap_swimming\' '
        'AND time > now() - 365d '
        'ORDER BY time DESC LIMIT 1000'
    )
    url = INFLUX_URL + "?" + urlencode({
        "db": INFLUX_DB,
        "q": query,
        "epoch": "ms",
    })

    with urlopen(url, timeout=20) as response:
        payload = json.loads(response.read().decode("utf-8"))

    if payload.get("error"):
        raise RuntimeError("InfluxDB: " + str(payload["error"]))

    rows = []
    for result in payload.get("results", []):
        if result.get("error"):
            raise RuntimeError("InfluxDB: " + str(result["error"]))
        for series in result.get("series", []):
            columns = series.get("columns", [])
            for values in series.get("values", []):
                rows.append(dict(zip(columns, values)))

    # Una stessa attività può avere più righe ActivitySummary.
    activities = {}
    for row in rows:
        aid = str(
            row.get("ActivityID")
            or row.get("Activity_ID")
            or row.get("ActivityId")
            or ""
        ).strip()

        if not aid.isdigit():
            continue

        try:
            timestamp = float(row["time"])
            local_dt = datetime.fromtimestamp(
                timestamp / 1000.0, timezone.utc
            ).astimezone(TZ)
        except (KeyError, TypeError, ValueError, OverflowError, OSError):
            continue

        current = activities.get(aid)
        if current is None or timestamp > current["timestamp"]:
            activities[aid] = {
                "timestamp": timestamp,
                "date": local_dt.date(),
                "name": row.get("activityName") or "",
                "distance": row.get("distance"),
            }

    return activities


def valid_json_object(path):
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return isinstance(value, dict)
    except (OSError, json.JSONDecodeError):
        return False


def run_step(command, label):
    print("\n=== " + label + " ===", flush=True)
    print("Comando:", " ".join(command), flush=True)
    result = subprocess.run(
        command,
        cwd=str(BASE),
        check=False,
        timeout=600,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"{label} terminato con codice {result.returncode}"
        )


def _main_unlocked():
    today = datetime.now(TZ).date()
    activities = query_activities()
    print(f"Attività di nuoto trovate in InfluxDB: {len(activities)}")
    print(f"Data locale: {today.isoformat()}")

    if not activities:
        print("Nessuna attività di nuoto disponibile.")
        return 0

    # Prima importa e analizza le attività non ancora elaborate.
    ordered = sorted(
        activities.items(),
        key=lambda item: item[1]["timestamp"],
    )

    for aid, meta in ordered:
        raw_file = DATA / f"{aid}.json"
        analysis_file = DATA / f"{aid}_analysis.json"

        need_raw = not valid_json_object(raw_file)
        need_analysis = not valid_json_object(analysis_file)

        if not need_raw and not need_analysis:
            continue

        try:
            if need_raw:
                run_step(
                    [sys.executable, str(EXTRACT), aid],
                    f"Estrazione attività {aid}",
                )

            if need_analysis:
                run_step(
                    [sys.executable, str(ANALYZE), aid],
                    f"Analisi attività {aid}",
                )

            if not valid_json_object(raw_file):
                raise RuntimeError(f"JSON estratto non valido: {raw_file}")
            if not valid_json_object(analysis_file):
                raise RuntimeError(
                    f"JSON di analisi non valido: {analysis_file}"
                )

        except Exception as exc:
            print(f"ERRORE attività {aid}: {exc}", file=sys.stderr)
            if meta["date"] == today:
                # Non inviare un report incompleto per una seduta odierna.
                raise
            print(
                f"ATTENZIONE: attività storica {aid} saltata.",
                file=sys.stderr,
            )

    # Rigenera il profilo e un report per ogni attività di oggi.
    today_ids = [
        aid for aid, meta in ordered
        if meta["date"] == today
    ]

    if not today_ids:
        print("Nessuna attività di nuoto di oggi in InfluxDB.")
        return 0

    for aid in today_ids:
        raw_file = DATA / f"{aid}.json"
        analysis_file = DATA / f"{aid}_analysis.json"

        if not valid_json_object(raw_file):
            raise RuntimeError(f"Dati originali mancanti per attività odierna {aid}")
        if not valid_json_object(analysis_file):
            raise RuntimeError(f"Analisi mancante per attività odierna {aid}")

        run_step(
            [sys.executable, str(UPDATE), "--activity-id", aid],
            f"Generazione report attività odierna {aid}",
        )

    print(
        f"\nImportazione completata. Report odierni generati: {len(today_ids)}"
    )
    return 0



def main():
    """Serializza importazioni manuali e pianificate."""
    lock_path = BASE / ".import_new_activities.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+", encoding="utf-8") as lock_handle:
        try:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("Importazione già in corso; nessuna seconda esecuzione avviata.", file=sys.stderr)
            return 2
        try:
            return _main_unlocked()
        finally:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERRORE IMPORTAZIONE: {exc}", file=sys.stderr)
        raise SystemExit(1)
