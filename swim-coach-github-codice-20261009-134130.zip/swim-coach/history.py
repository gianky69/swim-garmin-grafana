#!/usr/bin/env python3

import json
import sys
from pathlib import Path
from datetime import datetime, timezone
from statistics import mean


BASE_DIR = Path("/opt/swim-coach")
DATA_DIR = BASE_DIR / "data"

sys.path.insert(0, str(BASE_DIR))

from extract_activity import influx_query, extract_activity
from analyze_activity import analyze_activity


DEFAULT_LIMIT = 20

# Numero massimo di precedenti usati per il trend.
SERIES_HISTORY_SIZE = 5


# ============================================================
# FUNZIONI UTILI
# ============================================================

def safe_float(value):
    if value is None or value == "":
        return None

    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def safe_int(value):
    if value is None or value == "":
        return None

    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def format_time(seconds):
    if seconds is None:
        return "--:--"

    seconds = max(
        0,
        int(round(seconds))
    )

    minutes = seconds // 60
    secs = seconds % 60

    return f"{minutes}:{secs:02d}"


def format_pace(seconds):
    return format_time(seconds)


def timestamp_to_iso(timestamp_ms):
    if timestamp_ms is None:
        return None

    try:
        return datetime.fromtimestamp(
            float(timestamp_ms) / 1000,
            tz=timezone.utc
        ).isoformat()
    except (TypeError, ValueError, OverflowError):
        return None


def timestamp_to_date(timestamp_ms):
    iso = timestamp_to_iso(timestamp_ms)

    if not iso:
        return None

    return iso[:10]


def activity_sort_time(summary):
    value = safe_float(
        summary.get("time")
    )

    return value or 0


def classify_change(delta, threshold):
    """
    Classificazione generica.

    Per il passo:
        delta negativo = più veloce
        delta positivo = più lento

    Per le bracciate:
        delta negativo = meno bracciate
        delta positivo = più bracciate
    """

    if delta is None:
        return "unknown"

    if delta < -threshold:
        return "improving"

    if delta > threshold:
        return "declining"

    return "stable"


def linear_trend(values):
    """
    Pendenza lineare semplice.

    Valore negativo:
        la metrica tende a diminuire.

    Valore positivo:
        la metrica tende ad aumentare.
    """

    cleaned = [
        float(v)
        for v in values
        if v is not None
    ]

    if len(cleaned) < 3:
        return None

    n = len(cleaned)

    x = list(range(n))

    x_mean = mean(x)
    y_mean = mean(cleaned)

    denominator = sum(
        (xi - x_mean) ** 2
        for xi in x
    )

    if denominator == 0:
        return 0.0

    numerator = sum(
        (x[i] - x_mean)
        * (cleaned[i] - y_mean)
        for i in range(n)
    )

    return numerator / denominator


# ============================================================
# INDIVIDUAZIONE ATTIVITÀ
# ============================================================

def get_swim_activity_candidates():
    """
    Recupera le attività lap_swimming.

    ActivitySummary può contenere duplicati per ActivityID.
    Viene mantenuta una sola attività per ID.
    """

    query = (
        'SELECT * FROM "ActivitySummary" '
        'WHERE "activityType"=\'lap_swimming\' '
        'ORDER BY time DESC '
        'LIMIT 500'
    )

    rows = influx_query(query)

    candidates = {}

    for row in rows:

        activity_id = row.get(
            "ActivityID"
        )

        if activity_id is None:
            continue

        activity_id = str(
            activity_id
        )

        if activity_id not in candidates:
            candidates[
                activity_id
            ] = row

    result = list(
        candidates.values()
    )

    result.sort(
        key=activity_sort_time,
        reverse=True
    )

    return result


# ============================================================
# FIRMA STRUTTURA
# ============================================================

def build_structure_signature(analysis):

    labels = []

    for block in analysis.get(
        "blocks",
        []
    ):

        label = block.get(
            "label"
        )

        if not label:
            continue

        labels.append(
            label.replace(
                " × ",
                "x"
            ).replace(
                " m",
                ""
            )
        )

    return "|".join(
        labels
    )


# ============================================================
# RIASSUNTO DELLA SEDUTA
# ============================================================

def summarize_analysis(analysis):

    activity = analysis.get(
        "activity",
        {}
    )

    pool = analysis.get(
        "pool",
        {}
    )

    derived = analysis.get(
        "derived",
        {}
    )

    evaluation = analysis.get(
        "evaluation",
        {}
    )

    source_time = analysis.get(
        "_source_time"
    )

    date = timestamp_to_date(
        source_time
    )

    time_iso = timestamp_to_iso(
        source_time
    )

    return {
        "activity_id":
            analysis.get(
                "activity_id"
            ),

        "timestamp_ms":
            source_time,

        "time_iso":
            time_iso,

        "date":
            date,

        "name":
            activity.get(
                "name"
            ),

        "distance_m":
            safe_float(
                activity.get(
                    "distance_m"
                )
            ),

        "elapsed_s":
            safe_float(
                activity.get(
                    "elapsed_s"
                )
            ),

        "moving_s":
            safe_float(
                activity.get(
                    "moving_s"
                )
            ),

        "avg_hr":
            safe_float(
                activity.get(
                    "avg_hr"
                )
            ),

        "max_hr":
            safe_float(
                activity.get(
                    "max_hr"
                )
            ),

        "training_load":
            safe_float(
                activity.get(
                    "training_load"
                )
            ),

        "aerobic_training_effect":
            safe_float(
                activity.get(
                    "aerobic_training_effect"
                )
            ),

        "anaerobic_training_effect":
            safe_float(
                activity.get(
                    "anaerobic_training_effect"
                )
            ),

        "pool_length_m":
            safe_float(
                pool.get(
                    "length_m"
                )
            ),

        "avg_pace_100_s":
            safe_float(
                derived.get(
                    "avg_pace_100_s"
                )
            ),

        "avg_strokes_per_length":
            safe_float(
                derived.get(
                    "avg_strokes_per_length"
                )
            ),

        "avg_cadence":
            safe_float(
                derived.get(
                    "avg_cadence"
                )
            ),

        "avg_speed_m_s":
            safe_float(
                derived.get(
                    "avg_speed_m_s"
                )
            ),

        "swim_laps":
            safe_int(
                derived.get(
                    "swim_laps"
                )
            ),

        "blocks":
            safe_int(
                derived.get(
                    "blocks"
                )
            ),

        "distance_by_phase_m":
            derived.get(
                "distance_by_phase_m",
                {}
            ),

        "styles":
            derived.get(
                "styles",
                {}
            ),

        "pace_assessment":
            evaluation.get(
                "pace_assessment"
            ),

        "efficiency_assessment":
            evaluation.get(
                "efficiency_assessment"
            ),

        "fatigue_assessment":
            evaluation.get(
                "fatigue_assessment"
            ),

        "structure_signature":
            build_structure_signature(
                analysis
            ),
    }


# ============================================================
# RICALCOLO METRICHE DELLA SERIE
# ============================================================

def recompute_series_metrics(block):
    """
    Ricalcola le metriche della serie direttamente dalle
    singole ripetute.

    È importante perché i campi aggregati possono non essere
    sempre sufficientemente affidabili/confrontabili.

    Il passo viene calcolato come:

        tempo totale / distanza totale * 100

    quindi:
        2 x 50 m in 43 s complessivi
        = 43 s / 100 m
        = 0:43/100 m

    Questo è matematicamente corretto e non viene considerato
    un'anomalia dal parser.
    """

    repetitions = block.get(
        "repetitions_detail",
        []
    )

    valid_reps = []

    for rep in repetitions:

        distance = safe_float(
            rep.get(
                "distance_m"
            )
        )

        elapsed = safe_float(
            rep.get(
                "elapsed_s"
            )
        )

        if (
            distance is None
            or elapsed is None
            or distance <= 0
            or elapsed <= 0
        ):
            continue

        valid_reps.append(
            rep
        )

    if not valid_reps:

        return {
            "distance_m": None,
            "time_s": None,
            "pace_100_s": None,
            "avg_strokes": None,
            "avg_cadence": None,
            "technical_coverage": 0.0,
        }

    total_distance = sum(
        safe_float(
            rep.get(
                "distance_m"
            )
        )
        for rep in valid_reps
    )

    total_time = sum(
        safe_float(
            rep.get(
                "elapsed_s"
            )
        )
        for rep in valid_reps
    )

    if total_distance > 0:

        pace_100 = (
            total_time
            / total_distance
            * 100
        )

    else:

        pace_100 = None

    # --------------------------------------------------------
    # BRACCIATE/LUNGHEZZA
    # --------------------------------------------------------

    stroke_pairs = []

    for rep in valid_reps:

        strokes = safe_float(
            rep.get(
                "strokes_per_length"
            )
        )

        distance = safe_float(
            rep.get(
                "distance_m"
            )
        )

        if (
            strokes is not None
            and strokes > 0
            and distance is not None
            and distance > 0
        ):

            stroke_pairs.append(
                (
                    strokes,
                    distance
                )
            )

    if stroke_pairs:

        total_weight = sum(
            weight
            for _, weight
            in stroke_pairs
        )

        avg_strokes = (
            sum(
                value * weight
                for value, weight
                in stroke_pairs
            )
            / total_weight
        )

    else:

        avg_strokes = None

    # --------------------------------------------------------
    # CADENZA
    # --------------------------------------------------------

    cadence_pairs = []

    for rep in valid_reps:

        cadence = safe_float(
            rep.get(
                "cadence"
            )
        )

        elapsed = safe_float(
            rep.get(
                "elapsed_s"
            )
        )

        if (
            cadence is not None
            and cadence > 0
            and elapsed is not None
            and elapsed > 0
        ):

            cadence_pairs.append(
                (
                    cadence,
                    elapsed
                )
            )

    if cadence_pairs:

        total_weight = sum(
            weight
            for _, weight
            in cadence_pairs
        )

        avg_cadence = (
            sum(
                value * weight
                for value, weight
                in cadence_pairs
            )
            / total_weight
        )

    else:

        avg_cadence = None

    # --------------------------------------------------------
    # COPERTURA DATI TECNICI
    # --------------------------------------------------------

    technical_values = sum(
        1
        for rep in valid_reps
        if (
            safe_float(
                rep.get(
                    "strokes_per_length"
                )
            ) is not None
            and safe_float(
                rep.get(
                    "strokes_per_length"
                )
            ) > 0
        )
    )

    technical_coverage = (
        technical_values
        / len(valid_reps)
    )

    return {
        "distance_m":
            total_distance,

        "time_s":
            total_time,

        "pace_100_s":
            pace_100,

        "avg_strokes":
            avg_strokes,

        "avg_cadence":
            avg_cadence,

        "technical_coverage":
            technical_coverage,
    }


# ============================================================
# STORICO DELLE SERIE
# ============================================================

def extract_series_observations(analyses):
    """
    Costruisce uno storico separato per ogni tipo di serie.

    Esempio:

        4 × 100 m
        8 × 50 m
        4 × 75 m

    Le occorrenze duplicate nella stessa seduta vengono
    mantenute separatamente:

        8 × 50 m #1
        8 × 50 m #2
    """

    series = {}

    for analysis in analyses:

        activity_id = analysis.get(
            "activity_id"
        )

        timestamp = analysis.get(
            "_source_time"
        )

        date = timestamp_to_date(
            timestamp
        )

        occurrence_counter = {}

        for block in analysis.get(
            "blocks",
            []
        ):

            if block.get(
                "type"
            ) != "series":

                continue

            repetitions = safe_int(
                block.get(
                    "repetitions"
                )
            )

            if (
                repetitions is None
                or repetitions < 2
            ):
                continue

            label = block.get(
                "label"
            )

            if not label:
                continue

            occurrence = (
                occurrence_counter.get(
                    label,
                    0
                )
            )

            occurrence_counter[
                label
            ] = occurrence + 1

            metrics = (
                recompute_series_metrics(
                    block
                )
            )

            series_id = (
                f"{label}#{occurrence + 1}"
            )

            observation = {

                "activity_id":
                    activity_id,

                "date":
                    date,

                "timestamp_ms":
                    timestamp,

                "occurrence":
                    occurrence + 1,

                "label":
                    label,

                "series_id":
                    series_id,

                "repetitions":
                    repetitions,

                "distance_per_rep_m":
                    block.get(
                        "distance_per_rep_m"
                    ),

                "total_distance_m":
                    metrics[
                        "distance_m"
                    ],

                "average_pace_100_s":
                    metrics[
                        "pace_100_s"
                    ],

                "average_strokes_per_length":
                    metrics[
                        "avg_strokes"
                    ],

                "average_cadence":
                    metrics[
                        "avg_cadence"
                    ],

                "technical_coverage":
                    metrics[
                        "technical_coverage"
                    ],

                "average_rest_s":
                    safe_float(
                        block.get(
                            "average_rest_between_reps_s"
                        )
                    ),

                "pace_trend_inside_series":
                    block.get(
                        "pace_trend"
                    ),

                "efficiency_trend_inside_series":
                    block.get(
                        "efficiency_trend"
                    ),

                "first_pace_100_s":
                    safe_float(
                        block.get(
                            "first_pace_100_s"
                        )
                    ),

                "last_pace_100_s":
                    safe_float(
                        block.get(
                            "last_pace_100_s"
                        )
                    ),

                "pace_delta_inside_series":
                    safe_float(
                        block.get(
                            "pace_delta_s_per_100"
                        )
                    ),

                "strokes_delta_inside_series":
                    safe_float(
                        block.get(
                            "strokes_delta"
                        )
                    ),

                "styles":
                    block.get(
                        "styles",
                        {}
                    ),
            }

            series.setdefault(
                series_id,
                []
            ).append(
                observation
            )

    # Più recente -> più vecchio.
    for series_id in series:

        series[
            series_id
        ].sort(
            key=lambda x: (
                safe_float(
                    x.get(
                        "timestamp_ms"
                    )
                )
                or 0
            ),
            reverse=True
        )

    return series


# ============================================================
# TREND DELLE SERIE
# ============================================================

def build_series_trends(series_history):

    trends = {}

    for series_id, observations in (
        series_history.items()
    ):

        recent = observations[
            :SERIES_HISTORY_SIZE + 1
        ]

        if not recent:
            continue

        latest = recent[0]

        previous = recent[1:]

        latest_pace = safe_float(
            latest.get(
                "average_pace_100_s"
            )
        )

        latest_strokes = safe_float(
            latest.get(
                "average_strokes_per_length"
            )
        )

        latest_cadence = safe_float(
            latest.get(
                "average_cadence"
            )
        )

        # ----------------------------------------------------
        # PRECEDENTI
        # ----------------------------------------------------

        previous_paces = [
            safe_float(
                item.get(
                    "average_pace_100_s"
                )
            )
            for item in previous
        ]

        previous_paces = [
            value
            for value in previous_paces
            if value is not None
        ]

        previous_strokes = [
            safe_float(
                item.get(
                    "average_strokes_per_length"
                )
            )
            for item in previous
        ]

        previous_strokes = [
            value
            for value in previous_strokes
            if value is not None
        ]

        previous_cadences = [
            safe_float(
                item.get(
                    "average_cadence"
                )
            )
            for item in previous
        ]

        previous_cadences = [
            value
            for value in previous_cadences
            if value is not None
        ]

        previous_pace_avg = (
            mean(previous_paces)
            if previous_paces
            else None
        )

        previous_strokes_avg = (
            mean(previous_strokes)
            if previous_strokes
            else None
        )

        previous_cadence_avg = (
            mean(previous_cadences)
            if previous_cadences
            else None
        )

        # ----------------------------------------------------
        # DELTA
        # ----------------------------------------------------

        pace_delta = None

        if (
            latest_pace is not None
            and previous_pace_avg is not None
        ):

            pace_delta = (
                latest_pace
                - previous_pace_avg
            )

        strokes_delta = None

        if (
            latest_strokes is not None
            and previous_strokes_avg is not None
        ):

            strokes_delta = (
                latest_strokes
                - previous_strokes_avg
            )

        cadence_delta = None

        if (
            latest_cadence is not None
            and previous_cadence_avg is not None
        ):

            cadence_delta = (
                latest_cadence
                - previous_cadence_avg
            )

        # ----------------------------------------------------
        # CLASSIFICAZIONE PASSO
        # ----------------------------------------------------

        pace_verdict = classify_change(
            pace_delta,
            1.0
        )

        # ----------------------------------------------------
        # CLASSIFICAZIONE BRACCIATE
        # ----------------------------------------------------

        strokes_verdict = classify_change(
            strokes_delta,
            0.5
        )

        # ----------------------------------------------------
        # EFFICIENZA
        # ----------------------------------------------------

        if (
            pace_delta is None
            or strokes_delta is None
        ):

            efficiency_verdict = (
                "unknown"
            )

        elif (
            pace_delta < -1
            and strokes_delta <= 0
        ):

            efficiency_verdict = (
                "better"
            )

        elif (
            pace_delta > 1
            and strokes_delta >= 0
        ):

            efficiency_verdict = (
                "worse"
            )

        elif (
            pace_delta < 0
            and strokes_delta > 0
        ):

            efficiency_verdict = (
                "faster_but_less_efficient"
            )

        elif (
            pace_delta > 0
            and strokes_delta < 0
        ):

            efficiency_verdict = (
                "slower_but_more_efficient"
            )

        else:

            efficiency_verdict = (
                "stable"
            )

        # ----------------------------------------------------
        # TREND LUNGO PERIODO
        # ----------------------------------------------------

        chronological = list(
            reversed(recent)
        )

        chronological_paces = [
            safe_float(
                item.get(
                    "average_pace_100_s"
                )
            )
            for item in chronological
        ]

        chronological_paces = [
            value
            for value in chronological_paces
            if value is not None
        ]

        chronological_strokes = [
            safe_float(
                item.get(
                    "average_strokes_per_length"
                )
            )
            for item in chronological
        ]

        chronological_strokes = [
            value
            for value in chronological_strokes
            if value is not None
        ]

        pace_slope = linear_trend(
            chronological_paces
        )

        strokes_slope = linear_trend(
            chronological_strokes
        )

        if pace_slope is None:

            long_term_pace_trend = (
                "insufficient_data"
            )

        elif pace_slope < -1:

            long_term_pace_trend = (
                "improving"
            )

        elif pace_slope > 1:

            long_term_pace_trend = (
                "declining"
            )

        else:

            long_term_pace_trend = (
                "stable"
            )

        if strokes_slope is None:

            long_term_strokes_trend = (
                "insufficient_data"
            )

        elif strokes_slope < -0.5:

            long_term_strokes_trend = (
                "improving"
            )

        elif strokes_slope > 0.5:

            long_term_strokes_trend = (
                "declining"
            )

        else:

            long_term_strokes_trend = (
                "stable"
            )

        # ----------------------------------------------------
        # MIGLIORE / PEGGIORE
        # ----------------------------------------------------

        valid = [
            item
            for item in recent
            if item.get(
                "average_pace_100_s"
            ) is not None
        ]

        best = None
        worst = None

        if valid:

            best = min(
                valid,
                key=lambda x:
                    x[
                        "average_pace_100_s"
                    ]
            )

            worst = max(
                valid,
                key=lambda x:
                    x[
                        "average_pace_100_s"
                    ]
            )

        # ----------------------------------------------------
        # COPERTURA TECNICA
        # ----------------------------------------------------

        technical_coverages = [
            safe_float(
                item.get(
                    "technical_coverage"
                )
            )
            for item in recent
            if item.get(
                "technical_coverage"
            ) is not None
        ]

        technical_coverage_avg = (
            mean(
                technical_coverages
            )
            if technical_coverages
            else 0
        )

        trends[
            series_id
        ] = {

            "series":
                series_id,

            "label":
                latest.get(
                    "label"
                ),

            "occurrence":
                latest.get(
                    "occurrence"
                ),

            "observations_available":
                len(observations),

            "observations_used":
                len(recent),

            "latest":
                latest,

            "previous_average_pace_100_s":
                previous_pace_avg,

            "latest_pace_100_s":
                latest_pace,

            "pace_delta_vs_previous_average":
                pace_delta,

            "pace_verdict":
                pace_verdict,

            "previous_average_strokes_per_length":
                previous_strokes_avg,

            "latest_strokes_per_length":
                latest_strokes,

            "strokes_delta_vs_previous_average":
                strokes_delta,

            "strokes_verdict":
                strokes_verdict,

            "previous_average_cadence":
                previous_cadence_avg,

            "latest_cadence":
                latest_cadence,

            "cadence_delta_vs_previous_average":
                cadence_delta,

            "efficiency_verdict":
                efficiency_verdict,

            "technical_coverage":
                technical_coverage_avg,

            "pace_slope":
                pace_slope,

            "strokes_slope":
                strokes_slope,

            "long_term_pace_trend":
                long_term_pace_trend,

            "long_term_strokes_trend":
                long_term_strokes_trend,

            "best_recent":
                best,

            "worst_recent":
                worst,

            "recent_observations":
                recent,
        }

    return trends


# ============================================================
# STATISTICHE GENERALI
# ============================================================

def build_statistics(summaries):

    distances = [
        item["distance_m"]
        for item in summaries
        if item.get(
            "distance_m"
        ) is not None
    ]

    moving_times = [
        item["moving_s"]
        for item in summaries
        if item.get(
            "moving_s"
        ) is not None
    ]

    paces = [
        item["avg_pace_100_s"]
        for item in summaries
        if item.get(
            "avg_pace_100_s"
        ) is not None
    ]

    strokes = [
        item[
            "avg_strokes_per_length"
        ]
        for item in summaries
        if item.get(
            "avg_strokes_per_length"
        ) is not None
    ]

    cadences = [
        item["avg_cadence"]
        for item in summaries
        if item.get(
            "avg_cadence"
        ) is not None
    ]

    return {

        "activities_processed":
            len(summaries),

        "total_distance_m":
            sum(distances)
            if distances
            else 0,

        "average_distance_m":
            mean(distances)
            if distances
            else None,

        "average_moving_time_s":
            mean(moving_times)
            if moving_times
            else None,

        "average_pace_100_s":
            mean(paces)
            if paces
            else None,

        "average_strokes_per_length":
            mean(strokes)
            if strokes
            else None,

        "average_cadence":
            mean(cadences)
            if cadences
            else None,
    }


# ============================================================
# COSTRUZIONE STORICO
# ============================================================

def build_history(limit):

    candidates = (
        get_swim_activity_candidates()
    )

    candidates = candidates[
        :limit
    ]

    analyses = []
    failures = []

    print()
    print(
        "=" * 80
    )

    print(
        f"ELABORAZIONE STORICO - "
        f"ultime {len(candidates)} attività piscina"
    )

    print(
        "=" * 80
    )

    for position, candidate in enumerate(
        candidates,
        start=1
    ):

        activity_id = str(
            candidate.get(
                "ActivityID"
            )
        )

        print(
            f"[{position:02d}/{len(candidates):02d}] "
            f"ActivityID {activity_id} ...",
            end=" "
        )

        try:

            # ------------------------------------------------
            # Estrazione
            # ------------------------------------------------

            extracted = extract_activity(
                activity_id
            )

            extracted_file = (
                DATA_DIR
                / f"{activity_id}.json"
            )

            with extracted_file.open(
                "w",
                encoding="utf-8"
            ) as f:

                json.dump(
                    extracted,
                    f,
                    ensure_ascii=False,
                    indent=2
                )

            # ------------------------------------------------
            # Analisi
            # ------------------------------------------------

            analysis = analyze_activity(
                extracted
            )

            # Timestamp reale della riga Summary
            # usata per l'elenco storico.
            analysis[
                "_source_time"
            ] = candidate.get(
                "time"
            )

            analysis[
                "_summary_candidates"
            ] = extracted.get(
                "summary_candidates",
                []
            )

            analysis_file = (
                DATA_DIR
                / f"{activity_id}_analysis.json"
            )

            with analysis_file.open(
                "w",
                encoding="utf-8"
            ) as f:

                json.dump(
                    analysis,
                    f,
                    ensure_ascii=False,
                    indent=2
                )

            analyses.append(
                analysis
            )

            summary = summarize_analysis(
                analysis
            )

            print(
                f"OK - "
                f"{summary.get('distance_m', 0):.0f} m - "
                f"{format_time(summary.get('elapsed_s'))}"
            )

        except Exception as exc:

            print(
                f"ERRORE: {exc}"
            )

            failures.append({
                "activity_id":
                    activity_id,

                "error":
                    str(exc),
            })

    # Più recente -> più vecchio.
    analyses.sort(
        key=lambda x: (
            safe_float(
                x.get(
                    "_source_time"
                )
            )
            or 0
        ),
        reverse=True
    )

    # --------------------------------------------------------
    # RIASSUNTI
    # --------------------------------------------------------

    summaries = [
        summarize_analysis(
            analysis
        )
        for analysis in analyses
    ]

    # --------------------------------------------------------
    # STORICO SERIE
    # --------------------------------------------------------

    all_series_history = (
        extract_series_observations(
            analyses
        )
    )

    # --------------------------------------------------------
    # TREND SERIE
    # --------------------------------------------------------

    series_trends = (
        build_series_trends(
            all_series_history
        )
    )

    # --------------------------------------------------------
    # STATISTICHE
    # --------------------------------------------------------

    statistics = build_statistics(
        summaries
    )

    statistics[
        "activities_failed"
    ] = len(failures)

    # --------------------------------------------------------
    # OUTPUT
    # --------------------------------------------------------

    history = {

        "history_version":
            "2.1",

        "generated_at":
            datetime.now(
                timezone.utc
            ).isoformat(),

        "limit":
            limit,

        "series_history_size":
            SERIES_HISTORY_SIZE,

        "statistics":
            statistics,

        "activities":
            summaries,

        "series_history":
            all_series_history,

        "series_trends":
            series_trends,

        "failures":
            failures,
    }

    output_file = (
        DATA_DIR
        / "history_swim.json"
    )

    with output_file.open(
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            history,
            f,
            ensure_ascii=False,
            indent=2
        )

    return history, output_file


# ============================================================
# REPORT
# ============================================================

def print_history_report(
    history,
    output_file
):

    statistics = history[
        "statistics"
    ]

    activities = history[
        "activities"
    ]

    trends = history[
        "series_trends"
    ]

    print()
    print(
        "=" * 80
    )

    print(
        "STORICO NUOTO V2.1"
    )

    print(
        "=" * 80
    )

    print(
        f"Attività elaborate: "
        f"{statistics['activities_processed']}"
    )

    print(
        f"Errori:              "
        f"{statistics['activities_failed']}"
    )

    print(
        f"Distanza totale:     "
        f"{statistics['total_distance_m']:.0f} m"
    )

    if statistics.get(
        "average_distance_m"
    ) is not None:

        print(
            f"Distanza media:      "
            f"{statistics['average_distance_m']:.0f} m"
        )

    if statistics.get(
        "average_pace_100_s"
    ) is not None:

        print(
            f"Passo medio storico: "
            f"{format_pace(statistics['average_pace_100_s'])}/100"
        )

    if statistics.get(
        "average_strokes_per_length"
    ) is not None:

        print(
            f"Bracciate/25 medie:  "
            f"{statistics['average_strokes_per_length']:.1f}"
        )

    if statistics.get(
        "average_cadence"
    ) is not None:

        print(
            f"Cadenza media:       "
            f"{statistics['average_cadence']:.1f}"
        )

    # ========================================================
    # ATTIVITÀ
    # ========================================================

    print()
    print(
        "ULTIME ATTIVITÀ"
    )

    print(
        "-" * 80
    )

    print(
        f"{'Data':<12}"
        f"{'Nome':<18}"
        f"{'Dist':>7}"
        f"{'Passo':>9}"
        f"{'Br/25':>8}"
        f"{'FC':>6}"
        f"{'Load':>8}"
    )

    for item in activities[:10]:

        date = (
            item.get(
                "date"
            )
            or "----------"
        )

        name = str(
            item.get(
                "name"
            )
            or ""
        )

        if len(name) > 17:
            name = name[:17]

        distance = (
            item.get(
                "distance_m"
            )
            or 0
        )

        pace = item.get(
            "avg_pace_100_s"
        )

        strokes = item.get(
            "avg_strokes_per_length"
        )

        hr = item.get(
            "avg_hr"
        )

        load = item.get(
            "training_load"
        )

        strokes_text = (
            f"{strokes:>8.1f}"
            if strokes is not None
            else f"{'--':>8}"
        )

        hr_text = (
            f"{hr:>6.0f}"
            if hr is not None
            else f"{'--':>6}"
        )

        load_text = (
            f"{load:>8.1f}"
            if load is not None
            else f"{'--':>8}"
        )

        print(
            f"{date:<12}"
            f"{name:<18}"
            f"{distance:>7.0f}"
            f"{format_pace(pace):>9}"
            f"{strokes_text}"
            f"{hr_text}"
            f"{load_text}"
        )

    # ========================================================
    # TREND SERIE
    # ========================================================

    print()
    print(
        "TREND DELLE SERIE"
    )

    print(
        "-" * 80
    )

    if not trends:

        print(
            "Nessuna serie ripetuta trovata."
        )

    else:

        for series_id in sorted(
            trends.keys()
        ):

            trend = trends[
                series_id
            ]

            print()
            print(
                f"{trend.get('series')}"
            )

            if trend.get(
                "occurrence"
            ) is not None:

                print(
                    f"  Occorrenza:                "
                    f"{trend['occurrence']}"
                )

            print(
                f"  Osservazioni disponibili: "
                f"{trend['observations_available']}"
            )

            print(
                f"  Osservazioni utilizzate:   "
                f"{trend['observations_used']}"
            )

            print(
                f"  Passo ultima:              "
                f"{format_pace(trend['latest_pace_100_s'])}"
            )

            if trend.get(
                "previous_average_pace_100_s"
            ) is not None:

                print(
                    f"  Media precedenti:          "
                    f"{format_pace(trend['previous_average_pace_100_s'])}"
                )

            if trend.get(
                "pace_delta_vs_previous_average"
            ) is not None:

                print(
                    f"  Δ passo:                   "
                    f"{trend['pace_delta_vs_previous_average']:+.1f} s/100"
                )

            print(
                f"  Trend passo:               "
                f"{trend['pace_verdict']}"
            )

            if trend.get(
                "latest_strokes_per_length"
            ) is not None:

                print(
                    f"  Bracciate ultima:          "
                    f"{trend['latest_strokes_per_length']:.1f}"
                )

            if trend.get(
                "previous_average_strokes_per_length"
            ) is not None:

                print(
                    f"  Media br/25 precedenti:    "
                    f"{trend['previous_average_strokes_per_length']:.1f}"
                )

            if trend.get(
                "strokes_delta_vs_previous_average"
            ) is not None:

                print(
                    f"  Δ br/25:                   "
                    f"{trend['strokes_delta_vs_previous_average']:+.1f}"
                )

            print(
                f"  Trend bracciate:           "
                f"{trend['strokes_verdict']}"
            )

            if trend.get(
                "latest_cadence"
            ) is not None:

                print(
                    f"  Cadenza ultima:            "
                    f"{trend['latest_cadence']:.1f}"
                )

            if trend.get(
                "previous_average_cadence"
            ) is not None:

                print(
                    f"  Cadenza media precedente:  "
                    f"{trend['previous_average_cadence']:.1f}"
                )

            if trend.get(
                "cadence_delta_vs_previous_average"
            ) is not None:

                print(
                    f"  Δ cadenza:                 "
                    f"{trend['cadence_delta_vs_previous_average']:+.1f}"
                )

            print(
                f"  Efficienza:                "
                f"{trend['efficiency_verdict']}"
            )

            print(
                f"  Copertura tecnica media:   "
                f"{trend['technical_coverage'] * 100:.0f}%"
            )

            print(
                f"  Trend lungo periodo passo: "
                f"{trend['long_term_pace_trend']}"
            )

            print(
                f"  Trend lungo periodo br/25: "
                f"{trend['long_term_strokes_trend']}"
            )

            best = trend.get(
                "best_recent"
            )

            worst = trend.get(
                "worst_recent"
            )

            if best:

                print(
                    f"  Migliore recente:          "
                    f"{best.get('date')} "
                    f"({format_pace(best.get('average_pace_100_s'))})"
                )

            if worst:

                print(
                    f"  Peggiore recente:          "
                    f"{worst.get('date')} "
                    f"({format_pace(worst.get('average_pace_100_s'))})"
                )

            print()
            print(
                "  Ultime osservazioni:"
            )

            for observation in trend[
                "recent_observations"
            ]:

                date = (
                    observation.get(
                        "date"
                    )
                    or "----------"
                )

                activity_id = (
                    observation.get(
                        "activity_id"
                    )
                )

                pace = format_pace(
                    observation.get(
                        "average_pace_100_s"
                    )
                )

                strokes = observation.get(
                    "average_strokes_per_length"
                )

                cadence = observation.get(
                    "average_cadence"
                )

                coverage = observation.get(
                    "technical_coverage"
                )

                strokes_text = (
                    f"{strokes:.1f}"
                    if strokes is not None
                    else "--"
                )

                cadence_text = (
                    f"{cadence:.1f}"
                    if cadence is not None
                    else "--"
                )

                coverage_text = (
                    f"{coverage * 100:.0f}%"
                    if coverage is not None
                    else "--"
                )

                print(
                    f"    {date} "
                    f"{activity_id}  "
                    f"pace={pace}  "
                    f"br/25={strokes_text}  "
                    f"cad={cadence_text}  "
                    f"tech={coverage_text}"
                )

    print()
    print(
        "=" * 80
    )

    print(
        f"Archivio: {output_file}"
    )


# ============================================================
# MAIN
# ============================================================

def main():

    limit = DEFAULT_LIMIT

    if len(sys.argv) >= 2:

        try:

            limit = int(
                sys.argv[1]
            )

        except ValueError:

            print(
                "Uso:"
            )

            print(
                "  history.py [numero_attività]"
            )

            print(
                "Esempio:"
            )

            print(
                "  history.py 20"
            )

            sys.exit(1)

    if limit < 1:

        print(
            "Il numero di attività deve essere >= 1"
        )

        sys.exit(1)

    DATA_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    try:

        history, output_file = (
            build_history(
                limit
            )
        )

        print_history_report(
            history,
            output_file
        )

    except Exception as exc:

        print(
            f"ERRORE: {exc}",
            file=sys.stderr
        )

        sys.exit(2)


if __name__ == "__main__":
    main()
