#!/bin/bash
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
    echo "Esegui come root: bash install_email_reports.sh"
    exit 1
fi

HERE="$(cd "$(dirname "$0")" && pwd)"
SCRIPT_SRC="$HERE/send_swim_coach_email.py"
if [ ! -f "$SCRIPT_SRC" ]; then
    echo "ERRORE: send_swim_coach_email.py non trovato in $HERE"
    exit 1
fi

if ! command -v sendmail >/dev/null 2>&1; then
    echo "ERRORE: sendmail non trovato. Verifica Postfix."
    exit 1
fi
if [ "$(postconf -h relayhost 2>/dev/null || true)" != "[smtp.gmail.com]:587" ]; then
    echo "ERRORE: Postfix non risulta configurato con relayhost [smtp.gmail.com]:587."
    exit 1
fi
if ! postmap -q '[smtp.gmail.com]:587' hash:/etc/postfix/sasl_passwd >/dev/null 2>&1; then
    echo "ERRORE: credenziali SMTP Gmail non trovate in /etc/postfix/sasl_passwd."
    exit 1
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="/opt/swim-coach/backups/email-reports-$STAMP"
mkdir -p "$BACKUP_DIR" /opt/swim-coach/data
for target in \
    /opt/swim-coach/send_swim_coach_email.py \
    /etc/swim-coach-email.conf \
    /etc/systemd/system/swim-coach-weekly.service \
    /etc/systemd/system/swim-coach-weekly.timer \
    /etc/systemd/system/swim-coach-reminder.service \
    /etc/systemd/system/swim-coach-reminder.timer; do
    if [ -f "$target" ]; then
        cp -a "$target" "$BACKUP_DIR/$(basename "$target").bak"
    fi
done

install -o root -g root -m 750 "$SCRIPT_SRC" /opt/swim-coach/send_swim_coach_email.py

if [ ! -f /etc/swim-coach-email.conf ]; then
    read -r -p "Indirizzo Gmail (mittente e destinatario): " EMAIL
    if [[ ! "$EMAIL" =~ ^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$ ]]; then
        echo "Indirizzo email non valido."
        exit 1
    fi
    umask 077
    cat > /etc/swim-coach-email.conf <<EOF
SWIM_COACH_EMAIL_TO=$EMAIL
SWIM_COACH_EMAIL_FROM=$EMAIL
SWIM_COACH_TIMEZONE=Europe/Rome
EOF
    chown root:root /etc/swim-coach-email.conf
    chmod 600 /etc/swim-coach-email.conf
else
    chmod 600 /etc/swim-coach-email.conf
    echo "Uso la configurazione email già presente in /etc/swim-coach-email.conf."
fi

for unit in swim-coach-weekly.service swim-coach-weekly.timer swim-coach-reminder.service swim-coach-reminder.timer; do
    install -o root -g root -m 644 "$HERE/$unit" "/etc/systemd/system/$unit"
done

python3 -m py_compile /opt/swim-coach/send_swim_coach_email.py
systemd-analyze verify \
    /etc/systemd/system/swim-coach-weekly.service \
    /etc/systemd/system/swim-coach-weekly.timer \
    /etc/systemd/system/swim-coach-reminder.service \
    /etc/systemd/system/swim-coach-reminder.timer
systemd-analyze calendar 'Sat *-*-* 08:00:00 Europe/Rome'
systemd-analyze calendar '*-*-* 18:00:00 Europe/Rome'
systemctl daemon-reload

printf '\nInstallazione completata. Backup: %s\n' "$BACKUP_DIR"
echo "I timer NON sono stati attivati. Prima verifica le anteprime senza inviare email:"
echo "  python3 /opt/swim-coach/send_swim_coach_email.py --weekly --dry-run"
echo "  python3 /opt/swim-coach/send_swim_coach_email.py --reminder --dry-run --date 2026-10-10"
echo "Dopo aver controllato l'anteprima, attiva i timer con:"
echo "  systemctl enable --now swim-coach-weekly.timer swim-coach-reminder.timer"
