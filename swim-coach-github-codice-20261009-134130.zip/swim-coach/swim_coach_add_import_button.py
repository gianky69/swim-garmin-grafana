#!/usr/bin/env python3
"""Add a safe manual-import button to the Swim Coach V1.4 web dashboard.

Default target is /opt/swim-coach. The patch backs up changed files and refuses
unknown source layouts rather than partially modifying the installation.
"""
from __future__ import annotations

import argparse
import py_compile
import shutil
import sys
from datetime import datetime
from pathlib import Path

DASHBOARD_OLD = '''body = f"""
{message_html}
<div class='card'>
<h2>Swim Coach</h2>
'''

DASHBOARD_NEW = '''body = f"""
{message_html}
<div class='card'>
<h2>Importazione manuale Garmin</h2>
<p>Controlla InfluxDB per individuare le attività di nuoto non ancora importate in Swim Coach, genera le analisi mancanti e aggiorna i report delle sedute di oggi.</p>
<p class='small'>Il pulsante legge le attività già presenti in InfluxDB/Garmin Grafana; non forza una sincronizzazione con Garmin Connect. Se l'attività non è ancora arrivata in InfluxDB, riprova dopo la sincronizzazione.</p>
<form method='post' action='/import-activities' onsubmit="return confirm('Cercare e importare le nuove attività disponibili in InfluxDB? L’operazione può richiedere qualche minuto.')">
<button type='submit' class='warnbtn'>Controlla e importa nuove attività</button>
</form>
</div>
<div class='card'>
<h2>Swim Coach</h2>
'''

POST_OLD = '''        path = parsed.path

        if path in ("/merge-activities/create", "/merge-activities/unmerge"):
'''

POST_NEW = '''        path = parsed.path

        if path == "/import-activities":
            command = [sys.executable, str(BASE_DIR / "import_new_activities.py")]
            try:
                result = subprocess.run(
                    command,
                    cwd=str(BASE_DIR),
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    timeout=900,
                    check=False,
                )
                output = result.stdout or "(Nessun output prodotto.)"
                if result.returncode == 0:
                    headline = "Importazione completata con successo."
                    status = HTTPStatus.OK
                else:
                    headline = f"Importazione terminata con codice {result.returncode}."
                    status = HTTPStatus.INTERNAL_SERVER_ERROR
            except subprocess.TimeoutExpired as exc:
                output = exc.stdout or ""
                if isinstance(output, bytes):
                    output = output.decode("utf-8", errors="replace")
                headline = "Tempo massimo superato: controlla i log e lo stato dell’importazione."
                status = HTTPStatus.GATEWAY_TIMEOUT
            except OSError as exc:
                output = str(exc)
                headline = "Impossibile avviare l’importazione."
                status = HTTPStatus.INTERNAL_SERVER_ERROR

            body = f"""
<div class='card'>
<h2>Importazione attività Garmin</h2>
<p class='notice'>{html.escape(headline)}</p>
<p class='small'>Sono mostrati al massimo gli ultimi 24.000 caratteri del log.</p>
<pre style='white-space:pre-wrap;overflow-wrap:anywhere;max-height:70vh;overflow:auto'>{html.escape(output[-24000:])}</pre>
<div class='toolbar'>
<a class='button' href='/'>Torna alla dashboard</a>
<a class='button secondary' href='/reports'>Apri i report</a>
</div>
</div>
"""
            self.send_html(render_page("Importazione attività", body), status)
            return

        if path in ("/merge-activities/create", "/merge-activities/unmerge"):
'''

IMPORT_LOCK_MARKER = '\nif __name__ == "__main__":\n'

LOCK_WRAPPER = '''

def main():
    """Serializza importazioni manuali e pianificate."""
    lock_path = BASE / ".import_new_activities.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+", encoding="utf-8") as lock_handle:
        try:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("Importazione già in corso; nessuna seconda esecuzione avviata.", file=sys.stderr)
            return 2
        try:
            return _main_unlocked()
        finally:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)

'''


def replace_once(source: str, old: str, new: str, label: str) -> str:
    count = source.count(old)
    if count != 1:
        raise RuntimeError(f"Patch interrotta: punto '{label}' trovato {count} volte, attese 1.")
    return source.replace(old, new, 1)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dir", type=Path, default=Path("/opt/swim-coach"))
    args = parser.parse_args()
    base = args.base_dir.resolve()
    web_file = base / "swim_coach_web.py"
    importer_file = base / "import_new_activities.py"

    for required in (web_file, importer_file):
        if not required.is_file():
            print(f"ERRORE: file richiesto mancante: {required}", file=sys.stderr)
            return 1

    web_src = web_file.read_text(encoding="utf-8")
    importer_src = importer_file.read_text(encoding="utf-8")

    if "/import-activities" in web_src or "Importazione manuale Garmin" in web_src:
        print("Il pulsante o la route di importazione sembra già installato; nessuna modifica effettuata.")
        return 0

    # Validate/prepare all edits in memory before touching any source file.
    web_new = replace_once(web_src, DASHBOARD_OLD, DASHBOARD_NEW, "scheda dashboard")
    web_new = replace_once(web_new, POST_OLD, POST_NEW, "route POST import-activities")

    if "def main():" not in importer_src:
        raise RuntimeError("Non trovo la funzione main() in import_new_activities.py.")
    if "import fcntl" in importer_src and ".import_new_activities.lock" in importer_src:
        importer_new = importer_src
    else:
        importer_new = replace_once(
            importer_src,
            "import json\nimport subprocess\n",
            "import fcntl\nimport json\nimport subprocess\n",
            "import fcntl",
        )
        importer_new = replace_once(
            importer_new,
            "def main():\n",
            "def _main_unlocked():\n",
            "rinomina main importatore",
        )
        importer_new = replace_once(
            importer_new,
            IMPORT_LOCK_MARKER,
            LOCK_WRAPPER + IMPORT_LOCK_MARKER,
            "wrapper lock importatore",
        )

    # Compile prospective source in memory before backup/writing.
    compile(web_new, str(web_file), "exec")
    compile(importer_new, str(importer_file), "exec")

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup_dir = base / "backups" / f"web-import-button-{stamp}"
    backup_dir.mkdir(parents=True, exist_ok=False)
    shutil.copy2(web_file, backup_dir / web_file.name)
    shutil.copy2(importer_file, backup_dir / importer_file.name)

    web_file.write_text(web_new, encoding="utf-8")
    importer_file.write_text(importer_new, encoding="utf-8")
    print("Modifiche applicate.")
    print(f"Backup: {backup_dir}")
    print("Aggiunto il pulsante nella dashboard e l'endpoint POST /import-activities.")
    print("Le importazioni manuali e pianificate ora usano un lock per evitare esecuzioni simultanee.")
    print("Verifica finale: python3 -m py_compile", web_file, importer_file)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERRORE: {exc}", file=sys.stderr)
        raise SystemExit(1)
