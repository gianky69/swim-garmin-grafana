#!/usr/bin/env python3
"""
swim_coach_web.py V1.4
------------------------
Web app locale per correggere i dati Garmin usati dal coach di nuoto.

V1.4 aggiunge/corregge:
- unione manuale di due lap/segmenti adiacenti nell'elenco dei lap, anche quando Garmin salta la numerazione
- operazioni di unione salvate separatamente dai dati Garmin originali
- validazione server della reale adiacenza dei lap
- pulsanti di unione senza form HTML annidati
- unione di due registrazioni Garmin della stessa data
- dashboard con pagine correzioni, report e allenamenti futuri

V1.1 aggiunge:
- correzione manuale della distanza di ogni lap a multipli di 25 m
- pulsanti -25 / +25 m per correggere rapidamente una vasca persa o extra
- possibilita' di escludere un lap impostando distanza corretta = 0
- visualizzazione della distanza Garmin e della distanza corretta
- ricalcolo del passo in base alla distanza corretta
- possibilita' di aggiungere una vasca/lap mancante con sola distanza
- correzioni persistenti separate dai dati Garmin originali

Le correzioni vengono salvate in:
    /opt/swim-coach/data/corrections.json

Il file originale swim_profile.json non viene mai modificato.
"""

from __future__ import annotations

import argparse
import html
import json
import mimetypes
import os
import subprocess
import sys
import threading
import urllib.parse
from datetime import datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from activity_merges import ACTIVITY_MERGES_FILE, load_activity_merges, save_activity_merges

BASE_DIR = Path("/opt/swim-coach")
DATA_DIR = BASE_DIR / "data"
PROFILE_FILE = DATA_DIR / "swim_profile.json"
CORRECTIONS_FILE = DATA_DIR / "corrections.json"
REPORT_DIR = BASE_DIR / "reports"
FUTURE_WORKOUTS_FILE = DATA_DIR / "upcoming_workouts.json"

DEFAULT_HOST = "0.0.0.0"
DEFAULT_PORT = 8090

STYLES = {
    "auto": "Automatico",
    "freestyle": "Stile libero",
    "backstroke": "Dorso",
    "breaststroke": "Rana",
    "butterfly": "Delfino",
    "mixed": "Misto",
    "unknown": "Sconosciuto",
}

EQUIPMENT = {
    "auto": "Automatico",
    "none": "Senza attrezzatura",
    "fins": "Pinne",
    "pull_buoy": "Pull buoy",
    "paddles": "Palette",
    "kickboard": "Tavoletta",
    "other": "Altra attrezzatura",
}

CLASSIFICATIONS = {
    "auto": "Automatico",
    "normal_swim": "Nuoto normale",
    "possible_special": "Drill / lavoro speciale",
    "artifact": "Errore / artefatto Garmin",
}

DISTANCE_OPTIONS = [0] + list(range(25, 401, 25))

CORRECTIONS_LOCK = threading.Lock()
FUTURE_WORKOUTS_LOCK = threading.Lock()


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def load_json(path: Path, default: Any):
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, path)


def load_profile() -> dict:
    data = load_json(PROFILE_FILE, {})
    return data if isinstance(data, dict) else {}


def load_corrections() -> dict:
    data = load_json(CORRECTIONS_FILE, {})
    return data if isinstance(data, dict) else {}


def correction_key(activity_id: str, lap: Any) -> str:
    return f"{activity_id}:{lap}"


def get_correction(corrections: dict, activity_id: str, lap: Any) -> dict:
    value = corrections.get(correction_key(activity_id, lap), {})
    return value if isinstance(value, dict) else {}


def effective_value(correction: dict, key: str, automatic: Any):
    value = correction.get(key)
    if value in (None, "", "auto"):
        return automatic
    return value


def parse_positive_float(value: Any) -> float | None:
    try:
        x = float(value)
        if x > 0:
            return x
    except (TypeError, ValueError):
        pass
    return None


def parse_distance(value: Any) -> int | None:
    try:
        x = int(float(value))
    except (TypeError, ValueError):
        return None
    if x < 0 or x % 25 != 0 or x > 400:
        return None
    return x


def fmt_time(seconds: Any) -> str:
    try:
        x = float(seconds)
    except (TypeError, ValueError):
        return "-"
    if x < 0:
        return "-"
    total = int(round(x))
    return f"{total // 60}:{total % 60:02d}"


def fmt_float(value: Any, digits: int = 1) -> str:
    try:
        return f"{float(value):.{digits}f}"
    except (TypeError, ValueError):
        return "-"


def fmt_pace_from_distance(elapsed_s: Any, distance_m: Any) -> str:
    try:
        elapsed = float(elapsed_s)
        distance = float(distance_m)
        if elapsed <= 0 or distance <= 0:
            return "-"
        return fmt_time(elapsed * 100.0 / distance)
    except (TypeError, ValueError):
        return "-"


def effective_distance(row: dict, corr: dict) -> float:
    original = parse_positive_float(row.get("distance_m")) or 0.0
    corrected = corr.get("distance_corrected_m")
    if corrected not in (None, ""):
        parsed = parse_distance(corrected)
        if parsed is not None:
            return float(parsed)
    return original


def corrected_distance_label(row: dict, corr: dict) -> str:
    original = parse_positive_float(row.get("distance_m")) or 0.0
    corrected = corr.get("distance_corrected_m")
    if corrected not in (None, ""):
        parsed = parse_distance(corrected)
        if parsed is not None:
            return f"{parsed} m"
    return f"{int(round(original))} m"


def merge_correction_key(activity_id: str, source_laps: list[int]) -> str:
    ordered = sorted({int(x) for x in source_laps})
    return f"{activity_id}:merge:{'-'.join(str(x) for x in ordered)}"


def get_merge_operations(corrections: dict, activity_id: str) -> list[dict]:
    prefix = f"{activity_id}:merge:"
    out = []
    for key, value in corrections.items():
        if not key.startswith(prefix) or not isinstance(value, dict):
            continue
        source_laps = value.get("source_laps", [])
        try:
            source_laps = sorted({int(x) for x in source_laps})
        except (TypeError, ValueError):
            continue
        if len(source_laps) < 2:
            continue
        item = dict(value)
        item["source_laps"] = source_laps
        item["key"] = key
        out.append(item)
    out.sort(key=lambda x: x["source_laps"][0])
    return out


def merged_lap_map(corrections: dict, activity_id: str) -> dict[int, dict]:
    mapping = {}
    for op in get_merge_operations(corrections, activity_id):
        source = op["source_laps"]
        target = source[0]
        for lap in source[1:]:
            mapping[lap] = {"target": target, "operation": op}
        mapping[target] = {"target": target, "operation": op}
    return mapping


def merge_lap_metrics(rows_by_lap: dict[int, dict], source_laps: list[int], corrections: dict, activity_id: str) -> dict:
    selected = [rows_by_lap[x] for x in source_laps if x in rows_by_lap]
    if len(selected) != len(source_laps):
        return {}

    distances = []
    elapsed = []
    strokes = []
    for row in selected:
        corr = get_correction(corrections, activity_id, int(row.get("lap", 0) or 0))
        d = effective_distance(row, corr)
        distances.append(d)
        try:
            elapsed.append(float(row.get("elapsed_s") or 0))
        except (TypeError, ValueError):
            elapsed.append(0.0)
        try:
            br25 = float(row.get("strokes_per_25"))
            lengths = max(1.0, d / 25.0)
            strokes.append(br25 * lengths)
        except (TypeError, ValueError):
            pass

    total_distance = sum(distances)
    total_elapsed = sum(elapsed)
    total_strokes = sum(strokes) if strokes else None
    merged = dict(selected[0])
    merged["lap"] = source_laps[0]
    merged["distance_m"] = total_distance
    merged["elapsed_s"] = total_elapsed
    if total_distance > 0 and total_strokes is not None:
        merged["strokes_per_25"] = total_strokes / (total_distance / 25.0)
    else:
        merged["strokes_per_25"] = None
    merged["pace_sec100"] = (total_elapsed * 100.0 / total_distance) if total_distance > 0 else None
    merged["merged"] = True
    merged["merged_source_laps"] = source_laps
    return merged


def correction_has_manual_distance(corr: dict) -> bool:
    value = corr.get("distance_corrected_m")
    return value not in (None, "") and parse_distance(value) is not None


def group_activities(profile: dict, corrections: dict):
    observations = profile.get("all_observations", [])
    if not isinstance(observations, list):
        observations = []

    grouped: dict[str, dict] = {}

    for row in observations:
        if not isinstance(row, dict):
            continue
        aid = str(row.get("activity_id", ""))
        if not aid:
            continue

        item = grouped.setdefault(
            aid,
            {
                "activity_id": aid,
                "date": row.get("date") or "",
                "name": row.get("activity_name") or "",
                "rows": [],
            },
        )
        item["rows"].append(row)

    activities = list(grouped.values())

    for item in activities:
        item["rows"].sort(key=lambda r: int(r.get("lap", 0) or 0))

        corrected = 0
        special = 0
        fins = 0
        artifacts = 0
        original_distance = 0.0
        effective_dist = 0.0
        duration = 0.0

        for row in item["rows"]:
            lap = int(row.get("lap", 0) or 0)
            corr = get_correction(corrections, item["activity_id"], lap)

            if corr:
                corrected += 1

            original_distance += float(row.get("distance_m", 0) or 0)
            effective_dist += effective_distance(row, corr)
            duration += float(row.get("elapsed_s", 0) or 0)

            eq = effective_value(corr, "equipment", "auto")
            if eq == "fins":
                fins += 1

            cls = effective_value(
                corr,
                "classification",
                row.get("classification", "normal_swim"),
            )
            if cls == "possible_special":
                special += 1
            if cls == "artifact" or effective_distance(row, corr) == 0:
                artifacts += 1

        manual_items = [
            value
            for key, value in corrections.items()
            if key.startswith(item["activity_id"] + ":manual:")
            and isinstance(value, dict)
        ]

        for manual in manual_items:
            d = parse_distance(manual.get("distance_corrected_m")) or 0
            effective_dist += d
            corrected += 1

        item["corrected"] = corrected
        item["fins"] = fins
        item["special"] = special
        item["artifacts"] = artifacts
        item["original_distance"] = original_distance
        item["distance"] = effective_dist
        item["duration"] = duration
        item["manual_missing_lengths"] = len(manual_items)

    activities.sort(
        key=lambda x: (
            x.get("date", ""),
            x.get("activity_id", ""),
        ),
        reverse=True,
    )
    return activities


def render_page(title: str, body: str) -> str:
    return f"""<!doctype html>
<html lang='it'>
<head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'>
<meta name='theme-color' content='#111827'>
<meta name='apple-mobile-web-app-capable' content='yes'>
<meta name='apple-mobile-web-app-status-bar-style' content='black-translucent'>
<meta name='apple-mobile-web-app-title' content='Swim Coach'>
<link rel='manifest' href='/manifest.webmanifest'>
<title>{html.escape(title)}</title>
<style>
:root {{ color-scheme: light dark; }}
body {{ font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; margin:0; background:#f4f6f8; color:#1f2937; }}
main {{ max-width:1500px; margin:auto; padding:20px; }}
header {{ background:#111827; color:#fff; padding:18px 20px; border-radius:14px; margin-bottom:18px; }}
h1,h2,h3 {{ margin-top:0; }}
a {{ color:inherit; }}
.card {{ background:#fff; border-radius:14px; padding:16px; margin-bottom:16px; box-shadow:0 2px 10px rgba(0,0,0,.07); }}
table {{ width:100%; border-collapse:collapse; }}
th,td {{ padding:8px 7px; border-bottom:1px solid #e5e7eb; text-align:left; vertical-align:middle; }}
th {{ background:#f9fafb; position:sticky; top:0; z-index:2; }}
select,input[type=text],input[type=number] {{ width:100%; box-sizing:border-box; padding:7px; border:1px solid #cbd5e1; border-radius:7px; background:#fff; color:#111827; }}
textarea {{ width:100%; box-sizing:border-box; min-height:50px; padding:7px; border:1px solid #cbd5e1; border-radius:7px; background:#fff; color:#111827; }}
button,.button {{ display:inline-block; border:0; border-radius:8px; padding:9px 14px; background:#2563eb; color:#fff; font-weight:600; cursor:pointer; text-decoration:none; }}
button.secondary,.button.secondary {{ background:#475569; }}
button.smallbtn {{ padding:5px 8px; font-size:.85em; }}
button.warnbtn {{ background:#b45309; }}
button.dangerbtn {{ background:#b91c1c; }}
.badge {{ display:inline-block; padding:3px 8px; border-radius:999px; background:#e2e8f0; margin-right:5px; font-size:.83em; }}
.badge.fins {{ background:#dbeafe; }}
.badge.special {{ background:#fef3c7; }}
.badge.artifact {{ background:#fee2e2; }}
.badge.corrected {{ background:#dcfce7; }}
.small {{ font-size:.88em; color:#64748b; }}
.grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(170px,1fr)); gap:10px; }}
.stat {{ padding:12px; background:#f8fafc; border-radius:10px; }}
.toolbar {{ display:flex; gap:8px; flex-wrap:wrap; align-items:center; }}
.sticky-actions {{ position:sticky; bottom:0; background:rgba(255,255,255,.96); padding:12px; border-top:1px solid #e5e7eb; margin-top:12px; z-index:5; }}
.notice {{ padding:10px 12px; border-radius:9px; background:#ecfeff; border:1px solid #a5f3fc; margin-bottom:14px; }}
.notice.warn {{ background:#fffbeb; border-color:#fde68a; }}
.distance-box {{ min-width:155px; }}
.distance-actions {{ display:flex; gap:4px; margin-top:4px; }}
.distance-actions button {{ flex:1; }}
.manual {{ background:#f0fdf4; }}
.original {{ font-size:.8em; color:#64748b; }}
.main-nav {{ display:flex; gap:8px; flex-wrap:wrap; margin:0 0 16px; }}
.main-nav a {{ display:inline-block; padding:8px 12px; background:#e2e8f0; border-radius:9px; text-decoration:none; font-weight:650; }}
.main-nav a:hover {{ background:#cbd5e1; }}
.nav-grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:14px; }}
.nav-card {{ display:block; text-decoration:none; border:1px solid #e2e8f0; border-radius:12px; padding:16px; background:#fff; min-height:110px; }}
.nav-card:hover {{ border-color:#93c5fd; box-shadow:0 3px 12px rgba(37,99,235,.10); }}
.nav-card h2 {{ font-size:1.08rem; margin-bottom:8px; }}
.nav-card p {{ color:#64748b; margin-bottom:0; }}
@media (max-width:850px) {{
  main {{ padding:12px; }}
  header {{ border-radius:12px; padding:14px 15px; margin-bottom:12px; }}
  header h1 {{ font-size:1.35rem; line-height:1.15; }}
  .card {{ padding:12px; border-radius:14px; margin-bottom:12px; }}
  .grid {{ grid-template-columns:repeat(2,minmax(0,1fr)); gap:8px; }}
  .toolbar {{ gap:6px; }}
  button,.button {{ min-height:42px; box-sizing:border-box; display:inline-flex; align-items:center; justify-content:center; padding:9px 12px; }}
  button.smallbtn {{ min-height:42px; padding:8px 10px; font-size:.95rem; }}
  select,input[type=text],input[type=number],textarea {{ min-height:42px; font-size:16px; }}
  .sticky-actions {{ bottom:0; padding:10px 0 calc(10px + env(safe-area-inset-bottom)); background:rgba(255,255,255,.97); margin-left:-2px; margin-right:-2px; }}
  .sticky-actions .button, .sticky-actions button {{ flex:1; }}
  .distance-actions {{ gap:6px; }}
  .distance-actions button {{ flex:1; }}

  .lap-table {{ width:100%; border-collapse:separate; border-spacing:0; font-size:1rem; }}
  .lap-table thead {{ display:none; }}
  .lap-table, .lap-table tbody, .lap-table tr, .lap-table td {{ display:block; width:100%; box-sizing:border-box; }}
  .lap-table tr {{ margin:10px 0; padding:9px; border:1px solid #dbe3ec; border-radius:14px; background:#fff; box-shadow:0 1px 5px rgba(15,23,42,.05); }}
  .lap-table tr.manual {{ border-left:4px solid #16a34a; }}
  .lap-table td {{ display:grid; grid-template-columns:92px minmax(0,1fr); gap:8px; padding:6px 2px; border:0; text-align:left; min-width:0 !important; }}
  .lap-table td::before {{ color:#64748b; font-size:.76rem; font-weight:700; text-transform:uppercase; align-self:center; }}
  .lap-table td:nth-child(1)::before {{ content:'Lap'; }}
  .lap-table td:nth-child(2)::before {{ content:'Distanza'; }}
  .lap-table td:nth-child(3)::before {{ content:'Tempo'; }}
  .lap-table td:nth-child(4)::before {{ content:'Passo'; }}
  .lap-table td:nth-child(5)::before {{ content:'Stile auto'; }}
  .lap-table td:nth-child(6)::before {{ content:'Br / 25'; }}
  .lap-table td:nth-child(7)::before {{ content:'Cadenza'; }}
  .lap-table td:nth-child(8)::before {{ content:'Stato'; }}
  .lap-table td:nth-child(9)::before {{ content:'Stile'; }}
  .lap-table td:nth-child(10)::before {{ content:'Attrezzatura'; }}
  .lap-table td:nth-child(11)::before {{ content:'Classificazione'; }}
  .lap-table td:nth-child(12)::before {{ content:'Nota'; }}
  .lap-table td:nth-child(1) {{ background:#f8fafc; border-radius:10px; margin-bottom:4px; padding:9px 8px; font-size:1.05rem; font-weight:800; }}
  .lap-table td:nth-child(2) {{ display:block; }}
  .lap-table td:nth-child(2)::before {{ display:block; margin-bottom:5px; }}
  .lap-table td:nth-child(2) .distance-box {{ min-width:0; }}
  .lap-table td:nth-child(8) {{ display:block; }}
  .lap-table td:nth-child(8)::before {{ display:block; margin-bottom:5px; }}
  .lap-table td:nth-child(8) .badge {{ margin-bottom:4px; }}
  .lap-table td:nth-child(12) input {{ width:100%; }}
  .lap-table td[colspan] {{ display:block; }}
  .lap-table td[colspan]::before {{ content:''; display:none; }}

  .activity-list-table {{ width:100%; border-collapse:separate; border-spacing:0; font-size:1rem; }}
  .activity-list-table thead {{ display:none; }}
  .activity-list-table, .activity-list-table tbody, .activity-list-table tr, .activity-list-table td {{ display:block; width:100%; box-sizing:border-box; }}
  .activity-list-table tr {{ margin:10px 0; padding:10px; border:1px solid #dbe3ec; border-radius:14px; background:#fff; }}
  .activity-list-table td {{ display:grid; grid-template-columns:85px minmax(0,1fr); gap:8px; padding:7px 3px; border:0; }}
  .activity-list-table td::before {{ color:#64748b; font-size:.76rem; font-weight:700; text-transform:uppercase; align-self:center; }}
  .activity-list-table td:nth-child(1)::before {{ content:'Data'; }}
  .activity-list-table td:nth-child(2)::before {{ content:'Nome'; }}
  .activity-list-table td:nth-child(3)::before {{ content:'Distanza'; }}
  .activity-list-table td:nth-child(4)::before {{ content:'Tempo'; }}
  .activity-list-table td:nth-child(5)::before {{ content:'Stato'; }}
  .activity-list-table td:nth-child(6)::before {{ content:'Apri'; }}
  .activity-list-table td:nth-child(6) {{ display:block; padding-top:10px; }}
  .activity-list-table td[colspan] {{ display:block; }}

  .original {{ font-size:.78rem; }}
  .small {{ font-size:.82rem; }}
}}

@media (max-width:420px) {{
  .grid {{ grid-template-columns:1fr; }}
  .lap-table td {{ grid-template-columns:82px minmax(0,1fr); }}
  .badge {{ font-size:.78rem; }}
}}
</style>
<script>
function changeDistance(lap, delta) {{
  const sel = document.getElementById('distance_' + lap);
  if (!sel) return;
  const current = parseInt(sel.value || '0', 10);
  let next = current + delta;
  if (next < 0) next = 0;
  if (next > 400) next = 400;
  sel.value = String(next);
  updatePreview(lap);
}}
function updatePreview(lap) {{
  const sel = document.getElementById('distance_' + lap);
  const time = document.getElementById('time_' + lap);
  const out = document.getElementById('pace_' + lap);
  if (!sel || !time || !out) return;
  const d = parseFloat(sel.value || '0');
  const t = parseFloat(time.dataset.seconds || '0');
  if (!d || !t) {{ out.textContent = '-'; return; }}
  const sec100 = t * 100 / d;
  const total = Math.round(sec100);
  out.textContent = Math.floor(total/60) + ':' + String(total%60).padStart(2,'0');
}}
function setAllDistanceDelta(delta) {{
  document.querySelectorAll('select[data-distance]').forEach(sel => {{
    const current = parseInt(sel.value || '0', 10);
    let next = current + delta;
    if (next < 0) next = 0;
    if (next > 400) next = 400;
    sel.value = String(next);
    const lap = sel.dataset.lap;
    updatePreview(lap);
  }});
}}
</script>
</head>
<body>
<main>
<header>
<div class='small' style='color:#cbd5e1'>SWIM COACH</div>
<h1 style='margin:2px 0'>{html.escape(title)}</h1>
<div style='color:#cbd5e1'>Correzioni manuali dei dati Garmin</div>
</header>
<nav class='main-nav' aria-label='Navigazione Swim Coach'>
<a href='/'>Home</a>
<a href='/corrections'>Correggi dati</a>
<a href='/merge-activities'>Unisci registrazioni</a>
<a href='/reports'>Report</a>
<a href='/future'>Allenamenti futuri</a>
</nav>
{body}
</main>
</body>
</html>"""


def option_html(mapping: dict, selected: str) -> str:
    out = []
    for key, label in mapping.items():
        sel = " selected" if key == selected else ""
        out.append(
            f"<option value='{html.escape(key)}'{sel}>{html.escape(label)}</option>"
        )
    return "".join(out)


def distance_option_html(selected: int) -> str:
    out = []
    for distance in DISTANCE_OPTIONS:
        label = "Escludi lap" if distance == 0 else f"{distance} m"
        sel = " selected" if distance == selected else ""
        out.append(
            f"<option value='{distance}'{sel}>{html.escape(label)}</option>"
        )
    return "".join(out)


def render_merge_summary(op: dict) -> str:
    source = ", ".join(str(x) for x in op.get("source_laps", []))
    distance = parse_distance(op.get("distance_corrected_m"))
    if distance is None:
        distance = 0
    return (
        f"<span class='badge corrected'>UNIONE: lap {html.escape(source)} → {distance} m</span>"
    )


def activity_page(activity: dict, corrections: dict, message: str = "") -> str:
    aid = activity["activity_id"]
    encoded_aid = urllib.parse.quote(aid, safe="")
    rows_html = []
    rows_by_lap = {int(r.get("lap", 0) or 0): r for r in activity["rows"]}
    merge_ops = get_merge_operations(corrections, aid)
    merge_map = merged_lap_map(corrections, aid)
    merged_targets = {op["source_laps"][0]: op for op in merge_ops}
    merged_sources = {lap for op in merge_ops for lap in op["source_laps"][1:]}

    activity_rows = activity["rows"]

    for row_index, row in enumerate(activity_rows):
        current_lap = int(row.get("lap", 0) or 0)
        if current_lap in merged_sources:
            continue

        if current_lap in merged_targets:
            op = merged_targets[current_lap]
            merged = merge_lap_metrics(rows_by_lap, op["source_laps"], corrections, aid)
            if merged:
                row = merged
        lap = int(row.get("lap", 0) or 0)
        corr = get_correction(corrections, aid, lap)

        automatic_style = row.get("style", "unknown") or "unknown"
        automatic_classification = (
            row.get("classification", "normal_swim")
            or "normal_swim"
        )

        selected_style = effective_value(
            corr,
            "style",
            automatic_style,
        )
        selected_equipment = effective_value(
            corr,
            "equipment",
            "auto",
        )
        selected_class = effective_value(
            corr,
            "classification",
            automatic_classification,
        )

        original_distance = int(
            round(float(row.get("distance_m", 0) or 0))
        )

        corrected_distance = corr.get("distance_corrected_m")
        corrected_parsed = parse_distance(corrected_distance)
        if corrected_parsed is None:
            corrected_parsed = original_distance

        note = corr.get("note", "") if isinstance(corr, dict) else ""

        effective_dist = float(corrected_parsed)
        elapsed = row.get("elapsed_s")

        if effective_dist > 0 and elapsed:
            effective_pace = fmt_pace_from_distance(
                elapsed,
                effective_dist,
            )
        else:
            effective_pace = "-"

        badges = []

        if original_distance != corrected_parsed:
            badges.append(
                "<span class='badge corrected'>DISTANZA CORRETTA</span>"
            )

        if automatic_classification != "normal_swim":
            badges.append(
                "<span class='badge special'>automatico: speciale</span>"
            )

        if selected_equipment == "fins":
            badges.append(
                "<span class='badge fins'>PINNE</span>"
            )

        if selected_class == "artifact" or corrected_parsed == 0:
            badges.append(
                "<span class='badge artifact'>ESCLUSO</span>"
            )
        elif selected_class == "possible_special":
            badges.append(
                "<span class='badge special'>SPECIALE</span>"
            )

        if current_lap in merged_targets:
            op = merged_targets[current_lap]
            badges.append(render_merge_summary(op))
        elif current_lap in merge_map:
            badges.append("<span class='badge corrected'>PARTE DI UNIONE</span>")

        if corr:
            badges.append(
                "<span class='badge corrected'>CORRETTO</span>"
            )

        merge_button = ""

        if current_lap in merged_targets:
            op = merged_targets[current_lap]
            merge_key = html.escape(op["key"], quote=True)
            merge_button = (
                f"<button type='submit' class='smallbtn secondary' "
                f"formmethod='post' "
                f"formaction='/activity/{encoded_aid}/unmerge' "
                f"name='key' value='{merge_key}'>"
                f"Annulla unione"
                f"</button>"
            )

        next_lap = None
        if row_index + 1 < len(activity_rows):
            next_lap = int(
                activity_rows[row_index + 1].get("lap", 0) or 0
            )

        if (
            next_lap is not None
            and current_lap not in merged_targets
            and current_lap not in merged_sources
        ):
            next_is_merged = next_lap in merge_map
            if not next_is_merged:
                merge_button = (
                    f"<button type='submit' class='smallbtn warnbtn' "
                    f"formmethod='post' "
                    f"formaction='/activity/{encoded_aid}/merge' "
                    f"name='merge_pair' value='{current_lap},{next_lap}' "
                    f"onclick='return confirm(\"Unire lap {current_lap} + {next_lap} "
                    f"come una sola ripetuta?\")'>"
                    f"Unisci con lap {next_lap}"
                    f"</button>"
                )

        rows_html.append(
            f"""
<tr>
<td>{lap}</td>
<td>
  <div class='distance-box'>
    <select id='distance_{lap}' data-distance data-lap='{lap}' name='distance_{lap}' onchange='updatePreview({lap})'>
      {distance_option_html(corrected_parsed)}
    </select>
    <div class='distance-actions'>
      <button type='button' class='smallbtn secondary' onclick='changeDistance({lap},-25)'>−25</button>
      <button type='button' class='smallbtn secondary' onclick='changeDistance({lap},25)'>+25</button>
    </div>
    <div class='original'>Garmin: {original_distance} m</div>
  </div>
</td>
<td><span id='time_{lap}' data-seconds='{html.escape(str(elapsed or 0))}'>{fmt_time(elapsed)}</span></td>
<td>{fmt_time(row.get('pace_sec100'))}<br><span class='small'>corretto: <b id='pace_{lap}'>{effective_pace}</b></span></td>
<td>{html.escape(style_name(row.get('style', 'unknown')))}</td>
<td>{fmt_float(row.get('strokes_per_25'))}</td>
<td>{fmt_float(row.get('cadence'))}</td>
<td>{' / '.join(badges)}{merge_button}</td>
<td style='min-width:150px'>
<select name='style_{lap}'>
{option_html(STYLES, selected_style)}
</select>
</td>
<td style='min-width:160px'>
<select name='equipment_{lap}'>
{option_html(EQUIPMENT, selected_equipment)}
</select>
</td>
<td style='min-width:180px'>
<select name='classification_{lap}'>
{option_html(CLASSIFICATIONS, selected_class)}
</select>
</td>
<td><input type='text' name='note_{lap}' value='{html.escape(note, quote=True)}' placeholder='Nota'></td>
</tr>
"""
        )

    manual_rows = []

    for key, corr in corrections.items():
        prefix = aid + ":manual:"
        if not key.startswith(prefix) or not isinstance(corr, dict):
            continue

        distance = parse_distance(corr.get("distance_corrected_m")) or 0
        if distance <= 0:
            continue

        manual_id = key[len(prefix):]
        manual_rows.append(
            f"""
<tr class='manual'>
<td>+vasca</td>
<td><b>{distance} m</b><br><span class='small'>aggiunta manualmente</span></td>
<td>-</td>
<td>-</td>
<td>{html.escape(style_name(corr.get('style','unknown')))}</td>
<td>-</td>
<td>-</td>
<td><span class='badge corrected'>MANUALE</span></td>
<td colspan='4'>{html.escape(corr.get('note','Vasca mancante Garmin'))} <a class='button secondary' href='/activity/{urllib.parse.quote(aid, safe="")}/manual-delete/{urllib.parse.quote(manual_id, safe="")}' style='padding:5px 8px;font-size:.85em'>Rimuovi</a></td>
</tr>
"""
        )

    message_html = (
        f"<div class='notice'>{html.escape(message)}</div>"
        if message
        else ""
    )

    body = f"""
<div class='toolbar' style='margin-bottom:12px'>
<a class='button secondary' href='/'>← Attività</a>
<a class='button secondary' href='/api/corrections/download?activity_id={urllib.parse.quote(aid)}'>JSON correzioni</a>
</div>
{message_html}

<div class='card'>
<div class='grid'>
<div class='stat'><b>Attività</b><br>{html.escape(aid)}</div>
<div class='stat'><b>Data</b><br>{html.escape(activity.get('date','-'))}</div>
<div class='stat'><b>Nome</b><br>{html.escape(activity.get('name','-'))}</div>
<div class='stat'><b>Distanza Garmin</b><br>{int(round(activity.get('original_distance',0)))} m</div>
<div class='stat'><b>Distanza corretta</b><br><b>{int(round(activity.get('distance',0)))} m</b></div>
<div class='stat'><b>Tempo lap</b><br>{fmt_time(activity.get('duration'))}</div>
<div class='stat'><b>Correzioni</b><br>{activity.get('corrected',0)}</div>
<div class='stat'><b>Vasche manuali</b><br>{activity.get('manual_missing_lengths',0)}</div>
<div class='stat'><b>Unioni</b><br>{len(merge_ops)}</div>
</div>
</div>

<div class='card'>
<h2>Correggi lap</h2>
<p class='small'>La colonna "Distanza" modifica solo la distanza utilizzata dal coach. Il dato Garmin originale resta visibile e intatto.</p>
<p class='small'><b>Unione:</b> quando Garmin ha spezzato una ripetuta in più segmenti consecutivi, usa <b>Unisci con lap successivo</b>. I lap sono considerati consecutivi in base alla loro posizione nell'elenco, anche se Garmin salta alcuni numeri di lap. L'unione salva i lap originali e crea un'operazione separata; tempo e distanza della ripetuta risultante vengono sommati.</p>
<p class='small'>Usa <b>+25</b> quando Garmin ha perso una vasca all'interno del lap; <b>−25</b> quando ne ha registrata una in più. Impostando <b>Escludi lap</b> il record viene ignorato nelle elaborazioni successive.</p>
<div class='toolbar' style='margin-bottom:10px'>
<span class='small'>Regolazione rapida di tutti i lap:</span>
<button type='button' class='smallbtn secondary' onclick='setAllDistanceDelta(-25)'>−25 m tutti</button>
<button type='button' class='smallbtn secondary' onclick='setAllDistanceDelta(25)'>+25 m tutti</button>
</div>
<form method='post' action='/activity/{urllib.parse.quote(aid, safe="")}/save'>
<div style='overflow:auto'>
<table class='lap-table'>
<thead><tr>
<th>Lap</th><th>Distanza corretta</th><th>Tempo</th><th>Passo Garmin / corretto</th><th>Stile auto</th><th>Br/25</th><th>Cad.</th><th>Stato</th>
<th style='min-width:160px'>Stile</th><th style='min-width:170px'>Attrezzatura</th><th style='min-width:190px'>Classificazione</th><th>Nota</th>
</tr></thead>
<tbody>{''.join(rows_html)}{''.join(manual_rows)}</tbody>
</table>
</div>
<div class='sticky-actions'>
<button type='submit'>Salva tutte le correzioni</button>
<a class='button secondary' href='/activity/{urllib.parse.quote(aid, safe="")}'>Ricarica</a>
</div>
</form>
</div>

<div class='card'>
<h2>Aggiungi una vasca mancante</h2>
<p class='small'>Usa questa funzione quando Garmin ha completamente perso una vasca e quindi non esiste un lap da modificare. La vasca aggiunta contribuisce alla distanza corretta, ma non inventa tempo, bracciate o cadenza.</p>
<form method='post' action='/activity/{urllib.parse.quote(aid, safe="")}/manual-add'>
<div class='grid'>
<div><label>Distanza<br><select name='distance'>{''.join(f"<option value='{d}'>{d} m</option>" for d in range(25,101,25))}</select></label></div>
<div><label>Stile<br><select name='style'>{option_html(STYLES, 'auto')}</select></label></div>
<div><label>Attrezzatura<br><select name='equipment'>{option_html(EQUIPMENT, 'auto')}</select></label></div>
<div><label>Nota<br><input type='text' name='note' value='Vasca mancante Garmin'></label></div>
</div>
<div style='margin-top:10px'><button type='submit'>+ Aggiungi vasca</button></div>
</form>
</div>
"""

    return render_page(
        f"Seduta {activity.get('name') or aid}",
        body,
    )


def style_name(value: str) -> str:
    return STYLES.get(
        value,
        value.upper() if value else "-",
    )


def home_page(profile: dict, corrections: dict, message: str = "") -> str:
    activities = group_activities(
        profile,
        corrections,
    )

    message_html = (
        f"<div class='notice'>{html.escape(message)}</div>"
        if message
        else ""
    )

    rows = []

    for act in activities:
        aid = act["activity_id"]
        badges = []

        if act["corrected"]:
            badges.append(
                f"<span class='badge corrected'>{act['corrected']} correzioni</span>"
            )

        if act["fins"]:
            badges.append(
                f"<span class='badge fins'>{act['fins']} lap pinne</span>"
            )

        if act["special"]:
            badges.append(
                f"<span class='badge special'>{act['special']} speciali</span>"
            )

        if act["artifacts"]:
            badges.append(
                f"<span class='badge artifact'>{act['artifacts']} esclusi</span>"
            )

        if act["manual_missing_lengths"]:
            badges.append(
                f"<span class='badge corrected'>+{act['manual_missing_lengths']} vasche</span>"
            )

        original = int(round(act["original_distance"]))
        effective = int(round(act["distance"]))

        distance_cell = (
            f"{original} m"
            if original == effective
            else f"<span class='original'>{original} m</span> → <b>{effective} m</b>"
        )

        rows.append(
            f"""
<tr>
<td>{html.escape(act.get('date','-'))}</td>
<td>{html.escape(act.get('name','-'))}</td>
<td>{distance_cell}</td>
<td>{fmt_time(act.get('duration'))}</td>
<td>{''.join(badges) or '<span class="small">nessuna</span>'}</td>
<td><a class='button' href='/activity/{urllib.parse.quote(aid, safe="")}'>Apri</a></td>
</tr>
"""
        )

    body = f"""
{message_html}
<div class='toolbar' style='margin-bottom:12px'>
<a class='button secondary' href='/'>← Dashboard</a>
<a class='button secondary' href='/merge-activities'>Unisci registrazioni dello stesso giorno</a>
</div>
<div class='card'>
<h2>Correggi dati Garmin</h2>
<p class='small'>Fonte: dati Garmin normalizzati in swim_profile.json. Le correzioni restano separate e verranno applicate anche al motore di analisi.</p>
<div style='overflow:auto'>
<table class='activity-list-table'>
<thead><tr><th>Data</th><th>Nome</th><th>Distanza Garmin → corretta</th><th>Tempo</th><th>Stato</th><th></th></tr></thead>
<tbody>{''.join(rows) if rows else '<tr><td colspan="6">Nessuna attività disponibile.</td></tr>'}</tbody>
</table>
</div>
</div>

<div class='card'>
<h2>Correzioni disponibili</h2>
<p><b>Pinne / attrezzatura:</b> indica l'attrezzatura usata nella singola ripetuta.</p>
<p><b>Stile:</b> correggi eventuali errori di riconoscimento Garmin.</p>
<p><b>Distanza:</b> correggi una vasca persa o aggiunta, oppure escludi un lap errato.</p>
<p><b>Vasca mancante:</b> aggiungi 25/50/75/100 m quando Garmin ha completamente perso una porzione della seduta.</p>
<p class='small'>Le correzioni vengono salvate separatamente dai dati Garmin originali.</p>
</div>
"""

    return render_page(
        "Correzioni allenamenti",
        body,
    )


def read_upcoming_workouts() -> list[dict]:
    data = load_json(FUTURE_WORKOUTS_FILE, {})
    if isinstance(data, list):
        values = data
    elif isinstance(data, dict):
        values = data.get("workouts", data.get("sessions", []))
    else:
        values = []
    return [item for item in values if isinstance(item, dict)] if isinstance(values, list) else []


def dashboard_page(profile: dict, corrections: dict, message: str = "") -> str:
    merge_data = load_activity_merges()
    workouts = read_upcoming_workouts()
    reports = [p for p in REPORT_DIR.glob("swim-report-*.html") if p.is_file()] if REPORT_DIR.exists() else []
    message_html = f"<div class='notice'>{html.escape(message)}</div>" if message else ""
    cards = [
        ("/corrections", "Correggi i dati", "Apri una seduta e correggi distanza, stile, attrezzatura, classificazione o lap mancanti."),
        ("/merge-activities", "Unisci registrazioni", "Accorpa due registrazioni Garmin della stessa data quando la seduta è stata interrotta per errore."),
        ("/reports", "Report degli allenamenti", f"Consulta i report locali TXT e HTML. Report disponibili: {len(reports)}."),
        ("/future", "Allenamenti futuri", f"Visualizza le sedute programmate. Allenamenti in programma: {len(workouts)}."),
    ]
    cards_html = "".join(
        f"<a class='nav-card' href='{url}'><h2>{html.escape(title)}</h2><p>{html.escape(description)}</p></a>"
        for url, title, description in cards
    )
    body = f"""
{message_html}
<div class='card'>
<h2>Importazione manuale Garmin</h2>
<p>Controlla InfluxDB per individuare le attività di nuoto non ancora importate in Swim Coach, genera le analisi mancanti e aggiorna i report delle sedute di oggi.</p>
<p class='small'>Il pulsante legge le attività già presenti in InfluxDB/Garmin Grafana; non forza una sincronizzazione con Garmin Connect. Se l'attività non è ancora arrivata in InfluxDB, riprova dopo la sincronizzazione.</p>
<form method='post' action='/import-activities' onsubmit="return confirm('Cercare e importare le nuove attività disponibili in InfluxDB? L’operazione può richiedere qualche minuto.')">
<button type='submit' class='warnbtn'>Controlla e importa nuove attività</button>
</form>
</div>
<div class='card'>
<h2>Swim Coach</h2>
<p>Seleziona cosa vuoi fare. Le correzioni e le unioni vengono conservate separatamente dai dati originali Garmin.</p>
<div class='nav-grid'>{cards_html}</div>
</div>
<div class='grid'>
<div class='stat'><b>Versione profilo</b><br>{html.escape(str(profile.get('version', '—')))}</div>
<div class='stat'><b>Attività disponibili</b><br>{len({str(r.get('activity_id')) for r in profile.get('all_observations', []) if isinstance(r, dict)})}</div>
<div class='stat'><b>Correzioni salvate</b><br>{len(corrections)}</div>
<div class='stat'><b>Registrazioni unite</b><br>{len(merge_data.get('merges', []))}</div>
</div>
<div class='card'>
<h2>Ultimo report</h2>
<p class='small'>I report sono file locali e vengono aggiornati con il comando unico di aggiornamento.</p>
{f"<a class='button' href='/reports'>Apri i report</a>" if reports else "<p>Non ci sono ancora report HTML nella cartella reports.</p>"}
</div>
"""
    return render_page("Swim Coach — Home", body)


def activity_merge_page(profile: dict, corrections: dict, message: str = "") -> str:
    activities = group_activities(profile, corrections)
    by_id = {str(a["activity_id"]): a for a in activities}
    merge_data = load_activity_merges()
    merge_entries = merge_data.get("merges", [])
    already_used = {str(aid) for entry in merge_entries for aid in entry.get("activity_ids", [])}
    by_date: dict[str, list[dict]] = {}
    for act in activities:
        date = str(act.get("date") or "")
        if date and act["activity_id"] not in already_used:
            by_date.setdefault(date, []).append(act)
    message_html = f"<div class='notice'>{html.escape(message)}</div>" if message else ""
    forms = []
    for date, day_activities in sorted(by_date.items(), reverse=True):
        if len(day_activities) < 2:
            continue
        day_activities.sort(key=lambda a: (a.get("name", ""), a.get("activity_id", "")))
        options = []
        for act in day_activities:
            label = f"{act.get('name') or 'Attività'} — {int(round(act.get('distance', 0)))} m — {fmt_time(act.get('duration'))} — ID {act['activity_id']}"
            options.append(f"<option value='{html.escape(str(act['activity_id']), quote=True)}'>{html.escape(label)}</option>")
        options_html = "".join(options)
        a0 = html.escape(str(day_activities[0]["activity_id"]), quote=True)
        b0 = html.escape(str(day_activities[1]["activity_id"]), quote=True)
        forms.append(f"""
<div class='card'>
<h2>{html.escape(date)}</h2>
<p class='small'>Scegli prima la registrazione che deve comparire per prima nella seduta, poi la registrazione da accodare. È consentito unire solo due attività della stessa data; ogni registrazione può appartenere a una sola unione.</p>
<form method='post' action='/merge-activities/create' onsubmit="return confirm('Unire le due registrazioni come un solo allenamento? L’operazione sarà reversibile.')">
<input type='hidden' name='date' value='{html.escape(date, quote=True)}'>
<div class='grid'>
<div><label>Registrazione iniziale<select name='activity_a'>{options_html.replace("<option value='" + a0 + "'", "<option selected value='" + a0 + "'", 1)}</select></label></div>
<div><label>Registrazione da accodare<select name='activity_b'>{options_html.replace("<option value='" + b0 + "'", "<option selected value='" + b0 + "'", 1)}</select></label></div>
</div>
<p style='margin-bottom:0'><button type='submit' class='warnbtn'>Unisci le registrazioni</button></p>
</form>
</div>
""")
    if not forms:
        forms_html = "<div class='card'><p>Non risultano due registrazioni ancora disponibili nella stessa data. Quando Garmin crea due attività separate nello stesso giorno, compariranno qui.</p></div>"
    else:
        forms_html = "".join(forms)

    active_rows = []
    for entry in merge_entries:
        ids = entry.get("activity_ids", [])
        if len(ids) != 2:
            continue
        a = by_id.get(str(ids[0]), {})
        b = by_id.get(str(ids[1]), {})
        date = str(entry.get("date") or a.get("date") or b.get("date") or "—")
        a_label = f"{a.get('name') or ids[0]} (ID {ids[0]})"
        b_label = f"{b.get('name') or ids[1]} (ID {ids[1]})"
        active_rows.append(f"""
<tr><td>{html.escape(date)}</td><td>{html.escape(a_label)} + {html.escape(b_label)}</td><td>
<form method='post' action='/merge-activities/unmerge' onsubmit="return confirm('Annullare questa unione? I dati originali resteranno disponibili.')">
<input type='hidden' name='merge_id' value='{html.escape(str(entry.get('merge_id', '')), quote=True)}'>
<button type='submit' class='secondary smallbtn'>Annulla unione</button>
</form></td></tr>
""")
    active_html = "".join(active_rows) or "<tr><td colspan='3'>Nessuna registrazione unita.</td></tr>"
    body = f"""
{message_html}
<div class='toolbar' style='margin-bottom:12px'><a class='button secondary' href='/'>← Dashboard</a></div>
<div class='card'><h2>Unisci registrazioni dello stesso giorno</h2>
<p>Usa questa funzione quando la registrazione Garmin viene interrotta per errore e riprendi a nuotare creando una seconda attività. L'unione riguarda il profilo del coach e i report; i due originali restano visibili nella pagina di correzione.</p></div>
{forms_html}
<div class='card'><h2>Unioni attive</h2><div style='overflow:auto'><table><thead><tr><th>Data</th><th>Registrazioni unite</th><th>Operazione</th></tr></thead><tbody>{active_html}</tbody></table></div></div>
"""
    return render_page("Unisci registrazioni", body)


def reports_page(message: str = "") -> str:
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    txt_by_stem = {p.stem: p for p in REPORT_DIR.glob("swim-report-*.txt") if p.is_file()}
    html_by_stem = {p.stem: p for p in REPORT_DIR.glob("swim-report-*.html") if p.is_file()}
    # Se una registrazione è la seconda metà di una sessione unita, nascondi
    # il suo vecchio report autonomo finché l'unione è attiva.
    secondary_ids = {
        str(entry.get("activity_ids", ["", ""])[1])
        for entry in load_activity_merges().get("merges", [])
        if isinstance(entry, dict) and len(entry.get("activity_ids", [])) == 2
    }
    all_stems = set(txt_by_stem) | set(html_by_stem)
    stems = [stem for stem in all_stems if stem.rsplit("-", 1)[-1] not in secondary_ids]
    stems.sort(key=lambda stem: max((p.stat().st_mtime for p in (txt_by_stem.get(stem), html_by_stem.get(stem)) if p), default=0), reverse=True)
    rows = []
    for stem in stems:
        txt_path = txt_by_stem.get(stem)
        html_path = html_by_stem.get(stem)
        timestamp = max((p.stat().st_mtime for p in (txt_path, html_path) if p), default=0)
        date_label = datetime.fromtimestamp(timestamp).astimezone().strftime("%Y-%m-%d %H:%M") if timestamp else "—"
        links = []
        if html_path:
            links.append(f"<a class='button' href='/reports/file/{urllib.parse.quote(html_path.name)}'>Apri HTML</a>")
        if txt_path:
            links.append(f"<a class='button secondary' href='/reports/file/{urllib.parse.quote(txt_path.name)}'>Apri TXT</a>")
        rows.append(f"<tr><td>{html.escape(date_label)}</td><td>{html.escape(stem)}</td><td>{' '.join(links)}</td></tr>")
    table_body = "".join(rows) or "<tr><td colspan='3'>Nessun report disponibile. Esegui update_swim_coach.py per generare il primo report.</td></tr>"
    message_html = f"<div class='notice'>{html.escape(message)}</div>" if message else ""
    body = f"""
{message_html}
<div class='toolbar' style='margin-bottom:12px'><a class='button secondary' href='/'>← Dashboard</a></div>
<div class='card'><h2>Report degli allenamenti</h2><p class='small'>I report sono locali. Le vecchie versioni archiviate non vengono mostrate in questo elenco; restano nella cartella reports/archive.</p>
<div style='overflow:auto'><table><thead><tr><th>Generato</th><th>Report</th><th>Apri</th></tr></thead><tbody>{table_body}</tbody></table></div></div>
"""
    return render_page("Report allenamenti", body)


def future_workouts_page(message: str = "") -> str:
    """Show future workouts with edit, add and delete forms."""
    workouts = read_upcoming_workouts()
    cards = []

    def set_lines_for(workout: dict) -> list[str]:
        values = workout.get("sets", workout.get("main_set", []))
        if not isinstance(values, list):
            return []
        result = []
        for item in values:
            if isinstance(item, dict):
                parts = [
                    str(item.get(k))
                    for k in ("reps", "distance_m", "description", "pace", "rest")
                    if item.get(k) not in (None, "")
                ]
                if parts:
                    result.append(" · ".join(parts))
            elif str(item).strip():
                result.append(str(item).strip())
        return result

    def field(label: str, name: str, value: object, input_type: str = "text") -> str:
        return (
            f"<label style='display:block;margin:8px 0'>{html.escape(label)}"
            f"<input type='{input_type}' name='{name}' value='{html.escape(str(value or ''), quote=True)}' "
            "style='display:block;box-sizing:border-box;width:100%;max-width:100%;padding:8px;margin-top:4px' "
            "required></label>"
        )

    def editor_form(workout: dict, index: int, is_new: bool = False) -> str:
        workout_id = str(workout.get("id") or "")
        date_value = str(workout.get("date") or workout.get("scheduled_date") or "")
        title_value = str(workout.get("title") or workout.get("name") or "")
        distance_value = workout.get("distance_m", 2000)
        focus_value = str(workout.get("focus") or workout.get("goal") or "")
        notes_value = str(workout.get("notes") or workout.get("description") or "")
        sets_text = "\n".join(set_lines_for(workout))
        heading = "Nuova seduta" if is_new else f"Seduta {index}: {title_value or workout_id}"
        buttons = (
            "<button type='submit' name='action' value='add'>Aggiungi seduta</button>"
            if is_new else
            "<button type='submit' name='action' value='save'>Salva modifiche</button> "
            "<button type='submit' name='action' value='delete' class='warnbtn' "
            "onclick=\"return confirm('Eliminare questa seduta dal calendario?')\">Elimina seduta</button>"
        )
        hidden_id = "" if is_new else f"<input type='hidden' name='workout_id' value='{html.escape(workout_id, quote=True)}'>"
        distance_html = (
            f"<label style='display:block;margin:8px 0'>Distanza prevista (m)"
            f"<input type='number' name='distance_m' min='25' max='10000' step='25' "
            f"value='{html.escape(str(distance_value), quote=True)}' required "
            "style='display:block;box-sizing:border-box;width:100%;max-width:100%;padding:8px;margin-top:4px'></label>"
        )
        return (
            "<div class='card'>"
            f"<h2>{html.escape(heading)}</h2>"
            "<form method='post' action='/future/save'>"
            f"{hidden_id}"
            f"{field('Data', 'date', date_value, 'date')}"
            f"{field('Titolo', 'title', title_value)}"
            f"{distance_html}"
            f"{field('Obiettivo', 'focus', focus_value)}"
            "<label style='display:block;margin:8px 0'>Note"
            f"<textarea name='notes' rows='3' style='display:block;box-sizing:border-box;width:100%;max-width:100%;padding:8px;margin-top:4px'>{html.escape(notes_value)}</textarea></label>"
            "<label style='display:block;margin:8px 0'>Blocchi dell'allenamento "
            "<span class='small'>(una serie per riga; specifica stile, pinne e recupero)</span>"
            f"<textarea name='sets' rows='9' required style='display:block;box-sizing:border-box;width:100%;max-width:100%;padding:8px;margin-top:4px'>{html.escape(sets_text)}</textarea></label>"
            f"<p>{buttons}</p>"
            "</form></div>"
        )

    for index, workout in enumerate(
        sorted(workouts, key=lambda item: (str(item.get("date") or item.get("scheduled_date") or "9999-12-31"), str(item.get("title") or item.get("name") or ""))),
        start=1,
    ):
        cards.append(editor_form(workout, index))

    new_workout = {
        "date": "",
        "title": "",
        "distance_m": 2000,
        "focus": "",
        "notes": "",
        "sets": [],
    }
    message_html = f"<div class='notice'>{html.escape(message)}</div>" if message else ""
    intro = (
        "<div class='card'><h2>Programmazione degli allenamenti</h2>"
        "<p>Modifica le sedute, cambia la data, aggiungi una nuova seduta oppure elimina quella non più prevista. "
        "Le modifiche sono salvate in un file JSON separato dai dati Garmin. Prima di ogni salvataggio viene creata una copia di sicurezza.</p>"
        "<p class='small'>Inserisci una serie per riga. Il recupero va scritto nella descrizione della serie, per esempio: «recupero 20 s».</p></div>"
    )
    return render_page(
        "Allenamenti futuri",
        f"{message_html}<div class='toolbar' style='margin-bottom:12px'><a class='button secondary' href='/'>← Dashboard</a></div>"
        f"{intro}{''.join(cards)}{editor_form(new_workout, 0, True)}",
    )

def rebuild_after_activity_merge(activity_id: str) -> tuple[bool, str]:
    updater = BASE_DIR / "update_swim_coach.py"
    if not updater.is_file():
        return False, "Unione salvata, ma update_swim_coach.py non è presente: esegui l'aggiornamento manualmente."
    try:
        result = subprocess.run(
            [sys.executable, str(updater), "--activity-id", str(activity_id)],
            cwd=str(BASE_DIR), text=True, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, timeout=180, check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, f"Unione salvata, aggiornamento automatico non completato: {exc}. Esegui update_swim_coach.py manualmente."
    if result.returncode != 0:
        tail = (result.stdout or "").strip()[-500:]
        print("Aggiornamento post-unione fallito:\n" + tail)
        return False, "Unione salvata, ma profilo/report non aggiornati. Esegui update_swim_coach.py dal terminale."
    return True, "Profilo e report aggiornati automaticamente."


class Handler(BaseHTTPRequestHandler):
    server_version = "SwimCoachWeb/1.4"

    def log_message(self, fmt, *args):
        print(
            f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] "
            f"{self.address_string()} {fmt % args}"
        )

    def send_html(
        self,
        body: str,
        status=HTTPStatus.OK,
    ):
        data = body.encode("utf-8")
        self.send_response(status)
        self.send_header(
            "Content-Type",
            "text/html; charset=utf-8",
        )
        self.send_header(
            "Content-Length",
            str(len(data)),
        )
        self.end_headers()
        self.wfile.write(data)

    def send_manifest(self):
        payload = {
            "name": "Swim Coach",
            "short_name": "Swim Coach",
            "start_url": "/",
            "display": "standalone",
            "background_color": "#f4f6f8",
            "theme_color": "#111827",
            "lang": "it",
            "description": "Correzione dati Garmin per Swim Coach",
            "icons": [],
        }
        data = json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
        ).encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header(
            "Content-Type",
            "application/manifest+json; charset=utf-8",
        )
        self.send_header(
            "Cache-Control",
            "no-cache",
        )
        self.send_header(
            "Content-Length",
            str(len(data)),
        )
        self.end_headers()
        self.wfile.write(data)

    def send_json(
        self,
        payload,
        status=HTTPStatus.OK,
    ):
        data = json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
        ).encode("utf-8")

        self.send_response(status)
        self.send_header(
            "Content-Type",
            "application/json; charset=utf-8",
        )
        self.send_header(
            "Content-Length",
            str(len(data)),
        )
        self.end_headers()
        self.wfile.write(data)

    def redirect(self, location):
        self.send_response(
            HTTPStatus.SEE_OTHER
        )
        self.send_header(
            "Location",
            location,
        )
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(
            self.path
        )

        path = parsed.path
        query = urllib.parse.parse_qs(
            parsed.query
        )

        profile = load_profile()
        corrections = load_corrections()

        if path == "/manifest.webmanifest":
            self.send_manifest()
            return

        if path == "/":
            message = query.get("message", [""])[0]
            self.send_html(dashboard_page(profile, corrections, message))
            return

        if path == "/corrections":
            message = query.get("message", [""])[0]
            self.send_html(home_page(profile, corrections, message))
            return

        if path == "/merge-activities":
            message = query.get("message", [""])[0]
            self.send_html(activity_merge_page(profile, corrections, message))
            return

        if path == "/reports":
            message = query.get("message", [""])[0]
            self.send_html(reports_page(message))
            return

        if path == "/future":
            message = query.get("message", [""])[0]
            self.send_html(future_workouts_page(message))
            return

        if path.startswith("/reports/file/"):
            filename = urllib.parse.unquote(path[len("/reports/file/"):])
            candidate = (REPORT_DIR / filename).resolve()
            allowed = (
                Path(filename).name == filename
                and filename.startswith("swim-report-")
                and candidate.parent == REPORT_DIR.resolve()
                and candidate.suffix in (".txt", ".html")
                and candidate.is_file()
            )
            if not allowed:
                self.send_html(render_page("Errore", "<div class='card'>Report non trovato.</div>"), HTTPStatus.NOT_FOUND)
                return
            data = candidate.read_bytes()
            content_type = "text/html; charset=utf-8" if candidate.suffix == ".html" else "text/plain; charset=utf-8"
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(data)
            return

        if path.startswith("/activity/"):

            rest = path[len("/activity/"):]

            if "/manual-delete/" in rest:
                aid_enc, manual_id_enc = rest.split(
                    "/manual-delete/",
                    1,
                )
                aid = urllib.parse.unquote(aid_enc)
                manual_id = urllib.parse.unquote(
                    manual_id_enc
                )

                key = correction_key(
                    aid,
                    f"manual:{manual_id}",
                )

                with CORRECTIONS_LOCK:
                    corrections = load_corrections()
                    corrections.pop(
                        key,
                        None,
                    )
                    atomic_write_json(
                        CORRECTIONS_FILE,
                        corrections,
                    )

                message = (
                    "Vasca manuale rimossa."
                )

                self.redirect(
                    f"/activity/{urllib.parse.quote(aid, safe='')}?message="
                    f"{urllib.parse.quote(message)}"
                )
                return

            aid = urllib.parse.unquote(
                rest
            )

            activities = group_activities(
                profile,
                corrections,
            )

            activity = next(
                (
                    a
                    for a in activities
                    if a["activity_id"] == aid
                ),
                None,
            )

            if activity is None:
                self.send_html(
                    render_page(
                        "Errore",
                        "<div class='card'><h2>Attività non trovata</h2>"
                        "<a class='button' href='/'>Torna alle attività</a></div>",
                    ),
                    HTTPStatus.NOT_FOUND,
                )
                return

            message = query.get(
                "message",
                [""],
            )[0]

            self.send_html(
                activity_page(
                    activity,
                    corrections,
                    message,
                )
            )
            return

        if path == "/api/corrections":
            self.send_json(corrections)
            return

        if path == "/api/profile":
            self.send_json(profile)
            return

        if path == "/api/corrections/download":
            aid = query.get(
                "activity_id",
                [""],
            )[0]

            if aid:
                filtered = {
                    k: v
                    for k, v in corrections.items()
                    if k.startswith(
                        f"{aid}:"
                    )
                }
            else:
                filtered = corrections

            data = json.dumps(
                filtered,
                ensure_ascii=False,
                indent=2,
            ).encode("utf-8")

            self.send_response(
                HTTPStatus.OK
            )
            self.send_header(
                "Content-Type",
                "application/json; charset=utf-8",
            )
            self.send_header(
                "Content-Disposition",
                f'attachment; filename="corrections_{aid or "all"}.json"',
            )
            self.send_header(
                "Content-Length",
                str(len(data)),
            )
            self.end_headers()
            self.wfile.write(data)
            return

        self.send_html(
            render_page(
                "404",
                "<div class='card'><h2>Pagina non trovata</h2>"
                "<a class='button' href='/'>Home</a></div>",
            ),
            HTTPStatus.NOT_FOUND,
        )

    def do_POST(self):
        parsed = urllib.parse.urlparse(
            self.path
        )

        path = parsed.path

        if path == "/import-activities":
            command = [sys.executable, str(BASE_DIR / "import_new_activities.py")]
            try:
                result = subprocess.run(
                    command,
                    cwd=str(BASE_DIR),
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    timeout=900,
                    check=False,
                )
                output = result.stdout or "(Nessun output prodotto.)"
                if result.returncode == 0:
                    headline = "Importazione completata con successo."
                else:
                    headline = f"Importazione terminata con codice {result.returncode}."
            except subprocess.TimeoutExpired as exc:
                output = exc.stdout or ""
                if isinstance(output, bytes):
                    output = output.decode("utf-8", errors="replace")
                headline = "Tempo massimo superato: controlla i log e lo stato dell’importazione."
            except OSError as exc:
                output = str(exc)
                headline = "Impossibile avviare l’importazione."

            body = f"""
<div class='card'>
<h2>Importazione attività Garmin</h2>
<p class='notice'>{html.escape(headline)}</p>
<p class='small'>Sono mostrati al massimo gli ultimi 24.000 caratteri del log.</p>
<pre style='white-space:pre-wrap;overflow-wrap:anywhere;max-height:70vh;overflow:auto'>{html.escape(output[-24000:])}</pre>
<div class='toolbar'>
<a class='button' href='/'>Torna alla dashboard</a>
<a class='button secondary' href='/reports'>Apri i report</a>
</div>
</div>
"""
            self.send_html(render_page("Importazione attività", body))
            return



        # SWIM_COACH_FUTURE_EDITOR_V1: gestione del calendario degli allenamenti futuri.
        if path == "/future/save":
            def future_redirect(text: str) -> None:
                self.redirect("/future?message=" + urllib.parse.quote(text))

            try:
                content_length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                content_length = 0
            if content_length < 0 or content_length > 2_000_000:
                future_redirect("Richiesta troppo grande o non valida.")
                return
            raw = self.rfile.read(content_length).decode("utf-8", errors="replace")
            form = urllib.parse.parse_qs(raw, keep_blank_values=True)
            action = str(form.get("action", [""])[0]).strip()
            workout_id = str(form.get("workout_id", [""])[0]).strip()
            if action not in ("add", "save", "delete"):
                future_redirect("Operazione non riconosciuta.")
                return

            values = None
            if action != "delete":
                date_value = str(form.get("date", [""])[0]).strip()
                title_value = str(form.get("title", [""])[0]).strip()
                focus_value = str(form.get("focus", [""])[0]).strip()
                notes_value = str(form.get("notes", [""])[0]).strip()
                sets_text = str(form.get("sets", [""])[0])
                try:
                    distance_value = int(str(form.get("distance_m", [""])[0]).strip())
                except ValueError:
                    distance_value = 0
                try:
                    parsed_date = datetime.strptime(date_value, "%Y-%m-%d")
                    date_is_valid = parsed_date.strftime("%Y-%m-%d") == date_value
                except ValueError:
                    date_is_valid = False
                set_values = [line.strip() for line in sets_text.splitlines() if line.strip()]
                if not date_is_valid:
                    future_redirect("Inserisci una data valida nel formato richiesto.")
                    return
                if not title_value or len(title_value) > 160:
                    future_redirect("Il titolo è obbligatorio e non può superare 160 caratteri.")
                    return
                if distance_value < 25 or distance_value > 10000 or distance_value % 25 != 0:
                    future_redirect("La distanza deve essere tra 25 e 10000 m, a multipli di 25 m.")
                    return
                if len(focus_value) > 300 or len(notes_value) > 3000:
                    future_redirect("Obiettivo o note troppo lunghi.")
                    return
                if not set_values or len(set_values) > 80 or any(len(line) > 500 for line in set_values):
                    future_redirect("Inserisci da 1 a 80 serie, ciascuna lunga al massimo 500 caratteri.")
                    return
                values = {
                    "date": date_value,
                    "title": title_value,
                    "distance_m": distance_value,
                    "focus": focus_value,
                    "notes": notes_value,
                    "sets": set_values,
                }

            try:
                with FUTURE_WORKOUTS_LOCK:
                    if FUTURE_WORKOUTS_FILE.exists():
                        with FUTURE_WORKOUTS_FILE.open("r", encoding="utf-8") as stream:
                            stored = json.load(stream)
                    else:
                        stored = {"version": 1, "workouts": []}

                    if isinstance(stored, list):
                        data = {"version": 1, "workouts": stored}
                    elif isinstance(stored, dict):
                        data = dict(stored)
                        existing = data.get("workouts", data.get("sessions", []))
                        data["workouts"] = existing
                    else:
                        raise ValueError("Il file del programma non ha una struttura riconosciuta.")

                    workouts = data.get("workouts")
                    if not isinstance(workouts, list) or any(not isinstance(item, dict) for item in workouts):
                        raise ValueError("L'elenco delle sedute nel file non è valido; nessun dato è stato modificato.")

                    if action == "delete":
                        if not workout_id:
                            raise ValueError("ID della seduta mancante.")
                        remaining = [item for item in workouts if str(item.get("id", "")) != workout_id]
                        if len(remaining) == len(workouts):
                            raise ValueError("La seduta da eliminare non è stata trovata.")
                        workouts = remaining
                        success_message = "Seduta eliminata dal calendario."
                    elif action == "save":
                        if not workout_id:
                            raise ValueError("ID della seduta mancante.")
                        match_index = next((i for i, item in enumerate(workouts) if str(item.get("id", "")) == workout_id), None)
                        if match_index is None:
                            raise ValueError("La seduta da modificare non è stata trovata.")
                        workouts[match_index] = {**workouts[match_index], **values, "id": workout_id}
                        success_message = "Seduta aggiornata."
                    else:
                        new_id = "SC-" + datetime.now().astimezone().strftime("%Y%m%d-%H%M%S-%f")
                        while any(str(item.get("id", "")) == new_id for item in workouts):
                            new_id += "-1"
                        workouts.append({"id": new_id, **values})
                        success_message = "Nuova seduta aggiunta."

                    data["version"] = data.get("version", 1)
                    data["workouts"] = sorted(
                        workouts,
                        key=lambda item: (str(item.get("date") or item.get("scheduled_date") or "9999-12-31"), str(item.get("title") or item.get("name") or "")),
                    )
                    data.pop("sessions", None)

                    if FUTURE_WORKOUTS_FILE.exists():
                        stamp = datetime.now().astimezone().strftime("%Y%m%d-%H%M%S-%f")
                        backup_path = FUTURE_WORKOUTS_FILE.with_name(FUTURE_WORKOUTS_FILE.name + ".bak-" + stamp)
                        backup_path.write_bytes(FUTURE_WORKOUTS_FILE.read_bytes())
                    atomic_write_json(FUTURE_WORKOUTS_FILE, data)
            except (OSError, ValueError, json.JSONDecodeError) as exc:
                future_redirect("Salvataggio non riuscito: " + str(exc))
                return

            future_redirect(success_message + " Copia di sicurezza creata prima del salvataggio, se il file esisteva già.")
            return

        if path in ("/merge-activities/create", "/merge-activities/unmerge"):
            try:
                content_length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                content_length = 0
            raw = self.rfile.read(content_length).decode("utf-8", errors="replace")
            form = urllib.parse.parse_qs(raw, keep_blank_values=True)
            merge_data = load_activity_merges()
            current_corrections = load_corrections()
            profile = load_profile()
            activity_list = group_activities(profile, current_corrections)
            activity_by_id = {str(a["activity_id"]): a for a in activity_list}

            if path == "/merge-activities/create":
                aid_a = str(form.get("activity_a", [""])[0]).strip()
                aid_b = str(form.get("activity_b", [""])[0]).strip()
                submitted_date = str(form.get("date", [""])[0]).strip()
                a = activity_by_id.get(aid_a)
                b = activity_by_id.get(aid_b)
                error = ""
                if not a or not b:
                    error = "Seleziona due attività esistenti."
                elif aid_a == aid_b:
                    error = "Seleziona due registrazioni diverse."
                elif not a.get("date") or a.get("date") != b.get("date") or (submitted_date and a.get("date") != submitted_date):
                    error = "Puoi unire soltanto registrazioni della stessa data."
                else:
                    used = {str(x) for entry in merge_data.get("merges", []) for x in entry.get("activity_ids", [])}
                    if aid_a in used or aid_b in used:
                        error = "Una delle registrazioni fa già parte di un'unione. Annulla prima l'unione esistente."
                if error:
                    self.redirect("/merge-activities?message=" + urllib.parse.quote(error))
                    return

                merge_id = f"{aid_a}--{aid_b}"
                entry = {
                    "merge_id": merge_id,
                    "activity_ids": [aid_a, aid_b],
                    "primary_activity_id": aid_a,
                    "date": str(a.get("date")),
                    "created_at": now_iso(),
                    "source": "manual_web",
                    "note": "Registrazioni Garmin della stessa seduta unite manualmente.",
                }
                merge_data.setdefault("merges", []).append(entry)
                try:
                    save_activity_merges(merge_data)
                except OSError as exc:
                    self.redirect("/merge-activities?message=" + urllib.parse.quote(f"Impossibile salvare l'unione: {exc}"))
                    return
                success, update_message = rebuild_after_activity_merge(aid_a)
                message = f"Registrazioni {aid_a} + {aid_b} unite. {update_message}"
                self.redirect("/merge-activities?message=" + urllib.parse.quote(message))
                return

            # Annullamento unione registrazioni.
            merge_id = str(form.get("merge_id", [""])[0]).strip()
            entry = next((x for x in merge_data.get("merges", []) if str(x.get("merge_id")) == merge_id), None)
            if entry is None:
                self.redirect("/merge-activities?message=" + urllib.parse.quote("Unione non trovata."))
                return
            primary_id = str(entry.get("primary_activity_id") or (entry.get("activity_ids") or [""])[0])
            merge_data["merges"] = [x for x in merge_data.get("merges", []) if str(x.get("merge_id")) != merge_id]
            try:
                save_activity_merges(merge_data)
            except OSError as exc:
                self.redirect("/merge-activities?message=" + urllib.parse.quote(f"Impossibile salvare l'annullamento: {exc}"))
                return
            success, update_message = rebuild_after_activity_merge(primary_id)
            message = f"Unione annullata. {update_message}"
            self.redirect("/merge-activities?message=" + urllib.parse.quote(message))
            return

        # ----------------------------------------------------
        # Unione di lap consecutivi
        # ----------------------------------------------------

        if path.startswith("/activity/") and path.endswith("/merge"):
            aid = urllib.parse.unquote(path[len("/activity/"):-len("/merge")])
            try:
                content_length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                content_length = 0
            raw = self.rfile.read(content_length).decode("utf-8", errors="replace")
            form = urllib.parse.parse_qs(raw, keep_blank_values=True)
            lap_a = lap_b = 0
            merge_pair = form.get("merge_pair", [""])[0]
            if merge_pair:
                try:
                    raw_a, raw_b = merge_pair.split(",", 1)
                    lap_a = int(raw_a)
                    lap_b = int(raw_b)
                except (TypeError, ValueError):
                    lap_a = lap_b = 0
            else:
                # Compatibilità con eventuali vecchi pulsanti/form V1.3.
                try:
                    lap_a = int(form.get("lap_a", ["0"])[0])
                    lap_b = int(form.get("lap_b", ["0"])[0])
                except (TypeError, ValueError):
                    lap_a = lap_b = 0

            profile = load_profile()
            corrections = load_corrections()
            activity = next((a for a in group_activities(profile, corrections) if a["activity_id"] == aid), None)
            if activity is None:
                self.send_html(render_page("Errore", "<div class='card'>Attività non trovata.</div>"), HTTPStatus.NOT_FOUND)
                return

            rows_by_lap = {
                int(r.get("lap", 0) or 0): r
                for r in activity["rows"]
            }
            if lap_a not in rows_by_lap or lap_b not in rows_by_lap:
                self.redirect(
                    f"/activity/{urllib.parse.quote(aid, safe='')}?message="
                    + urllib.parse.quote("Uno dei lap indicati non esiste.")
                )
                return

            lap_numbers = [
                int(r.get("lap", 0) or 0)
                for r in activity["rows"]
            ]
            try:
                lap_a_index = lap_numbers.index(lap_a)
            except ValueError:
                lap_a_index = -1

            are_adjacent = (
                lap_a_index >= 0
                and lap_a_index + 1 < len(lap_numbers)
                and lap_numbers[lap_a_index + 1] == lap_b
            )

            if not are_adjacent:
                self.redirect(
                    f"/activity/{urllib.parse.quote(aid, safe='')}?message="
                    + urllib.parse.quote(
                        "Sono consentiti solo lap adiacenti nell'elenco Garmin."
                    )
                )
                return

            existing_map = merged_lap_map(corrections, aid)
            if lap_a in existing_map or lap_b in existing_map:
                self.redirect(f"/activity/{urllib.parse.quote(aid, safe='')}?message=" + urllib.parse.quote("Uno dei lap fa già parte di un'unione."))
                return

            corr_a = get_correction(corrections, aid, lap_a)
            corr_b = get_correction(corrections, aid, lap_b)
            distance_a = effective_distance(rows_by_lap[lap_a], corr_a)
            distance_b = effective_distance(rows_by_lap[lap_b], corr_b)
            elapsed_a = float(rows_by_lap[lap_a].get("elapsed_s") or 0)
            elapsed_b = float(rows_by_lap[lap_b].get("elapsed_s") or 0)

            source_laps = [lap_a, lap_b]
            key = merge_correction_key(aid, source_laps)
            entry = {
                "activity_id": aid,
                "updated_at": now_iso(),
                "source": "manual_web",
                "operation": "merge_laps",
                "source_laps": source_laps,
                "target_lap": lap_a,
                "distance_original_m": float(rows_by_lap[lap_a].get("distance_m") or 0) + float(rows_by_lap[lap_b].get("distance_m") or 0),
                "distance_corrected_m": distance_a + distance_b,
                "elapsed_original_s": elapsed_a + elapsed_b,
                "note": f"Unione manuale lap {lap_a}+{lap_b}: una sola ripetuta."
            }
            with CORRECTIONS_LOCK:
                corrections = load_corrections()
                corrections[key] = entry
                atomic_write_json(CORRECTIONS_FILE, corrections)

            message = f"Uniti i lap {lap_a} + {lap_b} in una sola ripetuta da {int(distance_a + distance_b)} m."
            self.redirect(f"/activity/{urllib.parse.quote(aid, safe='')}?message=" + urllib.parse.quote(message))
            return

        # ----------------------------------------------------
        # Annullamento di un'unione
        # ----------------------------------------------------

        if path.startswith("/activity/") and path.endswith("/unmerge"):
            aid = urllib.parse.unquote(path[len("/activity/"):-len("/unmerge")])
            try:
                content_length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                content_length = 0
            raw = self.rfile.read(content_length).decode("utf-8", errors="replace")
            form = urllib.parse.parse_qs(raw, keep_blank_values=True)
            key = form.get("key", [""])[0]
            with CORRECTIONS_LOCK:
                corrections = load_corrections()
                if key.startswith(f"{aid}:merge:"):
                    corrections.pop(key, None)
                    atomic_write_json(CORRECTIONS_FILE, corrections)
            self.redirect(f"/activity/{urllib.parse.quote(aid, safe='')}?message=" + urllib.parse.quote("Unione annullata."))
            return

        # ----------------------------------------------------
        # Salvataggio modifiche dei lap esistenti
        # ----------------------------------------------------

        if path.startswith("/activity/") and path.endswith("/save"):

            aid = urllib.parse.unquote(
                path[len("/activity/"):-len("/save")]
            )

            try:
                content_length = int(
                    self.headers.get(
                        "Content-Length",
                        "0",
                    )
                )
            except ValueError:
                content_length = 0

            raw = self.rfile.read(
                content_length
            ).decode(
                "utf-8",
                errors="replace",
            )

            form = urllib.parse.parse_qs(
                raw,
                keep_blank_values=True,
            )

            profile = load_profile()
            current_corrections = load_corrections()

            activities = group_activities(
                profile,
                current_corrections,
            )

            activity = next(
                (
                    a
                    for a in activities
                    if a["activity_id"] == aid
                ),
                None,
            )

            if activity is None:
                self.send_html(
                    render_page(
                        "Errore",
                        "<div class='card'>Attività non trovata.</div>",
                    ),
                    HTTPStatus.NOT_FOUND,
                )
                return

            with CORRECTIONS_LOCK:

                corrections = load_corrections()

                for row in activity["rows"]:

                    lap = int(
                        row.get(
                            "lap",
                            0,
                        )
                        or 0
                    )

                    style = form.get(
                        f"style_{lap}",
                        ["auto"],
                    )[0]

                    equipment = form.get(
                        f"equipment_{lap}",
                        ["auto"],
                    )[0]

                    classification = form.get(
                        f"classification_{lap}",
                        ["auto"],
                    )[0]

                    note = form.get(
                        f"note_{lap}",
                        [""],
                    )[0].strip()

                    original_distance = int(
                        round(
                            float(
                                row.get(
                                    "distance_m",
                                    0,
                                )
                                or 0
                            )
                        )
                    )

                    distance_raw = form.get(
                        f"distance_{lap}",
                        [str(original_distance)],
                    )[0]

                    corrected_distance = parse_distance(
                        distance_raw
                    )

                    if corrected_distance is None:
                        corrected_distance = original_distance

                    has_distance_correction = (
                        corrected_distance
                        != original_distance
                    )

                    has_manual = (
                        style != "auto"
                        or equipment != "auto"
                        or classification != "auto"
                        or bool(note)
                        or has_distance_correction
                    )

                    key = correction_key(
                        aid,
                        lap,
                    )

                    if not has_manual:
                        corrections.pop(
                            key,
                            None,
                        )
                        continue

                    existing = corrections.get(
                        key,
                        {},
                    )

                    if not isinstance(
                        existing,
                        dict,
                    ):
                        existing = {}

                    existing.update(
                        {
                            "activity_id": aid,
                            "lap": lap,
                            "updated_at": now_iso(),
                            "source": "manual_web",
                            "style": style,
                            "equipment": equipment,
                            "classification": classification,
                            "note": note,
                            "distance_original_m": original_distance,
                            "distance_corrected_m": corrected_distance,
                        }
                    )

                    corrections[key] = existing

                atomic_write_json(
                    CORRECTIONS_FILE,
                    corrections,
                )

            message = (
                "Correzioni salvate. Dati Garmin originali invariati."
            )

            self.redirect(
                f"/activity/{urllib.parse.quote(aid, safe='')}?message="
                f"{urllib.parse.quote(message)}"
            )
            return

        # ----------------------------------------------------
        # Aggiunta vasca completamente mancante
        # ----------------------------------------------------

        if path.startswith("/activity/") and path.endswith("/manual-add"):

            aid = urllib.parse.unquote(
                path[len("/activity/"):-len("/manual-add")]
            )

            try:
                content_length = int(
                    self.headers.get(
                        "Content-Length",
                        "0",
                    )
                )
            except ValueError:
                content_length = 0

            raw = self.rfile.read(
                content_length
            ).decode(
                "utf-8",
                errors="replace",
            )

            form = urllib.parse.parse_qs(
                raw,
                keep_blank_values=True,
            )

            distance = parse_distance(
                form.get(
                    "distance",
                    ["25"],
                )[0]
            )

            if not distance:
                distance = 25

            style = form.get(
                "style",
                ["auto"],
            )[0]

            equipment = form.get(
                "equipment",
                ["auto"],
            )[0]

            note = form.get(
                "note",
                ["Vasca mancante Garmin"],
            )[0].strip()

            manual_id = (
                datetime.now()
                .strftime(
                    "%Y%m%d%H%M%S%f"
                )
            )

            key = correction_key(
                aid,
                f"manual:{manual_id}",
            )

            entry = {
                "activity_id": aid,
                "manual_id": manual_id,
                "created_at": now_iso(),
                "updated_at": now_iso(),
                "source": "manual_web",
                "manual": True,
                "style": style,
                "equipment": equipment,
                "classification": "normal_swim",
                "distance_original_m": 0,
                "distance_corrected_m": distance,
                "elapsed_s": None,
                "note": note,
            }

            with CORRECTIONS_LOCK:
                corrections = load_corrections()
                corrections[key] = entry
                atomic_write_json(
                    CORRECTIONS_FILE,
                    corrections,
                )

            message = (
                f"Aggiunta manualmente una vasca da {distance} m. "
                "Non sono stati inventati dati tecnici."
            )

            self.redirect(
                f"/activity/{urllib.parse.quote(aid, safe='')}?message="
                f"{urllib.parse.quote(message)}"
            )
            return

        self.send_html(
            render_page(
                "Errore",
                "<div class='card'>POST non supportata.</div>",
            ),
            HTTPStatus.NOT_FOUND,
        )


def main():
    parser = argparse.ArgumentParser(
        description="Web UI locale per correzioni Swim Coach"
    )

    parser.add_argument(
        "--host",
        default=DEFAULT_HOST,
    )

    parser.add_argument(
        "--port",
        type=int,
        default=DEFAULT_PORT,
    )

    args = parser.parse_args()

    DATA_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    if not PROFILE_FILE.exists():
        print(
            f"ATTENZIONE: non esiste {PROFILE_FILE}"
        )
        print(
            "Genera prima il profilo con profile.py."
        )

    server = ThreadingHTTPServer(
        (
            args.host,
            args.port,
        ),
        Handler,
    )

    print("=" * 70)
    print("SWIM COACH WEB V1.4")
    print("=" * 70)
    print(f"Profilo:       {PROFILE_FILE}")
    print(f"Correzioni:    {CORRECTIONS_FILE}")
    print(f"Listen:        {args.host}:{args.port}")
    print(
        "Apri nel browser: http://IP_DEL_LXC:%d"
        % args.port
    )
    print(
        "Ctrl+C per terminare."
    )
    print()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nArresto.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
