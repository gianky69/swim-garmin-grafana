#!/usr/bin/env python3
"""Safely rebuild the Swim Coach profile and latest TXT/HTML report.

Default installation:
  /usr/bin/python3 /opt/swim-coach/update_swim_coach.py

The script backs up the current profile, corrections and activity-merges metadata,
runs profile.py, validates the generated JSON, builds the report in a staging
directory, archives an older report if the same activity report is being replaced,
and installs the new TXT/HTML pair. If a step fails, it restores the previous
profile and report. It never edits corrections.json or activity_merges.json.
"""
from __future__ import annotations

import argparse
import fcntl
import json
import os
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime
from pathlib import Path


def copy_if_file(src: Path, dst: Path) -> bool:
    if src.is_file():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        return True
    return False


def restore_file(backup: Path | None, target: Path, existed_before: bool) -> None:
    if existed_before and backup is not None and backup.is_file():
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(backup, target)
    elif not existed_before:
        target.unlink(missing_ok=True)


def run_command(command: list[str], cwd: Path, label: str) -> subprocess.CompletedProcess[str]:
    print(f"\n[{label}] {' '.join(command)}", flush=True)
    result = subprocess.run(
        command,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if result.stdout:
        print(result.stdout, end="" if result.stdout.endswith("\n") else "\n", flush=True)
    if result.returncode != 0:
        raise RuntimeError(f"{label} è terminato con codice {result.returncode}.")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Rigenera in sicurezza il profilo e il report Swim Coach."
    )
    parser.add_argument(
        "--base-dir",
        type=Path,
        default=Path("/opt/swim-coach"),
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--activity-id",
        default=None,
        help="Genera il report di una specifica attività; senza opzione usa la più recente.",
    )
    args = parser.parse_args()

    base = args.base_dir.resolve()
    data_dir = base / "data"
    report_dir = base / "reports"
    profile_script = base / "profile.py"
    report_script = base / "swim_report.py"
    profile_file = data_dir / "swim_profile.json"
    corrections_file = data_dir / "corrections.json"
    activity_merges_file = data_dir / "activity_merges.json"
    activity_merges_module = base / "activity_merges.py"
    lock_path = base / ".update_swim_coach.lock"

    missing = [str(p) for p in (profile_script, report_script, corrections_file, activity_merges_module) if not p.is_file()]
    if missing:
        print("ERRORE: file richiesti mancanti:\n  " + "\n  ".join(missing), file=sys.stderr)
        return 1

    try:
        with corrections_file.open("r", encoding="utf-8") as fh:
            corrections_data = json.load(fh)
        if not isinstance(corrections_data, dict):
            raise ValueError("corrections.json deve contenere un oggetto JSON.")
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"ERRORE: corrections.json non leggibile o non valido: {exc}", file=sys.stderr)
        return 1

    data_dir.mkdir(parents=True, exist_ok=True)
    report_dir.mkdir(parents=True, exist_ok=True)

    # Prevent two manual/timer runs from racing over the same JSON/report files.
    lock_handle = lock_path.open("a", encoding="utf-8")
    try:
        try:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("AGGIORNAMENTO NON AVVIATO: un'altra esecuzione è già in corso.", file=sys.stderr)
            return 2

        stamp = datetime.now().astimezone().strftime("%Y%m%d-%H%M%S-%f")
        backup_dir = base / "backups" / f"update-{stamp}"
        backup_dir.mkdir(parents=True, exist_ok=False)
        profile_backup = backup_dir / "swim_profile.json.before.json"
        corrections_backup = backup_dir / "corrections.json.before.json"
        activity_merges_backup = backup_dir / "activity_merges.json.before.json"
        profile_existed = copy_if_file(profile_file, profile_backup)
        copy_if_file(corrections_file, corrections_backup)
        copy_if_file(activity_merges_file, activity_merges_backup)

        stage_dir = Path(tempfile.mkdtemp(prefix=f".staging-{stamp}-", dir=report_dir))
        archived_files: dict[Path, Path] = {}
        installed_files: list[Path] = []
        archive_dir: Path | None = None
        succeeded = False

        try:
            print("=" * 66)
            print("SWIM COACH — AGGIORNAMENTO COMPLETO")
            print(f"Backup: {backup_dir}")
            print("corrections.json: verificato; il file non verrà modificato.")
            print("=" * 66)

            run_command([sys.executable, str(profile_script)], base, "1/2 Profilo")

            try:
                with profile_file.open("r", encoding="utf-8") as fh:
                    profile_data = json.load(fh)
            except (OSError, json.JSONDecodeError) as exc:
                raise RuntimeError(f"swim_profile.json generato non valido: {exc}") from exc

            ui_records = profile_data.get("all_observations")
            coaching_records = profile_data.get("coaching_observations")
            if not isinstance(ui_records, list) or not isinstance(coaching_records, list):
                raise RuntimeError(
                    "Il profilo non contiene le liste all_observations e coaching_observations attese. "
                    "Non avvio il report con uno schema inatteso."
                )
            if not coaching_records:
                raise RuntimeError("Il profilo non contiene osservazioni per il coaching.")

            version = profile_data.get("version", "—")
            merge_count = profile_data.get(
                "merged_repetitions_count",
                sum(1 for item in coaching_records if isinstance(item, dict) and item.get("merged")),
            )
            session_merge_count = profile_data.get("merged_sessions_count", 0)
            print(
                f"Profilo verificato: versione {version}; "
                f"osservazioni UI {len(ui_records)}; "
                f"osservazioni coaching {len(coaching_records)}; "
                f"unioni lap {merge_count}; registrazioni unite {session_merge_count}.",
                flush=True,
            )

            command = [
                sys.executable,
                str(report_script),
                "--output-dir",
                str(stage_dir),
            ]
            if args.activity_id:
                command.extend(["--activity-id", args.activity_id])

            report_result = run_command(command, base, "2/2 Report")
            txt_candidates = sorted(stage_dir.glob("swim-report-*.txt"))
            html_candidates = sorted(stage_dir.glob("swim-report-*.html"))
            if len(txt_candidates) != 1 or len(html_candidates) != 1:
                raise RuntimeError(
                    "Il generatore non ha prodotto esattamente un report TXT e uno HTML "
                    f"(TXT={len(txt_candidates)}, HTML={len(html_candidates)})."
                )

            staged_txt = txt_candidates[0]
            staged_html = html_candidates[0]
            if staged_txt.stem != staged_html.stem:
                raise RuntimeError("I nomi del report TXT e HTML non corrispondono.")
            if staged_txt.stat().st_size == 0 or staged_html.stat().st_size == 0:
                raise RuntimeError("Il report TXT o HTML è vuoto.")

            targets = [report_dir / staged_txt.name, report_dir / staged_html.name]
            existing_targets = [path for path in targets if path.exists()]
            if existing_targets:
                archive_dir = report_dir / "archive" / stamp
                archive_dir.mkdir(parents=True, exist_ok=False)
                for old in existing_targets:
                    archived = archive_dir / old.name
                    shutil.copy2(old, archived)
                    archived_files[old] = archived

            # Install the completed pair only after both staged files validate.
            for staged, target in zip((staged_txt, staged_html), targets):
                os.replace(staged, target)
                installed_files.append(target)

            if any(not p.is_file() or p.stat().st_size == 0 for p in targets):
                raise RuntimeError("Verifica finale fallita: report mancante o vuoto.")

            succeeded = True
            print("\n" + "=" * 66)
            print("AGGIORNAMENTO COMPLETATO")
            print(f"Profilo: {profile_file}")
            print(f"Report TXT: {targets[0]}")
            print(f"Report HTML: {targets[1]}")
            if archive_dir:
                print(f"Versioni precedenti del report archiviate in: {archive_dir}")
            print(f"Backup profilo/correzioni/unioni registrazioni: {backup_dir}")
            print("Nessuna e-mail inviata; il report resta locale.")
            print("=" * 66)
            return 0

        except Exception as exc:
            print(f"\nERRORE: aggiornamento interrotto: {exc}", file=sys.stderr)
            # Put back the last good profile.
            try:
                restore_file(profile_backup if profile_backup.exists() else None, profile_file, profile_existed)
                print("Profilo precedente ripristinato (se esisteva).", file=sys.stderr)
            except Exception as rollback_exc:
                print(f"ATTENZIONE: ripristino profilo non riuscito: {rollback_exc}", file=sys.stderr)

            # If target report replacement began, restore the last good report pair.
            for target in installed_files:
                try:
                    target.unlink(missing_ok=True)
                except OSError:
                    pass
            for target, archived in archived_files.items():
                try:
                    if archived.is_file():
                        shutil.copy2(archived, target)
                except OSError as rollback_exc:
                    print(f"ATTENZIONE: ripristino {target.name} non riuscito: {rollback_exc}", file=sys.stderr)

            print(f"Backup per diagnosi: {backup_dir}", file=sys.stderr)
            return 1

        finally:
            shutil.rmtree(stage_dir, ignore_errors=True)

    finally:
        try:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)
        finally:
            lock_handle.close()


if __name__ == "__main__":
    raise SystemExit(main())
