#!/usr/bin/env python3
"""
profile.py V1.6
----------------
Profilo storico del nuotatore con applicazione delle correzioni manuali
e delle unioni salvate dalla Web UI Swim Coach.

Fonte dati:
  /opt/swim-coach/data/*_analysis.json
  /opt/swim-coach/data/history_swim.json
  /opt/swim-coach/data/corrections.json

Priorita' delle informazioni:
  correzione manuale > dato Garmin/analisi automatica

Supporta:
  - stile libero
  - dorso
  - rana
  - delfino (supportato tecnicamente, ma non promosso nel coaching)
  - misto
  - equipment: none / fins / pull_buoy / paddles / kickboard / other
  - classificazione: normal / possible_special / artifact
  - distanza corretta
  - vasche manualmente aggiunte
  - unione di lap adiacenti nell’elenco Garmin, anche con numerazione discontinua
  - trend per seduta

Importante:
  - i dati Garmin originali non vengono modificati
  - le correzioni sono applicate solo in questo profilo
  - le pinne non vengono piu' interpretate automaticamente come errore
  - un lap con equipment=fins entra nel profilo PINNE e non nel profilo standard
"""

from __future__ import annotations

import copy
import json
import math
import statistics
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from activity_merges import apply_activity_merges, load_activity_merges

BASE_DIR = Path("/opt/swim-coach")
DATA_DIR = BASE_DIR / "data"
HISTORY_FILE = DATA_DIR / "history_swim.json"
CORRECTIONS_FILE = DATA_DIR / "corrections.json"
OUTPUT_FILE = DATA_DIR / "swim_profile.json"

VERSION = "1.6"

PROFILE_DISTANCES = [25, 50, 75, 100, 150, 200, 300, 400]

STYLE_LABELS = {
    "freestyle": "FREESTYLE",
    "backstroke": "BACKSTROKE",
    "breaststroke": "BREASTSTROKE",
    "butterfly": "BUTTERFLY",
    "mixed": "MIXED",
    "unknown": "UNKNOWN",
}

EQUIPMENT_LABELS = {
    "none": "SENZA ATTREZZATURA",
    "fins": "PINNE",
    "pull_buoy": "PULL BUOY",
    "paddles": "PALETTE",
    "kickboard": "TAVOLETTA",
    "other": "ALTRA ATTREZZATURA",
}

SUPPORTED_STYLES = (
    "freestyle",
    "backstroke",
    "breaststroke",
    "butterfly",
    "mixed",
    "unknown",
)

SUPPORTED_EQUIPMENT = (
    "none",
    "fins",
    "pull_buoy",
    "paddles",
    "kickboard",
    "other",
)


# ============================================================
# GENERIC UTILITIES
# ============================================================

def safe_float(value: Any) -> Optional[float]:
    if value is None or value == "":
        return None
    try:
        x = float(value)
        if math.isfinite(x):
            return x
    except (TypeError, ValueError):
        pass
    return None


def safe_int(value: Any) -> Optional[int]:
    if value is None or value == "":
        return None
    try:
        return int(round(float(value)))
    except (TypeError, ValueError):
        return None


def normalize_key(value: Any) -> str:
    return "".join(ch.lower() for ch in str(value) if ch.isalnum())


def first_value(d: Dict[str, Any], keys: Iterable[str]) -> Any:
    for key in keys:
        if key in d and d[key] not in (None, ""):
            return d[key]
    return None


def deep_find_values(obj: Any, wanted_keys: Iterable[str]) -> List[Any]:
    wanted = {normalize_key(k) for k in wanted_keys}
    found: List[Any] = []

    def visit(value: Any) -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                if normalize_key(key) in wanted:
                    found.append(child)
                if isinstance(child, (dict, list)):
                    visit(child)
        elif isinstance(value, list):
            for child in value:
                if isinstance(child, (dict, list)):
                    visit(child)

    visit(obj)
    return found


def deep_first_value(obj: Any, wanted_keys: Iterable[str]) -> Any:
    for value in deep_find_values(obj, wanted_keys):
        if value not in (None, ""):
            return value
    return None


def load_json(path: Path, default: Any) -> Any:
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def parse_date(value: Any) -> Optional[str]:
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).date().isoformat()
    except ValueError:
        pass
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(s[:10], fmt).date().isoformat()
        except ValueError:
            pass
    return s[:10] if len(s) >= 10 else s


def parse_time_seconds(value: Any) -> Optional[float]:
    if value is None or value == "":
        return None
    if isinstance(value, (int, float)):
        x = safe_float(value)
        return x if x is not None and x > 0 else None
    s = str(value).strip()
    if not s:
        return None
    if ":" in s:
        parts = s.split(":")
        try:
            if len(parts) == 2:
                return int(parts[0]) * 60 + float(parts[1])
            if len(parts) == 3:
                return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
        except ValueError:
            return None
    return safe_float(s)


def fmt_time(seconds: Optional[float]) -> str:
    if seconds is None:
        return "-"
    total = int(round(seconds))
    return f"{total // 60}:{total % 60:02d}"


def fmt_pace(seconds: Optional[float]) -> str:
    return fmt_time(seconds)


def clean_values(values: Iterable[Any]) -> List[float]:
    result = []
    for value in values:
        x = safe_float(value)
        if x is not None:
            result.append(x)
    return result


def median(values: Iterable[Any]) -> Optional[float]:
    values = clean_values(values)
    return statistics.median(values) if values else None


def mean(values: Iterable[Any]) -> Optional[float]:
    values = clean_values(values)
    return statistics.mean(values) if values else None


def percentile(values: Iterable[Any], p: float) -> Optional[float]:
    values = sorted(clean_values(values))
    if not values:
        return None
    if len(values) == 1:
        return values[0]
    pos = (len(values) - 1) * p
    lo = math.floor(pos)
    hi = math.ceil(pos)
    if lo == hi:
        return values[lo]
    return values[lo] * (hi - pos) + values[hi] * (pos - lo)


# ============================================================
# STYLE / EQUIPMENT
# ============================================================

def canonical_style(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, list):
        styles = [s for s in (canonical_style(x) for x in value) if s]
        styles = list(dict.fromkeys(styles))
        if len(styles) == 1:
            return styles[0]
        if len(styles) > 1:
            return "mixed"
        return None
    if isinstance(value, dict):
        return style_from_object(value)
    s = str(value).strip().lower().replace("_", " ").replace("-", " ")
    s = " ".join(s.split())
    mapping = {
        "freestyle": "freestyle", "free": "freestyle", "crawl": "freestyle",
        "front crawl": "freestyle", "frontcrawl": "freestyle", "stile libero": "freestyle",
        "backstroke": "backstroke", "back": "backstroke", "dorso": "backstroke",
        "breaststroke": "breaststroke", "breast": "breaststroke", "rana": "breaststroke",
        "butterfly": "butterfly", "fly": "butterfly", "delfino": "butterfly",
        "mixed": "mixed", "medley": "mixed", "all": "mixed",
        "unknown": "unknown",
    }
    return mapping.get(s, mapping.get(s.replace(" ", "")))


def style_from_object(obj: Any) -> str:
    values = deep_find_values(
        obj,
        ["style", "Style", "Swim_Stroke", "swim_stroke", "swimStroke",
         "stroke_type", "strokeType", "stroke", "Stroke"],
    )
    styles = []
    for value in values:
        style = canonical_style(value) if not isinstance(value, dict) else None
        if style:
            styles.append(style)
    styles = list(dict.fromkeys(styles))
    if len(styles) == 1:
        return styles[0]
    if len(styles) > 1:
        return "mixed"
    return "unknown"


def equipment_label(equipment: str) -> str:
    return EQUIPMENT_LABELS.get(equipment, equipment.upper())


def style_label(style: str) -> str:
    return STYLE_LABELS.get(style, style.upper())


# ============================================================
# HISTORY / CORRECTIONS
# ============================================================

def load_history() -> Dict[str, Dict[str, Any]]:
    raw = load_json(HISTORY_FILE, {})
    if isinstance(raw, list):
        items = raw
    elif isinstance(raw, dict):
        items = []
        for key in ("activities", "swims", "history", "items"):
            if isinstance(raw.get(key), list):
                items = raw[key]
                break
        if not items:
            for key, value in raw.items():
                if isinstance(value, dict):
                    aid = first_value(value, ["ActivityID", "activity_id", "activityId", "Activity_ID", "id"])
                    if aid is not None:
                        item = dict(value)
                        item.setdefault("ActivityID", aid)
                        items.append(item)
                    elif str(key).isdigit():
                        item = dict(value)
                        item.setdefault("ActivityID", key)
                        items.append(item)
    else:
        items = []

    result = {}
    for item in items:
        if not isinstance(item, dict):
            continue
        aid = first_value(item, ["ActivityID", "activity_id", "activityId", "Activity_ID", "id"])
        if aid is None:
            continue
        aid = str(aid)
        result[aid] = {
            "activity_id": aid,
            "date": parse_date(first_value(item, ["date", "Date", "activityDate", "timestamp", "startTimeLocal", "start_time", "startTime"])),
            "name": str(first_value(item, ["name", "activityName", "ActivityName"]) or ""),
            "distance": safe_float(first_value(item, ["distance", "Distance"])),
            "duration": safe_float(first_value(item, ["duration", "elapsedDuration", "elapsed_duration", "duration_s", "elapsed_s"])),
            "avg_hr": safe_float(first_value(item, ["averageHR", "avgHR", "avg_hr", "average_hr"])),
            "max_hr": safe_float(first_value(item, ["maxHR", "max_hr"])),
            "training_load": safe_float(first_value(item, ["trainingLoad", "activityTrainingLoad", "activity_training_load", "load"])),
        }
    return result


def load_corrections() -> Dict[str, Dict[str, Any]]:
    raw = load_json(CORRECTIONS_FILE, {})
    if not isinstance(raw, dict):
        return {}
    return {str(k): v for k, v in raw.items() if isinstance(v, dict)}


def correction_for(corrections: Dict[str, Dict[str, Any]], aid: str, lap: Any) -> Dict[str, Any]:
    value = corrections.get(f"{aid}:{lap}", {})
    return value if isinstance(value, dict) else {}


def is_manual(value: Any) -> bool:
    return value not in (None, "", "auto")


# ============================================================
# ANALYSIS PARSING
# ============================================================

def extract_distance(obj: Dict[str, Any]) -> Optional[float]:
    value = first_value(obj, ["distance_m", "distance", "Distance", "Distance_M", "distanceM"])
    if value is None:
        value = deep_first_value(obj, ["distance_m", "distance", "Distance", "Distance_M", "distanceM"])
    x = safe_float(value)
    if x is None or x <= 0:
        return None
    return x * 1000.0 if x < 1 else x


def extract_elapsed(obj: Dict[str, Any], distance: Optional[float]) -> Optional[float]:
    value = first_value(obj, ["elapsed_s", "elapsed", "Elapsed", "Elapsed_Time", "elapsed_time", "elapsedTime", "elapsed_seconds", "elapsedSeconds", "duration", "Duration", "duration_s", "duration_seconds", "durationSeconds"])
    if value is None:
        value = deep_first_value(obj, ["elapsed_s", "elapsed", "Elapsed", "Elapsed_Time", "elapsed_time", "elapsedTime", "duration", "Duration", "duration_s", "duration_seconds", "durationSeconds"])
    result = parse_time_seconds(value)
    if result is not None and result > 0:
        return result
    pace = safe_float(first_value(obj, ["pace_sec100", "pace_s100", "pace_100"]))
    if pace is not None and distance:
        return pace * distance / 100.0
    return None


def extract_strokes(obj: Dict[str, Any]) -> Optional[float]:
    x = safe_float(first_value(obj, ["strokes", "Strokes", "stroke_count", "strokeCount"]))
    if x is not None:
        return x
    values = deep_find_values(obj, ["strokes", "Strokes", "stroke_count", "strokeCount"])
    nums = [safe_float(v) for v in values]
    nums = [x for x in nums if x is not None and x > 0]
    return sum(nums) if nums else None


def extract_strokes_per_25(obj: Dict[str, Any], distance: float, strokes: Optional[float]) -> Optional[float]:
    x = safe_float(first_value(obj, ["strokes_per_25", "strokesPer25", "avg_strokes_per_25", "Avg_Strokes_Per_25"]))
    if x is not None:
        return x
    if strokes is not None and distance > 0:
        return strokes * 25.0 / distance
    return None


def extract_cadence(obj: Dict[str, Any]) -> Optional[float]:
    x = safe_float(first_value(obj, ["cadence", "Cadence", "avg_cadence", "Avg_Cadence", "average_cadence", "stroke_rate", "strokeRate"]))
    if x is not None and x > 0:
        return x
    vals = [safe_float(v) for v in deep_find_values(obj, ["cadence", "Cadence", "avg_cadence", "Avg_Cadence", "average_cadence", "stroke_rate", "strokeRate"])]
    vals = [x for x in vals if x is not None and x > 0]
    return statistics.mean(vals) if vals else None


def extract_speed(obj: Dict[str, Any]) -> Optional[float]:
    x = safe_float(first_value(obj, ["speed_mps", "speed", "Speed", "avg_speed", "Avg_Speed", "average_speed", "AverageSpeed"]))
    if x is not None:
        return x
    vals = [safe_float(v) for v in deep_find_values(obj, ["speed_mps", "speed", "Speed", "avg_speed", "Avg_Speed", "average_speed"])]
    vals = [x for x in vals if x is not None and x > 0]
    return statistics.mean(vals) if vals else None


def extract_lap_index(obj: Dict[str, Any], fallback: int) -> int:
    x = safe_int(first_value(obj, ["lap", "Lap", "lap_index", "LapIndex", "index", "Index"]))
    return x if x is not None else fallback


def looks_like_lap(obj: Dict[str, Any]) -> bool:
    distance = extract_distance(obj)
    if distance is None:
        return False
    elapsed = extract_elapsed(obj, distance)
    return elapsed is not None and elapsed > 0


def find_laps(analysis: Any) -> List[Dict[str, Any]]:
    candidates: List[List[Dict[str, Any]]] = []
    preferred = {"laps", "swimlaps", "worklaps", "swim_laps", "work_laps", "segments", "intervals", "singlelaps", "workblocks"}

    def visit(obj: Any) -> None:
        if isinstance(obj, dict):
            for key, value in obj.items():
                nk = normalize_key(key)
                if nk in preferred and isinstance(value, list):
                    local = [x for x in value if isinstance(x, dict) and looks_like_lap(x)]
                    if local:
                        candidates.append(local)
                if isinstance(value, (dict, list)):
                    visit(value)
        elif isinstance(obj, list):
            for value in obj:
                if isinstance(value, (dict, list)):
                    visit(value)

    visit(analysis)
    if candidates:
        candidates.sort(key=len, reverse=True)
        return candidates[0]

    fallback: List[Dict[str, Any]] = []

    def fallback_visit(obj: Any) -> None:
        if isinstance(obj, dict):
            if looks_like_lap(obj):
                fallback.append(obj)
            for value in obj.values():
                if isinstance(value, (dict, list)):
                    fallback_visit(value)
        elif isinstance(obj, list):
            for value in obj:
                if isinstance(value, (dict, list)):
                    fallback_visit(value)

    fallback_visit(analysis)
    return fallback


def load_analysis_records(aid: str, analysis: Any, metadata: Dict[str, Any], source_file: str) -> List[Dict[str, Any]]:
    rows = []
    seen = set()

    for pos, lap in enumerate(find_laps(analysis), start=1):
        distance = extract_distance(lap)
        if distance is None:
            continue
        elapsed = extract_elapsed(lap, distance)
        if elapsed is None or elapsed <= 0:
            continue

        nominal = int(round(distance / 25.0) * 25)
        if nominal <= 0 or nominal > 400 or abs(distance - nominal) > 3:
            continue

        lap_index = extract_lap_index(lap, pos)
        key = (aid, lap_index)
        if key in seen:
            continue
        seen.add(key)

        pace = elapsed * 100.0 / distance
        derived_speed = distance / elapsed
        speed = extract_speed(lap)
        ratio = speed / derived_speed if speed is not None and derived_speed > 0 else None
        strokes = extract_strokes(lap)
        strokes25 = extract_strokes_per_25(lap, distance, strokes)
        cadence = extract_cadence(lap)

        rows.append({
            "activity_id": str(aid),
            "date": metadata.get("date"),
            "activity_name": metadata.get("name", ""),
            "source_file": source_file,
            "lap": lap_index,
            "distance_m": distance,
            "distance_nominal_m": nominal,
            "elapsed_s": elapsed,
            "pace_sec100": pace,
            "speed_mps": speed,
            "derived_speed_mps": derived_speed,
            "speed_ratio": ratio,
            "strokes": strokes,
            "strokes_per_25": strokes25,
            "cadence": cadence,
            "style": style_from_object(lap),
            "equipment": "none",
            "classification": "auto_normal",
            "classification_source": "automatic",
            "special_reason": None,
            "special_reasons": [],
            "correction_applied": False,
        })

    return rows


# ============================================================
# AUTOMATIC CLASSIFICATION
# ============================================================

def automatic_classification(records: List[Dict[str, Any]]) -> None:
    groups = defaultdict(list)
    for r in records:
        groups[(r["style"], r["distance_nominal_m"])].append(r)

    for group in groups.values():
        paces = [r["pace_sec100"] for r in group if r.get("pace_sec100") is not None]
        med = median(paces)
        for r in group:
            reasons = []
            distance = r["distance_nominal_m"]
            speed = r["derived_speed_mps"]
            garmin_speed = r.get("speed_mps")
            ratio = r.get("speed_ratio")

            if distance <= 100 and speed >= 1.75:
                reasons.append("very_high_derived_speed")

            if distance <= 100 and garmin_speed is not None and garmin_speed >= 1.85:
                reasons.append("very_high_garmin_speed")

            if ratio is not None and (ratio < 0.70 or ratio > 1.30):
                reasons.append("time_speed_inconsistency")

            if med is not None and len(paces) >= 4:
                if r["pace_sec100"] < med * 0.72 and (r.get("strokes") is None or r.get("cadence") is None):
                    reasons.append("extreme_pace_missing_technique")

            if distance <= 50 and speed >= 2.00 and (r.get("strokes") is None or r.get("cadence") is None):
                reasons.append("extreme_short_rep")

            if reasons:
                r["classification"] = "possible_special"
                r["classification_source"] = "automatic"
                r["special_reason"] = reasons[0]
                r["special_reasons"] = list(dict.fromkeys(reasons))
            else:
                r["classification"] = "normal_swim"
                r["classification_source"] = "automatic"


# ============================================================
# MANUAL CORRECTIONS
# ============================================================

def apply_corrections(records: List[Dict[str, Any]], corrections: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    result: List[Dict[str, Any]] = []
    records_by_key = {}

    for record in records:
        records_by_key[(record["activity_id"], int(record["lap"]))] = record

    for record in records:
        aid = record["activity_id"]
        lap = int(record["lap"])
        corr = correction_for(corrections, aid, lap)

        if corr:
            record["correction_applied"] = True
            record["correction"] = corr

            # Distanza
            corrected_distance = safe_int(corr.get("distance_corrected_m"))
            if corrected_distance is not None and 0 <= corrected_distance <= 400 and corrected_distance % 25 == 0:
                record["distance_original_m"] = record["distance_m"]
                record["distance_m"] = float(corrected_distance)
                record["distance_nominal_m"] = corrected_distance

                if corrected_distance > 0 and record.get("elapsed_s"):
                    record["pace_sec100"] = record["elapsed_s"] * 100.0 / corrected_distance
                    record["derived_speed_mps"] = corrected_distance / record["elapsed_s"]

            # Stile manuale
            style = corr.get("style")
            if is_manual(style):
                record["style_original"] = record.get("style")
                record["style"] = canonical_style(style) or record["style"]
                record["style_source"] = "manual"
            else:
                record["style_source"] = "automatic"

            # Attrezzatura manuale
            equipment = corr.get("equipment")
            if is_manual(equipment):
                record["equipment"] = str(equipment)
                record["equipment_source"] = "manual"
            else:
                record["equipment"] = "none"
                record["equipment_source"] = "automatic"

            # Classificazione manuale
            classification = corr.get("classification")
            if classification == "artifact":
                record["classification"] = "artifact"
                record["classification_source"] = "manual"
            elif classification == "possible_special":
                record["classification"] = "possible_special"
                record["classification_source"] = "manual"
            elif classification == "normal_swim":
                record["classification"] = "normal_swim"
                record["classification_source"] = "manual"
            elif is_manual(classification):
                record["classification_source"] = "manual"

            # Un equipment esplicito (pinne) non deve essere trattato come errore.
            if record.get("equipment") not in ("none", "") and classification in (None, "", "auto"):
                record["classification"] = "normal_swim"
                record["classification_source"] = "equipment_override"

        # Gli artifact automatici/manuali non entrano nelle metriche.
        if record.get("classification") != "artifact" and record.get("distance_m", 0) > 0:
            result.append(record)

    # Vasche completamente mancanti aggiunte dalla Web UI
    for key, corr in corrections.items():
        prefix = None
        aid = None
        manual_id = None
        if ":manual:" in key:
            aid, manual_id = key.split(":manual:", 1)
        else:
            continue

        distance = safe_int(corr.get("distance_corrected_m"))
        if distance is None or distance <= 0:
            continue

        # evitiamo duplicazioni se un record manuale fosse gia' stato materializzato
        manual_record = {
            "activity_id": aid,
            "date": None,
            "activity_name": "",
            "source_file": "manual",
            "lap": f"manual:{manual_id}",
            "distance_m": float(distance),
            "distance_nominal_m": distance,
            "elapsed_s": None,
            "pace_sec100": None,
            "speed_mps": None,
            "derived_speed_mps": None,
            "speed_ratio": None,
            "strokes": None,
            "strokes_per_25": None,
            "cadence": None,
            "style": canonical_style(corr.get("style")) or "unknown",
            "equipment": corr.get("equipment") if is_manual(corr.get("equipment")) else "none",
            "classification": corr.get("classification") if corr.get("classification") in ("possible_special", "artifact") else "normal_swim",
            "classification_source": "manual",
            "special_reason": None,
            "special_reasons": [],
            "correction_applied": True,
            "manual_missing_distance": True,
            "manual_note": corr.get("note", ""),
        }

        if manual_record["classification"] != "artifact":
            result.append(manual_record)

    return result


# ============================================================
# MANUAL MERGE OPERATIONS
# ============================================================

def apply_merge_operations(
    records: List[Dict[str, Any]],
    corrections: Dict[str, Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Unisce i record delle operazioni merge_laps salvate dalla Web UI.

    La consecutività viene valutata sull'ordine dei record presenti per attività,
    non sul valore numerico dei lap Garmin: ad esempio 19 e 22 possono essere
    adiacenti nell'elenco normalizzato.
    """
    operations_by_activity = defaultdict(list)

    for key, corr in corrections.items():
        if not isinstance(corr, dict):
            continue
        if corr.get("operation") != "merge_laps":
            continue
        if ":merge:" not in str(key):
            continue

        aid_from_key = str(key).split(":merge:", 1)[0]
        aid = str(corr.get("activity_id") or aid_from_key)

        raw_sources = corr.get("source_laps", [])
        if not isinstance(raw_sources, list):
            continue
        try:
            source_laps = sorted({int(x) for x in raw_sources})
        except (TypeError, ValueError):
            continue
        if len(source_laps) < 2:
            continue

        operations_by_activity[aid].append(source_laps)

    if not operations_by_activity:
        return records

    activity_rows = defaultdict(list)
    record_by_key = {}

    for record in records:
        aid = str(record.get("activity_id", ""))
        try:
            lap = int(record.get("lap"))
        except (TypeError, ValueError):
            # I record di vasche aggiunte manualmente hanno un lap non numerico.
            continue
        activity_rows[aid].append(record)
        record_by_key[(aid, lap)] = record

    merged_by_target = {}
    consumed_sources = set()
    applied_count = 0
    skipped_count = 0

    for aid, activity_ops in operations_by_activity.items():
        ordered_rows = sorted(
            activity_rows.get(aid, []),
            key=lambda r: int(r.get("lap")),
        )
        lap_numbers = [int(r.get("lap")) for r in ordered_rows]
        position_by_lap = {lap: i for i, lap in enumerate(lap_numbers)}
        reserved = set()

        # Processa le operazioni nell'ordine in cui compaiono nella seduta.
        activity_ops.sort(
            key=lambda src: position_by_lap.get(src[0], 10**9)
        )

        for source_laps in activity_ops:
            positions = [position_by_lap.get(lap) for lap in source_laps]
            if (
                any(pos is None for pos in positions)
                or positions != list(range(positions[0], positions[0] + len(positions)))
                or any((aid, lap) in reserved for lap in source_laps)
            ):
                skipped_count += 1
                continue

            selected = [record_by_key.get((aid, lap)) for lap in source_laps]
            if any(row is None for row in selected):
                skipped_count += 1
                continue

            # La UI non consente unioni sovrapposte; questo controllo protegge
            # anche da corrections.json creati/modificati manualmente.
            source_distances = [
                max(0.0, safe_float(row.get("distance_m")) or 0.0)
                for row in selected
            ]
            source_times = [
                max(0.0, safe_float(row.get("elapsed_s")) or 0.0)
                for row in selected
            ]
            total_distance = sum(source_distances)
            total_elapsed = sum(source_times)

            if total_distance <= 0 or total_elapsed <= 0:
                skipped_count += 1
                continue

            merged = dict(selected[0])
            original_distances = [
                safe_float(
                    row.get(
                        "distance_original_m",
                        row.get("distance_m", 0),
                    )
                ) or 0.0
                for row in selected
            ]
            merged["distance_original_m"] = sum(original_distances)
            merged["distance_m"] = total_distance
            merged["distance_nominal_m"] = int(round(total_distance / 25.0) * 25)
            merged["elapsed_s"] = total_elapsed
            merged["pace_sec100"] = total_elapsed * 100.0 / total_distance
            merged["derived_speed_mps"] = total_distance / total_elapsed
            # La velocità Garmin non è sommabile/mediabile in modo affidabile.
            merged["speed_mps"] = None
            merged["speed_ratio"] = None
            merged["lap"] = source_laps[0]
            merged["merged"] = True
            merged["merged_source_laps"] = list(source_laps)
            merged["merge_operation"] = True
            merged["correction_applied"] = True

            # Calcola una media pesata delle bracciate per 25 m.
            estimated_strokes = []
            exact_strokes = []
            cadences = []
            styles = []
            equipment = []
            classifications = []
            reasons = []

            for row, dist, elapsed in zip(selected, source_distances, source_times):
                stroke_count = safe_float(row.get("strokes"))
                strokes_per_25 = safe_float(row.get("strokes_per_25"))
                if stroke_count is not None:
                    exact_strokes.append(stroke_count)
                    estimated_strokes.append(stroke_count)
                elif strokes_per_25 is not None and dist > 0:
                    estimated_strokes.append(strokes_per_25 * dist / 25.0)

                cadence = safe_float(row.get("cadence"))
                if cadence is not None and cadence > 0 and elapsed > 0:
                    cadences.append((cadence, elapsed))

                style = row.get("style")
                if style:
                    styles.append(style)
                eq = row.get("equipment") or "none"
                if eq:
                    equipment.append(eq)
                cls = row.get("classification")
                if cls:
                    classifications.append(cls)
                reasons.extend(row.get("special_reasons") or [])
                if row.get("special_reason"):
                    reasons.append(row["special_reason"])

            if estimated_strokes and total_distance > 0:
                merged["strokes_per_25"] = sum(estimated_strokes) / (total_distance / 25.0)
            else:
                merged["strokes_per_25"] = None
            merged["strokes"] = sum(exact_strokes) if len(exact_strokes) == len(selected) else None

            if cadences:
                merged["cadence"] = sum(value * weight for value, weight in cadences) / sum(weight for _, weight in cadences)
            else:
                merged["cadence"] = None

            unique_styles = set(styles)
            merged["style"] = next(iter(unique_styles)) if len(unique_styles) == 1 else ("mixed" if unique_styles else "unknown")
            merged["style_source"] = "manual_merge"

            unique_equipment = set(equipment)
            merged["equipment"] = next(iter(unique_equipment)) if len(unique_equipment) == 1 else "other"
            merged["equipment_source"] = "manual_merge"

            # Se un segmento è stato classificato manualmente, rispetta la
            # scelta sul lap iniziale; altrimenti conserva la classificazione
            # speciale se almeno uno dei segmenti lo era.
            first = selected[0]
            if first.get("classification_source") == "manual":
                merged["classification"] = first.get("classification", "normal_swim")
                merged["classification_source"] = "manual_merge"
            elif "possible_special" in classifications:
                merged["classification"] = "possible_special"
                merged["classification_source"] = "automatic_merge"
            else:
                merged["classification"] = first.get("classification", "normal_swim")
                merged["classification_source"] = "automatic_merge"

            merged["special_reasons"] = list(dict.fromkeys(reasons))
            merged["special_reason"] = merged["special_reasons"][0] if merged["special_reasons"] else None
            merged["merged_note"] = f"Unione dei lap {', '.join(str(x) for x in source_laps)}"

            merged_by_target[(aid, source_laps[0])] = merged
            for lap in source_laps:
                reserved.add((aid, lap))
                if lap != source_laps[0]:
                    consumed_sources.add((aid, lap))
            applied_count += 1

    if applied_count:
        print(f"Unioni manuali applicate al profilo: {applied_count}")
    if skipped_count:
        print(f"ATTENZIONE: unioni non applicate per lap mancanti, non adiacenti o sovrapposti: {skipped_count}")

    result = []
    for record in records:
        aid = str(record.get("activity_id", ""))
        try:
            lap = int(record.get("lap"))
        except (TypeError, ValueError):
            result.append(record)
            continue

        key = (aid, lap)
        if key in consumed_sources:
            continue
        result.append(merged_by_target.get(key, record))

    return result


# ============================================================
# TREND / PROFILE
# ============================================================

def session_values(records: List[Dict[str, Any]], metric: str) -> List[Tuple[str, str, float]]:
    grouped = defaultdict(list)
    dates = {}
    for r in records:
        value = safe_float(r.get(metric))
        if value is None:
            continue
        aid = str(r["activity_id"])
        grouped[aid].append(value)
        dates[aid] = r.get("date") or ""

    result = []
    for aid, values in grouped.items():
        m = median(values)
        if m is not None:
            result.append((dates.get(aid, ""), aid, m))

    result.sort(key=lambda x: (x[0], x[1]))
    return result


def trend_for(records: List[Dict[str, Any]], metric: str, lower_is_better: bool = True) -> Tuple[str, Optional[float], Optional[float], int]:
    sessions = session_values(records, metric)
    n = len(sessions)
    if n < 3:
        m = median(x[2] for x in sessions)
        return "insufficient_data", m, m, n

    if n >= 6:
        older = sessions[-6:-3]
        recent = sessions[-3:]
    else:
        older = sessions[:1]
        recent = sessions[-3:]

    old = median(x[2] for x in older)
    new = median(x[2] for x in recent)
    if old is None or new is None:
        return "insufficient_data", old, new, n

    change = (new - old) / old if old else 0.0

    if lower_is_better:
        if change <= -0.02:
            return "improving", old, new, n
        if change >= 0.02:
            return "declining", old, new, n
    else:
        if change >= 0.02:
            return "improving", old, new, n
        if change <= -0.02:
            return "declining", old, new, n

    return "stable", old, new, n


def technical_coverage(records: List[Dict[str, Any]]) -> float:
    if not records:
        return 0.0
    valid = sum(1 for r in records if r.get("strokes_per_25") is not None or r.get("cadence") is not None)
    return 100.0 * valid / len(records)


def confidence(n: int, coverage: float) -> str:
    if n >= 12 and coverage >= 75:
        return "high"
    if n >= 5 and coverage >= 50:
        return "medium"
    if n >= 3:
        return "low"
    return "very_low"


def distance_profile(records: List[Dict[str, Any]], include_missing: bool = False) -> Dict[str, Any]:
    timed = [r for r in records if r.get("elapsed_s") is not None and r.get("pace_sec100") is not None]

    paces = [r["pace_sec100"] for r in timed]
    strokes = [r["strokes_per_25"] for r in timed if r.get("strokes_per_25") is not None]
    cadence = [r["cadence"] for r in timed if safe_float(r.get("cadence")) and r["cadence"] > 0]

    trend, older_med, recent_med, sessions = trend_for(timed, "pace_sec100", lower_is_better=True)

    ordered = sorted(timed, key=lambda r: (r.get("date") or "", str(r["activity_id"]), str(r["lap"])), reverse=True)
    recent = ordered[:10]

    coverage = technical_coverage(timed)

    best = min(timed, key=lambda r: r["pace_sec100"]) if timed else None

    return {
        "n": len(timed),
        "missing_data": sum(1 for r in records if r.get("elapsed_s") is None),
        "best_time_s": min((r["elapsed_s"] for r in timed), default=None),
        "best_pace_sec100": min(paces, default=None),
        "fast_quartile_pace_sec100": percentile(paces, 0.25),
        "median_pace_sec100": median(paces),
        "older_median_pace_sec100": older_med,
        "recent_median_pace_sec100": recent_med,
        "worst_pace_sec100": max(paces, default=None),
        "trend": trend,
        "sessions": sessions,
        "strokes_per_25_avg": mean(strokes),
        "strokes_per_25_recent": mean([r["strokes_per_25"] for r in recent if r.get("strokes_per_25") is not None]),
        "strokes_trend": trend_for(timed, "strokes_per_25", lower_is_better=True)[0],
        "cadence_avg": mean(cadence),
        "cadence_recent": mean([r["cadence"] for r in recent if r.get("cadence") is not None and r["cadence"] > 0]),
        "technical_coverage_pct": coverage,
        "confidence": confidence(len(timed), coverage),
        "best_observation": {
            "activity_id": best["activity_id"],
            "date": best.get("date"),
            "lap": best["lap"],
            "time": fmt_time(best["elapsed_s"]),
            "pace": fmt_pace(best["pace_sec100"]),
            "strokes_per_25": best.get("strokes_per_25"),
            "cadence": best.get("cadence"),
        } if best else None,
        "recent_observations": [
            {
                "activity_id": r["activity_id"],
                "date": r.get("date"),
                "lap": r["lap"],
                "time": fmt_time(r.get("elapsed_s")),
                "pace": fmt_pace(r.get("pace_sec100")),
                "strokes_per_25": r.get("strokes_per_25"),
                "cadence": r.get("cadence"),
            }
            for r in recent
        ],
    }


def build_style_equipment_profile(records: List[Dict[str, Any]], style: str, equipment: str) -> Dict[str, Any]:
    selected = [r for r in records if r.get("style") == style and r.get("equipment", "none") == equipment]

    result = {
        "style": style,
        "style_label": style_label(style),
        "equipment": equipment,
        "equipment_label": equipment_label(equipment),
        "observations": len(selected),
        "special_observations": sum(1 for r in selected if r.get("classification") == "possible_special"),
        "distances": {},
    }

    for distance in PROFILE_DISTANCES:
        subset = [r for r in selected if r.get("distance_nominal_m") == distance and r.get("classification") == "normal_swim"]
        result["distances"][str(distance)] = distance_profile(subset)

    return result


# ============================================================
# SUMMARY
# ============================================================

def build_summary(records: List[Dict[str, Any]], history: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    activity_ids = sorted({str(r["activity_id"]) for r in records if isinstance(r.get("activity_id"), str)})

    distances = []
    durations = []
    avg_hr = []
    max_hr = []
    loads = []

    for aid in activity_ids:
        m = history.get(aid, {})
        if m.get("distance") is not None:
            distances.append(m["distance"])
        if m.get("duration") is not None:
            durations.append(m["duration"])
        if m.get("avg_hr") is not None:
            avg_hr.append(m["avg_hr"])
        if m.get("max_hr") is not None:
            max_hr.append(m["max_hr"])
        if m.get("training_load") is not None:
            loads.append(m["training_load"])

    if not distances:
        grouped = defaultdict(float)
        for r in records:
            grouped[str(r["activity_id"])] += float(r.get("distance_m") or 0)
        distances = list(grouped.values())

    return {
        "activities_used": len(activity_ids),
        "normal_laps": sum(1 for r in records if r.get("classification") == "normal_swim"),
        "special_laps": sum(1 for r in records if r.get("classification") == "possible_special"),
        "average_activity_distance_m": mean(distances),
        "average_activity_duration_s": mean(durations),
        "average_hr": mean(avg_hr),
        "max_hr_observed": max(max_hr) if max_hr else None,
        "average_training_load": mean(loads),
        "styles": dict(sorted(defaultdict(int, ((r.get("style", "unknown"), 0) for r in [])).items())),
        "equipment_counts": {},
    }


def json_clean(obj: Any) -> Any:
    if isinstance(obj, float):
        return round(obj, 4) if math.isfinite(obj) else None
    if isinstance(obj, dict):
        return {k: json_clean(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_clean(v) for v in obj]
    return obj


# ============================================================
# PRINT
# ============================================================

def print_table(profile: Dict[str, Any]) -> None:
    print()
    print(f"{profile['style_label']} — {profile['equipment_label']}")
    print("-" * 105)
    print(f"  Osservazioni: {profile['observations']}   Speciali: {profile['special_observations']}")
    print()
    print(f"  {'Dist':>5} {'N':>4} {'Migliore':>10} {'25%':>10} {'Mediana':>10} {'Recente':>10} {'Br/25':>8} {'Trend':>12} {'Conf.':>10}")
    for distance in PROFILE_DISTANCES:
        p = profile["distances"][str(distance)]
        strokes_value = p["strokes_per_25_avg"]
        strokes_text = f"{strokes_value:.1f}" if strokes_value is not None else "-"
        print(
            f"  {distance:>3} m {p['n']:>4} {fmt_pace(p['best_pace_sec100']):>10} "
            f"{fmt_pace(p['fast_quartile_pace_sec100']):>10} "
            f"{fmt_pace(p['median_pace_sec100']):>10} "
            f"{fmt_pace(p['recent_median_pace_sec100']):>10} "
            f"{strokes_text:>8} "
            f"{p['trend']:>12} {p['confidence']:>10}"
        )


def main() -> int:
    print("=" * 105)
    print(f"PROFILO NUOTATORE V{VERSION}")
    print("=" * 105)

    if not HISTORY_FILE.exists():
        print(f"ERRORE: manca {HISTORY_FILE}")
        return 1

    history = load_history()
    corrections = load_corrections()

    analysis_files = []
    for path in sorted(DATA_DIR.glob("*_analysis.json")):
        aid = path.name.split("_", 1)[0]
        if not aid.isdigit():
            continue
        data = load_json(path, None)
        if data is not None:
            analysis_files.append((aid, path, data))

    if not analysis_files:
        print("ERRORE: nessun *_analysis.json trovato.")
        return 1

    records = []
    used_files = 0

    for aid, path, analysis in analysis_files:
        meta = dict(history.get(aid, {}))

        # Se lo storico non contiene data o nome, recuperali
        # dall'estrazione originale di InfluxDB.
        if not meta.get("date") or not meta.get("name"):
            raw_activity = load_json(DATA_DIR / f"{aid}.json", {})
            summary = (
                raw_activity.get("summary", {})
                if isinstance(raw_activity, dict)
                else {}
            )
            if not isinstance(summary, dict):
                summary = {}

            if not meta.get("date"):
                stamp = summary.get("time_iso") or summary.get("time")
                try:
                    if isinstance(stamp, (int, float)):
                        dt = datetime.fromtimestamp(
                            float(stamp) / 1000
                        ).astimezone()
                    elif stamp:
                        dt = datetime.fromisoformat(
                            str(stamp).replace("Z", "+00:00")
                        ).astimezone()
                    else:
                        dt = None

                    if dt is not None:
                        meta["date"] = dt.date().isoformat()
                except (TypeError, ValueError, OverflowError, OSError):
                    pass

            if not meta.get("name"):
                activity_meta = (
                    analysis.get("activity", {})
                    if isinstance(analysis, dict)
                    else {}
                )
                if not isinstance(activity_meta, dict):
                    activity_meta = {}

                meta["name"] = (
                    summary.get("activityName")
                    or summary.get("ActivityName")
                    or activity_meta.get("name")
                    or ""
                )

        current = load_analysis_records(aid, analysis, meta, path.name)
        if current:
            used_files += 1
            records.extend(current)

    if not records:
        print("ERRORE: nessun lap valido trovato nelle analisi.")
        return 1

    automatic_classification(records)

    # Mantieni una copia non corretta/non accorpata per la Web UI: serve a
    # visualizzare i lap originali e rende sempre possibile annullare un merge.
    ui_records = copy.deepcopy(records)

    # Il profilo di coaching usa invece correzioni manuali e unioni applicate.
    records = apply_corrections(records, corrections)
    records = apply_merge_operations(records, corrections)

    # Le registrazioni Garmin separate ma appartenenti alla stessa seduta
    # vengono raggruppate solo per il coaching; all_observations resta originale.
    activity_merge_data = load_activity_merges()
    records, history, applied_activity_merges, activity_merge_warnings = apply_activity_merges(
        records, activity_merge_data, history
    )
    for warning in activity_merge_warnings:
        print(f"ATTENZIONE unione registrazioni: {warning}")

    # Normalizzazione equipment.
    for r in records:
        eq = r.get("equipment") or "none"
        if eq == "auto":
            eq = "none"
        if eq not in SUPPORTED_EQUIPMENT:
            eq = "other"
        r["equipment"] = eq

    # Counts.
    style_counts = defaultdict(int)
    equipment_counts = defaultdict(int)
    classification_counts = defaultdict(int)

    for r in records:
        style_counts[r.get("style", "unknown")] += 1
        equipment_counts[r.get("equipment", "none")] += 1
        classification_counts[r.get("classification", "unknown")] += 1

    summary = build_summary(records, history)

    # Distanza ricostruita dalle osservazioni corrette (separata dal totale
    # Garmin storico, che rimane disponibile in average_activity_distance_m).
    corrected_distances_by_activity = defaultdict(float)
    for record in records:
        distance = safe_float(record.get("distance_m")) or 0.0
        if distance > 0 and record.get("classification") != "artifact":
            corrected_distances_by_activity[str(record["activity_id"])] += distance
    corrected_distance_values = list(corrected_distances_by_activity.values())
    summary["average_activity_distance_corrected_m"] = mean(corrected_distance_values)
    summary["activities_with_corrected_distance"] = len(corrected_distance_values)
    summary["analysis_files_found"] = len(analysis_files)
    summary["analysis_files_with_laps"] = used_files
    summary["normal_laps"] = classification_counts.get("normal_swim", 0)
    summary["special_laps"] = classification_counts.get("possible_special", 0)
    summary["artifact_laps"] = classification_counts.get("artifact", 0)
    summary["styles"] = dict(style_counts)
    summary["equipment_counts"] = dict(equipment_counts)
    summary["special_reasons"] = dict(
        defaultdict(int,
            ((r.get("special_reason") or "unknown", 1)
             for r in records if r.get("classification") == "possible_special")
        )
    )

    profiles = {}
    for style in SUPPORTED_STYLES:
        profiles[style] = {}
        for equipment in SUPPORTED_EQUIPMENT:
            selected = [r for r in records if r.get("style") == style and r.get("equipment") == equipment]
            if selected:
                profiles[style][equipment] = build_style_equipment_profile(records, style, equipment)

    # Profilo standard freestyle per compatibilita'.
    standard_freestyle = profiles.get("freestyle", {}).get("none")
    distances_compat = standard_freestyle["distances"] if standard_freestyle else {
        str(d): distance_profile([]) for d in PROFILE_DISTANCES
    }

    special_records = [r for r in records if r.get("classification") == "possible_special"]
    manual_fins = [r for r in records if r.get("equipment") == "fins"]
    artifacts = [r for r in records if r.get("classification") == "artifact"]

    output = {
        "version": VERSION,
        "merged_repetitions_count": sum(1 for r in records if r.get("merged")),
        "merged_sessions_count": len(applied_activity_merges),
        "activity_merges": applied_activity_merges,
        "activity_merge_warnings": activity_merge_warnings,
        "generated_at": datetime.now().astimezone().isoformat(),
        "summary": summary,
        "profiles": profiles,
        "distances": distances_compat,
        # Osservazioni non modificate per l'editor; il motore usa quelle coaching sotto.
        "all_observations": ui_records,
        "coaching_observations": records,
        "manual_corrections_count": len(corrections),
        "manual_fins_observations": len(manual_fins),
        "special_observations": [
            {
                "activity_id": r["activity_id"],
                "date": r.get("date"),
                "lap": r["lap"],
                "style": r.get("style"),
                "equipment": r.get("equipment"),
                "distance_m": r.get("distance_m"),
                "time": fmt_time(r.get("elapsed_s")),
                "pace": fmt_pace(r.get("pace_sec100")),
                "reason": r.get("special_reason"),
            }
            for r in special_records
        ],
        "artifact_observations": [
            {
                "activity_id": r["activity_id"],
                "date": r.get("date"),
                "lap": r["lap"],
                "style": r.get("style"),
                "distance_m": r.get("distance_m"),
            }
            for r in artifacts
        ],
        "notes": [
            "Le correzioni manuali della Web UI hanno priorita' sui dati automatici.",
            "Le ripetute marcate PINNE sono escluse dal profilo standard e conservate nel profilo PINNE.",
            "Un equipment esplicito non viene interpretato come errore Garmin.",
            "Gli artifact manuali sono esclusi dalle metriche.",
            "Le vasche manuali contribuiscono alla distanza ma non inventano tempo o dati tecnici.",
            "Le registrazioni unite nella stessa seduta restano distinte in all_observations e sono raggruppate solo in coaching_observations.",
            "Butterfly e' supportato tecnicamente ma non deve essere utilizzato dal coach come stile praticato senza conferma manuale.",
            "Breaststroke va interpretato con cautela perche' puo' contenere errori Garmin.",
        ],
    }

    with OUTPUT_FILE.open("w", encoding="utf-8") as f:
        json.dump(json_clean(output), f, ensure_ascii=False, indent=2)
        f.write("\n")

    # Console summary.
    print(f"Attività utilizzate:          {summary['activities_used']}")
    print(f"Analisi caricate:             {used_files}")
    print(f"Lap normali:                  {summary['normal_laps']}")
    print(f"Lap possibili speciali:       {summary['special_laps']}")
    print(f"Lap esclusi come artefatti:   {summary['artifact_laps']}")
    if summary.get("average_activity_distance_m") is not None:
        print(f"Distanza media seduta:        {summary['average_activity_distance_m']:.0f} m")
    if summary.get("average_activity_duration_s") is not None:
        print(f"Tempo medio nuoto:            {fmt_time(summary['average_activity_duration_s'])}")
    if summary.get("average_hr") is not None:
        print(f"FC media storico:             {summary['average_hr']:.0f} bpm")
    if summary.get("max_hr_observed") is not None:
        print(f"FC max osservata:             {summary['max_hr_observed']:.0f} bpm")
    if summary.get("average_training_load") is not None:
        print(f"Training Load medio:          {summary['average_training_load']:.1f}")

    print()
    print("EQUIPMENT")
    print("-" * 105)
    for equipment in SUPPORTED_EQUIPMENT:
        count = equipment_counts.get(equipment, 0)
        if count:
            print(f"  {equipment_label(equipment):22} {count:4} lap")

    if manual_fins:
        print()
        print("RIPETUTE MARCATE CON PINNE")
        print("-" * 105)
        for r in sorted(manual_fins, key=lambda x: (x.get("date") or "", x["activity_id"], str(x["lap"]))):
            print(
                f"  {r.get('date')} {r['activity_id']} lap={r['lap']} "
                f"{r.get('distance_nominal_m')} m {style_label(r.get('style','unknown'))} "
                f"time={fmt_time(r.get('elapsed_s'))} pace={fmt_pace(r.get('pace_sec100'))}"
            )

    if special_records:
        print()
        print("POSSIBILI LAVORI SPECIALI NON CORRETTI MANUALMENTE")
        print("-" * 105)
        for r in sorted(special_records, key=lambda x: (x.get("date") or "", x["activity_id"], str(x["lap"]))):
            print(
                f"  {r.get('date')} {r['activity_id']} lap={r['lap']} "
                f"{r.get('distance_nominal_m')} m {style_label(r.get('style','unknown'))} "
                f"time={fmt_time(r.get('elapsed_s'))} pace={fmt_pace(r.get('pace_sec100'))} "
                f"→ {r.get('special_reason')}"
            )

    print()
    print("PROFILI")
    print("=" * 105)

    # Ordine: standard e pinne per gli stili che esistono.
    for style in ("freestyle", "backstroke", "breaststroke", "butterfly", "mixed", "unknown"):
        for equipment in ("none", "fins", "pull_buoy", "paddles", "kickboard", "other"):
            profile = profiles.get(style, {}).get(equipment)
            if profile and profile["observations"]:
                print_table(profile)

    print()
    print("DIAGNOSTICA")
    print("-" * 105)
    for style in SUPPORTED_STYLES:
        if style_counts.get(style, 0):
            print(f"  {style_label(style):14} {style_counts[style]:4} lap")
    print()
    for equipment in SUPPORTED_EQUIPMENT:
        if equipment_counts.get(equipment, 0):
            print(f"  {equipment_label(equipment):22} {equipment_counts[equipment]:4} lap")

    print()
    print("NOTE")
    print("-" * 105)
    print("  • corrections.json viene applicato dopo la classificazione automatica.")
    print("  • PINNE e' una categoria di profilo, non un errore.")
    print("  • Un lap con pinne non viene usato per il ritmo standard.")
    print("  • Le correzioni di distanza ricalcolano il passo.")
    print("  • Le vasche manuali senza tempo aumentano la distanza ma non la prestazione.")
    print()
    print(f"Correzioni lette:             {len(corrections)}")
    print(f"Ripetute unite nel profilo:    {sum(1 for r in records if r.get('merged'))}")
    print(f"Registrazioni unite in sedute: {len(applied_activity_merges)}")
    print(f"Profilo JSON:                 {OUTPUT_FILE}")
    print("=" * 105)

    return 0


if __name__ == "__main__":
    sys.exit(main())
