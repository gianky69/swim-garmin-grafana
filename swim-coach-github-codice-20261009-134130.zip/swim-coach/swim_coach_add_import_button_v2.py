#!/usr/bin/env python3
"""Install a manual InfluxDB-import button for Swim Coach V1.4-style UI.

Backs up all edited files, validates both prospective Python modules before
writing, and refuses unknown/partially patched layouts.
"""
from __future__ import annotations

import argparse
import shutil
import sys
from datetime import datetime
from pathlib import Path

DASHBOARD_OLD = '''body = f"""
{message_html}
<div class='card'>
<h2>Swim Coach</h2>
'''

DASHBOARD_NEW = '''body = f"""
{message_html}
<div class='card'>
<h2>Importazione manuale Garmin</h2>
<p>Controlla InfluxDB per individuare le attività di nuoto non ancora importate in Swim Coach, genera le analisi mancanti e aggiorna i report delle sedute di oggi.</p>
<p class='small'>Il pulsante legge le attività già presenti in InfluxDB/Garmin Grafana; non forza una sincronizzazione con Garmin Connect. Se l'attività non è ancora arrivata in InfluxDB, riprova dopo la sincronizzazione.</p>
<form method='post' action='/import-activities' onsubmit="return confirm('Cercare e importare le nuove attività disponibili in InfluxDB? L’operazione può richiedere qualche minuto.')">
<button type='submit' class='warnbtn'>Controlla e importa nuove attività</button>
</form>
</div>
<div class='card'>
<h2>Swim Coach</h2>
'''

POST_ROUTE = '''
        if path == "/import-activities":
            command = [sys.executable, str(BASE_DIR / "import_new_activities.py")]
            try:
                result = subprocess.run(
                    command,
                    cwd=str(BASE_DIR),
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    timeout=900,
                    check=False,
                )
                output = result.stdout or "(Nessun output prodotto.)"
                if result.returncode == 0:
                    headline = "Importazione completata con successo."
                else:
                    headline = f"Importazione terminata con codice {result.returncode}."
            except subprocess.TimeoutExpired as exc:
                output = exc.stdout or ""
                if isinstance(output, bytes):
                    output = output.decode("utf-8", errors="replace")
                headline = "Tempo massimo superato: controlla i log e lo stato dell’importazione."
            except OSError as exc:
                output = str(exc)
                headline = "Impossibile avviare l’importazione."

            body = f"""
<div class='card'>
<h2>Importazione attività Garmin</h2>
<p class='notice'>{html.escape(headline)}</p>
<p class='small'>Sono mostrati al massimo gli ultimi 24.000 caratteri del log.</p>
<pre style='white-space:pre-wrap;overflow-wrap:anywhere;max-height:70vh;overflow:auto'>{html.escape(output[-24000:])}</pre>
<div class='toolbar'>
<a class='button' href='/'>Torna alla dashboard</a>
<a class='button secondary' href='/reports'>Apri i report</a>
</div>
</div>
"""
            self.send_html(render_page("Importazione attività", body))
            return

'''

LOCK_WRAPPER = '''

def main():
    """Serializza importazioni manuali e pianificate."""
    lock_path = BASE / ".import_new_activities.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+", encoding="utf-8") as lock_handle:
        try:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("Importazione già in corso; nessuna seconda esecuzione avviata.", file=sys.stderr)
            return 2
        try:
            return _main_unlocked()
        finally:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)

'''


def replace_once(source: str, old: str, new: str, label: str) -> str:
    count = source.count(old)
    if count != 1:
        raise RuntimeError(
            f"Patch interrotta: punto '{label}' trovato {count} volte, attesa 1."
        )
    return source.replace(old, new, 1)


def add_post_route(source: str) -> str:
    if 'if path == "/import-activities":' in source:
        raise RuntimeError("La route /import-activities è già presente, ma la patch non risulta completa.")
    post_start = source.find("    def do_POST(self):")
    if post_start < 0:
        raise RuntimeError("Non trovo il metodo do_POST(self).")
    path_line = "        path = parsed.path"
    index = source.find(path_line, post_start)
    if index < 0:
        raise RuntimeError("Non trovo path = parsed.path dentro do_POST.")
    # Ensure this is the first route dispatch point inside do_POST.
    insert_at = index + len(path_line)
    return source[:insert_at] + "\n" + POST_ROUTE + source[insert_at:]


def lock_importer(source: str) -> str:
    if ".import_new_activities.lock" in source and "fcntl.flock" in source:
        return source
    if "def main():" not in source:
        raise RuntimeError("Non trovo def main() in import_new_activities.py.")
    source = replace_once(
        source,
        "import json\nimport subprocess\n",
        "import fcntl\nimport json\nimport subprocess\n",
        "import fcntl",
    )
    source = replace_once(
        source,
        "def main():\n",
        "def _main_unlocked():\n",
        "rinomina main importatore",
    )
    marker = '\nif __name__ == "__main__":\n'
    source = replace_once(source, marker, LOCK_WRAPPER + marker, "wrapper lock importatore")
    return source


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dir", type=Path, default=Path("/opt/swim-coach"))
    args = parser.parse_args()
    base = args.base_dir.resolve()
    web_file = base / "swim_coach_web.py"
    importer_file = base / "import_new_activities.py"

    for required in (web_file, importer_file):
        if not required.is_file():
            print(f"ERRORE: file richiesto mancante: {required}", file=sys.stderr)
            return 1

    web_src = web_file.read_text(encoding="utf-8")
    importer_src = importer_file.read_text(encoding="utf-8")

    if 'if path == "/import-activities":' in web_src or "Importazione manuale Garmin" in web_src:
        print("La route o il riquadro è già presente: controllo manuale necessario; nessuna modifica effettuata.")
        return 1

    # Prepare changes in memory; nothing is written until all anchors and compile checks pass.
    web_new = replace_once(web_src, DASHBOARD_OLD, DASHBOARD_NEW, "scheda dashboard")
    web_new = add_post_route(web_new)
    importer_new = lock_importer(importer_src)

    compile(web_new, str(web_file), "exec")
    compile(importer_new, str(importer_file), "exec")

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup_dir = base / "backups" / f"web-import-button-v2-{stamp}"
    backup_dir.mkdir(parents=True, exist_ok=False)
    shutil.copy2(web_file, backup_dir / web_file.name)
    shutil.copy2(importer_file, backup_dir / importer_file.name)

    web_file.write_text(web_new, encoding="utf-8")
    importer_file.write_text(importer_new, encoding="utf-8")
    print("Pulsante e route di importazione installati.")
    print(f"Backup dei file originali: {backup_dir}")
    print("Importatore protetto da lock per evitare esecuzioni simultanee manuali/automatiche.")
    print("Ora esegui: python3 -m py_compile swim_coach_web.py import_new_activities.py")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERRORE: {exc}", file=sys.stderr)
        raise SystemExit(1)
