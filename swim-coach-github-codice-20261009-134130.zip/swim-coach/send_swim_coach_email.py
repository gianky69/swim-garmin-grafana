#!/usr/bin/env python3
"""Invia digest settimanali e promemoria delle sedute Swim Coach via Postfix."""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import date, datetime, timedelta
from email.message import EmailMessage
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

BASE_DIR = Path(os.environ.get("SWIM_COACH_BASE_DIR", "/opt/swim-coach"))
DATA_DIR = BASE_DIR / "data"
REPORT_DIR = BASE_DIR / "reports"
PLAN_FILE = DATA_DIR / "upcoming_workouts.json"
STATE_FILE = DATA_DIR / "email_state.json"
CONFIG_FILE = Path(os.environ.get("SWIM_COACH_EMAIL_CONFIG", "/etc/swim-coach-email.conf"))
REPORT_PATTERN = re.compile(r"^swim-report-(\d{4}-\d{2}-\d{2})-.+\.txt$")
EMAIL_PATTERN = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


def load_config() -> tuple[str, str, ZoneInfo]:
    cfg: dict[str, str] = {}
    if CONFIG_FILE.is_file():
        for raw in CONFIG_FILE.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            cfg[key.strip()] = value.strip().strip("\"'")
    # Environment variables override the config file.
    for key in ("SWIM_COACH_EMAIL_TO", "SWIM_COACH_EMAIL_FROM", "SWIM_COACH_TIMEZONE"):
        if os.environ.get(key):
            cfg[key] = os.environ[key]
    email_to = cfg.get("SWIM_COACH_EMAIL_TO", "").strip()
    email_from = cfg.get("SWIM_COACH_EMAIL_FROM", email_to).strip()
    timezone_name = cfg.get("SWIM_COACH_TIMEZONE", "Europe/Rome").strip()
    if not EMAIL_PATTERN.fullmatch(email_to):
        raise ValueError(f"Destinatario email mancante o non valido in {CONFIG_FILE}.")
    if not EMAIL_PATTERN.fullmatch(email_from):
        raise ValueError(f"Mittente email mancante o non valido in {CONFIG_FILE}.")
    try:
        timezone = ZoneInfo(timezone_name)
    except ZoneInfoNotFoundError as exc:
        raise ValueError(f"Fuso orario non disponibile: {timezone_name}") from exc
    return email_to, email_from, timezone


def parse_date(value: object) -> date | None:
    if value is None:
        return None
    try:
        return date.fromisoformat(str(value)[:10])
    except (TypeError, ValueError):
        return None


def load_workouts() -> list[dict]:
    if not PLAN_FILE.is_file():
        return []
    try:
        data = json.loads(PLAN_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Impossibile leggere il piano {PLAN_FILE}: {exc}") from exc
    if isinstance(data, list):
        items = data
    elif isinstance(data, dict):
        items = data.get("workouts", data.get("sessions", []))
    else:
        items = []
    if not isinstance(items, list):
        raise RuntimeError("Il campo workouts in upcoming_workouts.json non è una lista.")
    workouts = [item for item in items if isinstance(item, dict)]
    return sorted(workouts, key=lambda item: (parse_date(item.get("date") or item.get("scheduled_date")) or date.max,
                                               str(item.get("title") or item.get("name") or "")))


def load_reports(start: date, end: date) -> list[tuple[date, Path]]:
    results: list[tuple[date, Path]] = []
    if not REPORT_DIR.is_dir():
        return results
    for path in REPORT_DIR.glob("swim-report-*.txt"):
        match = REPORT_PATTERN.match(path.name)
        if not match or not path.is_file():
            continue
        report_date = parse_date(match.group(1))
        if report_date is not None and start <= report_date <= end:
            results.append((report_date, path))
    return sorted(results, key=lambda pair: (pair[0], pair[1].name))


def format_date(value: date) -> str:
    return value.strftime("%d/%m/%Y")


def format_workout(workout: dict, index: int | None = None) -> str:
    scheduled = parse_date(workout.get("date") or workout.get("scheduled_date"))
    title = str(workout.get("title") or workout.get("name") or f"Seduta {index or ''}").strip()
    distance = workout.get("distance_m")
    focus = str(workout.get("focus") or workout.get("goal") or "Obiettivo non specificato").strip()
    notes = str(workout.get("notes") or workout.get("description") or "").strip()
    lines = [f"{format_date(scheduled) if scheduled else 'Data da definire'} — {title}"]
    if distance not in (None, ""):
        lines.append(f"Distanza prevista: {distance} m")
    lines.append(f"Obiettivo: {focus}")
    if notes:
        lines.append(f"Note: {notes}")
    sets = workout.get("sets", workout.get("main_set", []))
    if isinstance(sets, list) and sets:
        lines.append("Serie:")
        for item in sets:
            if isinstance(item, dict):
                parts = [str(item.get(k)) for k in ("reps", "distance_m", "description", "pace", "rest") if item.get(k) not in (None, "")]
                if parts:
                    lines.append("  • " + " · ".join(parts))
            elif str(item).strip():
                lines.append("  • " + str(item).strip())
    return "\n".join(lines)


def load_state() -> dict:
    try:
        obj = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        if isinstance(obj, dict):
            return obj
    except (OSError, json.JSONDecodeError):
        pass
    return {"version": 1, "sent": {}}


def save_state(state: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_suffix(STATE_FILE.suffix + ".tmp")
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, STATE_FILE)


def mail_message(email_to: str, email_from: str, subject: str, body: str) -> EmailMessage:
    msg = EmailMessage()
    msg["From"] = email_from
    msg["To"] = email_to
    msg["Subject"] = subject
    msg.set_content(body, charset="utf-8")
    return msg


def deliver(msg: EmailMessage, email_from: str, dry_run: bool, state_key: str | None = None) -> None:
    if dry_run:
        print("=== MODALITÀ PROVA: EMAIL NON INVIATA ===")
        print(f"A: {msg['To']}")
        print(f"Da: {msg['From']}")
        print(f"Oggetto: {msg['Subject']}")
        print("\n" + msg.get_content())
        return
    if state_key:
        state = load_state()
        sent = state.setdefault("sent", {})
        if state_key in sent:
            print(f"Invio saltato: già inviato ({state_key}, {sent[state_key]}).")
            return
    sendmail = shutil.which("sendmail") or "/usr/sbin/sendmail"
    try:
        result = subprocess.run(
            [sendmail, "-i", "-f", email_from, "-t"],
            input=msg.as_bytes(),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=45,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError(f"Impossibile eseguire sendmail: {exc}") from exc
    if result.returncode != 0:
        detail = result.stderr.decode("utf-8", "replace").strip()
        raise RuntimeError(f"sendmail è terminato con codice {result.returncode}: {detail}")
    if state_key:
        state = load_state()
        state.setdefault("sent", {})[state_key] = datetime.now().astimezone().isoformat(timespec="seconds")
        save_state(state)
    print(f"Email consegnata a Postfix per l'invio: {msg['Subject']}")


def build_weekly(today: date, timezone: ZoneInfo, workouts: list[dict]) -> tuple[str, str]:
    start = today - timedelta(days=6)
    reports = load_reports(start, today)
    body = [
        "SWIM COACH — RIEPILOGO SETTIMANALE",
        f"Periodo: {format_date(start)} – {format_date(today)}",
        "",
        "ALLENAMENTI SVOLTI",
    ]
    if not reports:
        body.append("Nessun report di allenamento trovato nel periodo indicato.")
    else:
        body.append(f"Report trovati: {len(reports)}")
        for report_date, path in reports:
            body.extend(["", "=" * 68, f"REPORT: {format_date(report_date)} — {path.name}", "=" * 68])
            try:
                body.append(path.read_text(encoding="utf-8", errors="replace").strip())
            except OSError as exc:
                body.append(f"Impossibile leggere il report: {exc}")
    next_end = today + timedelta(days=6)
    upcoming = [w for w in workouts if (parse_date(w.get("date") or w.get("scheduled_date")) is not None
                                         and today <= parse_date(w.get("date") or w.get("scheduled_date")) <= next_end)]
    body.extend(["", "=" * 68, f"SEDUTE PROGRAMMATE NEI PROSSIMI 7 GIORNI ({format_date(today)} – {format_date(next_end)})", "=" * 68])
    if not upcoming:
        body.append("Nessuna seduta programmata nel periodo.")
    else:
        for i, workout in enumerate(upcoming, 1):
            body.extend(["", format_workout(workout, i)])
    subject = f"Swim Coach — riepilogo allenamenti {start.strftime('%d/%m')}–{today.strftime('%d/%m/%Y')}"
    return subject, "\n".join(body).strip() + "\n"


def build_daily(today: date) -> tuple[str, str] | None:
    reports = load_reports(today, today)
    if not reports:
        print(
            f"Nessun report di allenamento trovato per oggi "
            f"({format_date(today)}); nessuna email da inviare."
        )
        return None

    body = [
        "SWIM COACH — RIEPILOGO ALLENAMENTO",
        f"Data: {format_date(today)}",
        f"Report di attività trovati: {len(reports)}",
        "",
    ]

    for report_date, path in reports:
        body.extend([
            "=" * 68,
            f"ALLENAMENTO: {format_date(report_date)} — {path.name}",
            "=" * 68,
        ])
        try:
            content = path.read_text(encoding="utf-8", errors="replace").strip()
            body.append(content or "Il report è vuoto.")
        except OSError as exc:
            body.append(f"Impossibile leggere il report: {exc}")
        body.append("")

    subject = f"Swim Coach — riepilogo allenamento {today.strftime('%d/%m/%Y')}"
    return subject, "\n".join(body).strip() + "\n"


def build_reminder(today: date, workouts: list[dict]) -> tuple[str, str] | None:
    target = today + timedelta(days=1)
    planned = [w for w in workouts if parse_date(w.get("date") or w.get("scheduled_date")) == target]
    if not planned:
        print(f"Nessuna seduta programmata per domani ({format_date(target)}); nessuna email da inviare.")
        return None
    title = str(planned[0].get("title") or planned[0].get("name") or "Allenamento di domani")
    body = [
        "SWIM COACH — PROMEMORIA ALLENAMENTO",
        f"Domani, {format_date(target)}, è prevista una seduta di nuoto.",
        "",
    ]
    for i, workout in enumerate(planned, 1):
        if i > 1:
            body.extend(["", "---", ""])
        body.append(format_workout(workout, i))
    body.extend(["", "Buon allenamento!", "Swim Coach"])
    return f"Swim Coach — seduta di domani: {title}", "\n".join(body) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Invio email automatiche Swim Coach via Postfix.")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--weekly", action="store_true", help="Invia il riepilogo settimanale.")
    mode.add_argument("--daily", action="store_true", help="Invia il riepilogo degli allenamenti di oggi, se disponibili.")
    mode.add_argument("--reminder", action="store_true", help="Invia promemoria se domani è programmata una seduta.")
    parser.add_argument("--dry-run", action="store_true", help="Mostra l'email senza inviarla.")
    parser.add_argument("--date", help="Data di riferimento YYYY-MM-DD; ammessa solo con --dry-run.")
    args = parser.parse_args()
    if args.date and not args.dry_run:
        parser.error("--date è consentito soltanto con --dry-run.")
    try:
        email_to, email_from, timezone = load_config()
        if args.date:
            try:
                today = date.fromisoformat(args.date)
            except ValueError:
                parser.error("--date deve avere il formato YYYY-MM-DD.")
        else:
            today = datetime.now(timezone).date()
        workouts = load_workouts()
        if args.weekly:
            subject, body = build_weekly(today, timezone, workouts)
            msg = mail_message(email_to, email_from, subject, body)
            iso_year, iso_week, _ = today.isocalendar()
            key = f"weekly:{iso_year}-W{iso_week:02d}"
            deliver(msg, email_from, args.dry_run, key)
        elif args.daily:
            result = build_daily(today)
            if result is None:
                return 0
            subject, body = result
            msg = mail_message(email_to, email_from, subject, body)
            key = f"daily:{today.isoformat()}"
            deliver(msg, email_from, args.dry_run, key)
        else:
            result = build_reminder(today, workouts)
            if result is None:
                return 0
            subject, body = result
            msg = mail_message(email_to, email_from, subject, body)
            key = f"reminder:{(today + timedelta(days=1)).isoformat()}"
            deliver(msg, email_from, args.dry_run, key)
    except (OSError, ValueError, RuntimeError) as exc:
        print(f"ERRORE: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
